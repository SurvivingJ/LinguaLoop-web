# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1711`

Read `data/exercise_seeding/zh/wf2/r1711/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1711/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101793: 小卖部

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小卖部是学校或车站里卖零食和小东西的小店。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101794: 小卖部

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 设在学校、机关、车站、公园等地方，主要出售零食、饮料和日常小用品的小商店。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101799: 仍未

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 到现在还没有，以后可能会有。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101800: 仍未

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 副词，表示到现在为止某种情况还没有发生或出现，多用于书面语，含有事情以后可能发生的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101801: 交涉

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 和别人说话商量，想把事情办好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101802: 交涉

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指双方或多方为了解决某个问题或达成某种协议而进行商谈、协调，常用于外交、工作或纠纷等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
