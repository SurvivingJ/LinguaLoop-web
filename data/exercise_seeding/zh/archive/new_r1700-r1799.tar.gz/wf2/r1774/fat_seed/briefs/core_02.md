# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1774`

Read `data/exercise_seeding/zh/wf2/r1774/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1774/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100739: 翻身

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把身体转到另一边
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100741: 低头

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把头放低
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100743: 过错

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 过错就是做错了事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100745: 急切

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 非常想马上做某事
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100747: 生计

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 生计就是赚钱养活自己
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100749: 背包

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 背包是一种可以背在背上的袋子，用来放东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
