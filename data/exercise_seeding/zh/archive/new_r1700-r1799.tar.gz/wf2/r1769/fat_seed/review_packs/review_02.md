# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1769`

Read `data/exercise_seeding/zh/wf2/r1769/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1769/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1769/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1769/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1769/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 100593: 排练
- sense 100595: 考核表
- sense 100597: 摆满
- sense 100599: 欢呼声
- sense 100603: 急性
- sense 100607: 只顾
