# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1431`

Read `data/exercise_seeding/zh/wf2/r1431/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1431/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1431/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1431/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1431/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 96757: 壳
- sense 96758: 壳
- sense 96769: 比如说
- sense 96770: 比如说
- sense 96773: 海报
- sense 96774: 海报
