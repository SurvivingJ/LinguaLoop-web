# Fat-seed review 01 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1420`

Read `data/exercise_seeding/zh/wf2/r1420/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1420/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1420/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1420/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1420/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 96815: 同盟
- sense 96816: 同盟
- sense 96819: 哪像
- sense 96820: 哪像
- sense 96823: 善良
- sense 96824: 善良
