# Fat-seed review 01 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1411`

Read `data/exercise_seeding/zh/wf2/r1411/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1411/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1411/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1411/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1411/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 93399: 不确实
- sense 93400: 不确实
- sense 93403: 二话
- sense 93404: 二话
- sense 93415: 兑换
- sense 93416: 兑换
