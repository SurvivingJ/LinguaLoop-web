# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1835`

Read `data/exercise_seeding/zh/wf2/r1835/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1835/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1835/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1835/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1835/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 101317: 保持一致
- sense 101319: 至关重要
- sense 101321: 拨打
- sense 101323: 问卷
- sense 101327: 抽样
- sense 101329: 微弱
