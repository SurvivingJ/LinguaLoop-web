# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1511`

Read `data/exercise_seeding/zh/wf2/r1511/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1511/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1511/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1511/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1511/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 88105: 打扮
- sense 88106: 打扮
- sense 88113: 抓地
- sense 88114: 抓地
- sense 88121: 拍出
- sense 88122: 拍出
