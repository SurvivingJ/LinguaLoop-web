# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1503`

Read `data/exercise_seeding/zh/wf2/r1503/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1503/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1503/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1503/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1503/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 87674: 酷
- sense 87679: 针
- sense 87680: 针
- sense 87689: 电压
- sense 87690: 电压
- sense 87695: 饼
