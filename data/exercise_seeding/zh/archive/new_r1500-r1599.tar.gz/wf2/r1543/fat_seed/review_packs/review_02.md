# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1543`

Read `data/exercise_seeding/zh/wf2/r1543/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1543/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1543/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1543/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1543/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 88719: 下级
- sense 88720: 下级
- sense 88729: 不可思议
- sense 88730: 不可思议
- sense 88737: 世纪末
- sense 88738: 世纪末
