# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1566`

Read `data/exercise_seeding/zh/wf2/r1566/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1566/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 89969: 板块

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 板块是像大木板一样的一大块地。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89970: 板块

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 地球表面巨大的岩石块；也指某个整体中相对独立的部分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89975: 业主

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 业主是房子或店铺的主人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89981: 标准间

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 标准间是旅馆里有两张床的普通房间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89982: 标准间

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 旅馆中设施规格统一、一般有两张单人床的客房。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89987: 歌声

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 歌声是人唱歌时发出的声音。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
