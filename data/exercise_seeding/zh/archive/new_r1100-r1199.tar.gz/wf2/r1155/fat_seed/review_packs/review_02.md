# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1155`

Read `data/exercise_seeding/zh/wf2/r1155/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1155/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1155/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1155/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1155/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 90013: 发展中
- sense 90014: 发展中
- sense 90019: 知道了
- sense 90020: 知道了
- sense 90023: 社会主义
- sense 90024: 社会主义
