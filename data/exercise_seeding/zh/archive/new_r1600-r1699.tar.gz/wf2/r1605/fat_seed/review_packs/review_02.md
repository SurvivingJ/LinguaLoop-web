# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1605`

Read `data/exercise_seeding/zh/wf2/r1605/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1605/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1605/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1605/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1605/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 87367: 喜悦
- sense 87375: 国内线
- sense 87376: 国内线
- sense 87381: 团长
- sense 87389: 在教
- sense 87390: 在教
