# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0961`

Read `data/exercise_seeding/zh/wf2/r0961/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0961/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103149: 追尾

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 后面的车撞到前面车的屁股。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在早高峰的城市快速路上，一辆轿车因前车突然减速而发生追尾。
- sentences to write yourself: 9

## sense 103150: 追尾

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指行驶中的车辆，后车的前部撞上前车的后部，是一种常见的交通事故。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103155: 查勘

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 去一个地方，仔细看一看，弄清楚那里是什么样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 保险公司完成查勘定损后，会根据责任比例进行理赔。
- sentences to write yourself: 9

## sense 103156: 查勘

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 到现场实地察看、了解情况，常用于地质、灾害、工程、案件等方面，目的是弄清真实情况，为下一步工作提供依据。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103157: 行驶证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 行驶证是一张小卡，说明这辆车是谁的，可以上路开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与此同时，车主应及时向保险公司报案，提交事故证明、驾驶证、行驶证和照片等材料。
- sentences to write yourself: 9

## sense 103158: 行驶证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 行驶证是由交通管理部门发给车主的证件，上面写着车辆的所有人、车牌号码、车型等信息，证明这辆车可以合法在道路上行驶。开车时通常要随身携带。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
