# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0961`

Read `data/exercise_seeding/zh/wf2/r0961/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0961/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103217: 妨碍交通

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 东西挡在路上，车和人就走不过去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若车辆能够移动且无人受伤，双方应尽快将车移至不妨碍交通的地方，避免造成拥堵。
- sentences to write yourself: 9

## sense 103218: 妨碍交通

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人或物占用道路或影响通行，使车辆和行人不能顺利通过，造成道路堵塞或行动困难。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103219: 驾驶证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 驾驶证是一张小卡片。有了它，大人才可以开车。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与此同时，车主应及时向保险公司报案，提交事故证明、驾驶证、行驶证和照片等材料。
- sentences to write yourself: 9

## sense 103220: 驾驶证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 政府部门发给通过考试的人、证明他可以合法驾驶机动车的证件。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103301: 闪光灯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 照相时会很亮一下的灯，让照片看得更清楚。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 虽然碰撞较轻，但双方仍立即开启危险报警闪光灯，并在车后放置三角警示牌，防止二次事故。
- sentences to write yourself: 9

## sense 103302: 闪光灯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 照相机上或与相机配合使用的一种灯，在拍照的瞬间发出很强的光，用来在光线较暗时补充照明。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
