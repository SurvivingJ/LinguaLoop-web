# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0953`

Read `data/exercise_seeding/zh/wf2/r0953/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0953/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104189: 人为失误

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人做事时不小心，做错了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 正因如此，许多财务和销售人员在制作月度报表时，都将数据透视表视为不可或缺的工具，既提升了工作效率，又减少了人为失误，为管理层决策提供了可靠依据。
- sentences to write yourself: 9

## sense 104190: 人为失误

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指由于人的疏忽、不注意或操作不当而造成的错误，不是机器或自然原因引起的。常用于事故、工作或技术方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104191: 逐条

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 一条一条地，一个接着一个。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对成千上万行的销售记录，逐条统计不仅耗时费力，而且极易出错。
- sentences to write yourself: 9

## sense 104192: 逐条

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指把事情或项目按顺序一条一条地进行，不遗漏、不合并。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103965: 拉高

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西弄得更高，或者让数字变大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当少数极端值把整体拉高或拉低时，平均数会失去代表性：多数员工的月薪不过数千元，个别高管的巨额薪酬却使平均数看起来相当可观，此时中位数反而更接近真实处境。
- sentences to write yourself: 9

## sense 103966: 拉高

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 使位置、高度、数值、价格或音调等向上升高，常指人为地推高或提升。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
