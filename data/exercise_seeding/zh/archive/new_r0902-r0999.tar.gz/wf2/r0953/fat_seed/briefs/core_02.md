# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0953`

Read `data/exercise_seeding/zh/wf2/r0953/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0953/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101955: 并不相同

- reading: (none)
- dictionary POS hint: i. The enum below wins over this hint.
- existing definition: 两样东西不一样，有不同的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在描述一组数据的集中趋势时，人们习惯把平均数、中位数与众数当作可靠的答案，然而它们各自的敏感性并不相同，一旦数据的分布形态发生扭曲，结论便可能失真。
- sentences to write yourself: 9

## sense 101956: 并不相同

- reading: (none)
- dictionary POS hint: i. The enum below wins over this hint.
- existing definition: 表示两个或多个事物、人或情况之间有差别，并不一致。常用来说明不能把它们看成一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104106: 高管

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指公司或企业中职位较高的管理人员，如总经理、副总经理、总监等，负责制定决策和管理公司。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当少数极端值把整体拉高或拉低时，平均数会失去代表性：多数员工的月薪不过数千元，个别高管的巨额薪酬却使平均数看起来相当可观，此时中位数反而更接近真实处境。
- sentences to write yourself: 9

## sense 104105: 高管

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 高管是公司里管事情的大人物，他们做很重要的决定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104107: 偏态

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 偏态就是数据不是平均分开的，有的多在一边，有的少在另一边。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 偏态分布尤其容易制造错觉——在右偏的工资、房价数据中，平均数总被长尾拽向高处，而中位数依然稳稳停在多数人的位置上。
- sentences to write yourself: 9

## sense 104108: 偏态

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 统计学术语，指数据的分布不对称，集中的高峰偏向一侧，另一侧拖着长长的尾巴，与对称的正态分布不同。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
