# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0930`

Read `data/exercise_seeding/zh/wf2/r0930/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0930/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103297: 忍气吞声

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 被人欺负了，心里难过，也不敢说话，只好忍着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 倘若遇到违规收费、故意绕路或其他不当行为，乘客切勿忍气吞声，而应保留录音、截图等证据，及时向平台投诉，情况严重时报警处理。
- sentences to write yourself: 9

## sense 103298: 忍气吞声

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 受了委屈或欺负，心里不满，却不敢表达，也不敢反抗，只好默默忍受。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103299: 车牌号

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 车牌号是挂在车上的一串数字和字，每辆车都不一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 103300: 车牌号

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指车辆牌照上的号码，由汉字、字母和数字组成，用来识别每一辆车，也叫车牌号码。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103303: 发送给

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西或消息交给别人，让别人收到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 103304: 发送给

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把信息、邮件、物品、信号等传送出去，让某个对象收到。后面常接接收的对象，如“发送给老师”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
