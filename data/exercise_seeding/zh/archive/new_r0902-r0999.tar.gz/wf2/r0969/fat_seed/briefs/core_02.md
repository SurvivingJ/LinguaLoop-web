# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0969`

Read `data/exercise_seeding/zh/wf2/r0969/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0969/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 86477: 法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 法是大家都要听的规矩。
- learner tier: T3
- surface forms seen in tests: ["法"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (7, keep verbatim, put first):
  0. 记谱法就是写音乐的方法。
  1. 不同的地方有不同的记谱法。
  2. 他们需要记谱法帮忙。
  3. 没有记谱法，音乐很容易忘记。
  4. 几百年前，欧洲的作曲家用了新的记谱法。
  5. 慢慢地，这种记谱法传到了别的国家。
  6. 历史告诉我们，好的方法是慢慢来的。
- sentences to write yourself: 3

## sense 86478: 法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 由国家制定、要求大家共同遵守的规则，即法律。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104255: 埋下

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西放进土里盖好，或者把一个想法先放在心里，以后会长大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，平台以点击率作为核心指标，也埋下了隐患。
- sentences to write yourself: 9

## sense 104256: 埋下

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词。本义是把东西放进土里并盖住；也常比喻事先留下某种因素、想法或隐患，日后会产生影响或结果。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101207: 久而久之

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 时间长了，慢慢就变了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 用户越是点击某类话题，系统便越倾向于推送同类信息，久而久之，视野逐渐收窄，仿佛被困在一个由自身偏好编织的“信息茧房”里，难以接触到不同的观点。
- sentences to write yourself: 9

## sense 24972: 嵌入

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把一个小东西放进另一个东西里面。
- learner tier: T3
- surface forms seen in tests: ["嵌入"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 推荐算法已经深深嵌入我们的日常生活：打开新闻客户端或短视频平台，首页呈现的内容往往恰好契合我们的兴趣。
- sentences to write yourself: 9
