# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0908`

Read `data/exercise_seeding/zh/wf2/r0908/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0908/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103211: 潜藏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 藏在里面，不让人看见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 算法偏见常被误认为是技术本身的缺陷，实则往往源于训练数据中潜藏的社会成见。
  1. 网约车为人们的出行带来了极大的便利，然而其背后潜藏的安全隐患却不容忽视。
- sentences to write yourself: 8

## sense 103212: 潜藏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指隐藏在内部或深处，不容易被发现，多用于危险、问题、能力、感情等抽象或具体的事物。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104239: 归入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西放进一类里，让它成为这一类的一部分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 随后，企业会根据消费习惯对庞大的人群进行细分，把相似的用户归入同一类别，并分别推送不同的广告和优惠，这就是所谓的精准营销。
  1. 聚类分析为此提供了有效的思路，它能依据消费金额、购买频率和浏览偏好等数据，将特征相近的客户归入同一类别。
- sentences to write yourself: 8

## sense 104240: 归入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把某人或某事物划入、纳入某个类别、范围或系统之中，使其成为其中的一部分。常用于较正式的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104381: 茧

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 茧是小虫子吐丝做成的小壳，虫子住在里面长大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104382: 茧

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 某些昆虫（如蚕）的幼虫在变成蛹之前，吐丝结成的椭圆形外壳，也指手或脚上因长期摩擦而长出的厚硬皮。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
