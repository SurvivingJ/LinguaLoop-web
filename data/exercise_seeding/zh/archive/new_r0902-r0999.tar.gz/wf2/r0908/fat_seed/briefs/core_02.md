# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0908`

Read `data/exercise_seeding/zh/wf2/r0908/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0908/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102331: 缓冲

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 缓冲就是让快的事变慢一点，这样不会太猛，也不会太疼。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 正是在这样的背景下，离婚冷静期应运而生——它并非要阻止人们结束婚姻，而是为冲动的决定留出一点缓冲的余地。
  1. 过去，通勤是一段缓冲：走出办公室的那一刻，人便正式下班，家庭时间由此开始。
- sentences to write yourself: 8

## sense 102332: 缓冲

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指使冲突、冲击或紧张的情况变得缓和，也指起缓和作用的过程或事物。可用作动词，也常作名词或定语，如“缓冲地带”“缓冲时间”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 87484: 适用

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 适合使用；在某一范围内可以使用。
- learner tier: T3
- surface forms seen in tests: ["适用"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 至于饼图，它适用于表现各部分占整体的比例，但类别一旦超过五六个，扇形就会显得拥挤，读者难以分辨。
  1. 选购空气净化器时，不能只关注外观，而应综合考量洁净空气量、滤网寿命、适用面积与噪音水平。
- sentences to write yourself: 8

## sense 87483: 适用

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 适用是可以拿来用，用起来合适。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103939: 疏漏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 疏漏就是做事时没注意，漏掉了东西，或者做错了一点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 更重要的是，分析师可以把反复进行的清洗和统计步骤写成脚本，实现流程的自动化：每当新数据到来，只需运行脚本，就能在几分钟内得到结果，既避免了人工操作的疏漏，也使分析过程可以被复现和检验。
  1. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 8

## sense 103940: 疏漏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指因为粗心或考虑不周而出现的遗漏和错误；也可指这样的遗漏或错误本身。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
