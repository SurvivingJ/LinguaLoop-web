# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0968`

Read `data/exercise_seeding/zh/wf2/r0968/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0968/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103031: 客流量

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一段时间里，来店里或来这个地方的人有多少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其一是趋势，即客流量随经济发展、人口流动而呈现的长期增减走向；其二是季节性，指每年春节前后反复出现的周期性高峰；其三是偶发因素，比如极端天气或临时政策调整所造成的波动。
- sentences to write yourself: 9

## sense 103032: 客流量

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在一定时间内到某个场所（如商店、景区、车站）的人数总量，常用来衡量人流多少或生意好坏。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103071: 春运

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 过年前后，很多人坐车坐船回家，路上人特别多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢春运，全国铁路、公路和航空客流都会在短时间内急剧攀升，给运输部门带来巨大压力。
- sentences to write yourself: 9

## sense 103072: 春运

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指每年春节前后出现的全国性大规模人口流动高峰，大量人员集中乘坐火车、汽车、飞机等交通工具返乡或出行，交通运输十分紧张。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104272: 离不开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 表示某人或某事物不能没有另一个人或事物，必须依靠它才行；也可指因为有事或有关系，无法离开某地或某人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 要想提前做好运力调配，就离不开科学的预测。
- sentences to write yourself: 9

## sense 104271: 离不开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 离不开就是少了它不行，一定要有它。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
