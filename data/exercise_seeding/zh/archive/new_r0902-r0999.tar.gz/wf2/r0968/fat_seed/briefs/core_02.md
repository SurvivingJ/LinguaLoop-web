# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0968`

Read `data/exercise_seeding/zh/wf2/r0968/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0968/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104274: 增开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在原有数量之外，再增加开设或开行，多用于班次、课程、窗口、航线等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦遇到突发事件，历史规律就可能失效，因此，分析人员还需结合实时数据不断修正模型，使预测结果更贴近现实，从而为售票安排、车次增开和站内疏导提供可靠依据。
- sentences to write yourself: 9

## sense 104273: 增开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 本来有的车或课不够，就再多加一些。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104276: 疏导

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词。指清除阻塞，使水流或人流畅通；也指通过耐心的引导和开解，让人消除心中的烦闷或不良情绪。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦遇到突发事件，历史规律就可能失效，因此，分析人员还需结合实时数据不断修正模型，使预测结果更贴近现实，从而为售票安排、车次增开和站内疏导提供可靠依据。
- sentences to write yourself: 9

## sense 104275: 疏导

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 疏导就是把堵住的水或心里的难过慢慢引开，让它们顺畅地流走。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104277: 运力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 车、船、飞机一次能运多少东西，就是运力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 要想提前做好运力调配，就离不开科学的预测。
- sentences to write yourself: 9

## sense 104278: 运力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指交通工具或运输系统运送货物或旅客的能力，常用来说明运输的数量、规模或承载水平。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
