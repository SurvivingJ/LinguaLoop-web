# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0903`

Read `data/exercise_seeding/zh/wf2/r0903/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0903/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 19861: 来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从别处到说话人所在的位置。
- learner tier: T3
- surface forms seen in tests: ["来"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (10, keep verbatim, put first):
  0. 图案是一只猫，它坐在月亮上，一只爪子伸出来，好像在够星星。
  1. 我试穿了一下，感觉很舒服，于是就买了下来。
  2. 因为我知道，我真正喜欢的，是它所带来的那种感觉，那种简单、自由、快乐的感觉。
  3. 我知道，很多东西，一旦失去了，就很难再找回来。
  4. 春天来了，社区里很多人开始一起种树。
  5. 这个活动是居民自己组织的，大家自愿参加，没有人必须来。
  6. 虽然城市发展的速度很快，但我们也能做一点事来保护环境。
  7. ”年轻人和孩子也加入进来，他们学习自然知识，也学会了合作。
  8. 虽然一个人的力量很小，但是大家一起努力，就能带来大的改变。
  9. 如果条件符合，这些信息会被记录下来。
- sentences to write yourself: 0

## sense 27316: 来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从别处到说话人这里。
- learner tier: T3
- surface forms seen in tests: ["来"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 蔬菜直接在城市里生产，不需要从很远的农村运来。
  1. 未来，随着技术进步，这类项目可能成为城市生活的一部分。
- sentences to write yourself: 8

## sense 100645: 耐人寻味

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 这个词是说事情很有意思，让人想很久。
- learner tier: T3
- surface forms seen in tests: ["耐人寻味"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 于是，交易市场上出现了耐人寻味的一幕：房子越小、越旧，单价反而越高。
  1. 蘸料台前的取舍同样耐人寻味：嗜辣者层层叠叠地舀上辣椒与蒜末，仿佛生怕味道不足；清淡者只添少许香油与葱花，力求守住食材本味。
  2. 因此，如何在享受便利与保持自主之间寻得平衡，已成为智能家居时代一道耐人寻味的课题。
  3. 这种“地下化”带来的后果耐人寻味——课外辅导从明码标价的市场行为，变成了比拼人脉与信息的不平等竞争，无力支付高价家教的普通家庭反而更加被动。
- sentences to write yourself: 6

## sense 86650: 体验

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 亲身经历；通过实践来认识。
- learner tier: T3
- surface forms seen in tests: ["体验"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 或许网红店卖的从来不只是食物，更是一种值得分享的体验。
  1. 某些原本绕行过远的公交线路，经过优化后缩短了行程时间，乘客的候车体验也明显改善。
  2. 若新用户次日留存率不足三成，说明初次体验存在短板，比如注册流程繁琐，核心功能不易被发现。
  3. 然而，深度阅读所给予的思辨能力与审美体验，是任何速食式内容都无法替代的。
- sentences to write yourself: 6

## sense 86649: 体验

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 体验是自己亲身去试一试、感受一下。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100017: 一目了然

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 一眼就能看明白。
- learner tier: T3
- surface forms seen in tests: ["一目了然"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
  1. 如果只想查看某个季度或某一类产品的情况，还可以借助筛选功能，让无关信息暂时隐藏起来，使关键数据一目了然。
  2. 临近傍晚，她着手撰写周报，把结论提炼成简明的文字，并配以直观的图表，使不懂技术的同事也能一目了然。
- sentences to write yourself: 7
