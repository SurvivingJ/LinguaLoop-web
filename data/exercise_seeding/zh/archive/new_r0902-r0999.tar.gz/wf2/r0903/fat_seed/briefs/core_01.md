# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0903`

Read `data/exercise_seeding/zh/wf2/r0903/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0903/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101913: 望而却步

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 看到很难或很怕的事，就不敢往前走了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 近几年物价持续攀升，一把青菜从两块钱涨到五块，猪肉更是让人望而却步。
  1. 法律明确规定了每日和每月加班的上限，但在实际执行中，取证困难、担心失业等因素让许多人望而却步。
  2. 私教能根据个人体质与目标制定方案，及时纠正动作，避免运动损伤，这在很大程度上提高了训练的安全性，但高昂的费用也让一些人望而却步。
  3. 热门科室的专家号往往在放号后数分钟内被抢空，于是"号贩子"应运而生，将原本几十元的诊费炒至数百元，令不少外地患者望而却步。
- sentences to write yourself: 6

## sense 101914: 望而却步

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 原指看到危险、困难或可怕的事物，就吓得停下脚步不敢前进，现多形容遇到困难或危险就害怕退缩，不敢继续做下去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103673: 零散

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 零散就是东西很少，到处都有一点，不在一起。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 这些零散的行为数据经过算法整合，逐渐拼出一幅关于我们的“用户画像”。
  1. 随着社交平台的普及，网民每天都会留下海量评论，这些看似零散的文字背后，往往蕴藏着公众对产品、事件乃至政策的真实态度。
  2. 首先应追问数据来源：数据出自官方登记、专业调查，还是网络上的零散转载？
  3. 一种是“拍脑袋”式决策，管理者凭借个人直觉或零散印象迅速拍板，看似果断高效，实则风险潜伏其中。
- sentences to write yourself: 6

## sense 103674: 零散

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容事物数量少而且分散，不集中、不成整体；也可指不系统、不完整。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 85719: 多

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: “多”是说东西很多，数目大。
- learner tier: T3
- surface forms seen in tests: ["多"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (10, keep verbatim, put first):
  0. 印刷术可以很快地印出很多书。
  1. 书变多了，也变便宜了。
  2. 知识慢慢传到很多人那里。
  3. 他用机器印书，一天能印很多本。
  4. 田里的庄稼需要水，但水不多，所以每个人都要小心。
  5. 音乐理论也慢慢变多了。
  6. 今天的记谱法比以前清楚多了。
  7. 这样印书比以前快多了，也便宜多了。
  8. 很多人第一次能自己买书读。
  9. 学校越来越多，人们开始学习科学、历史和医学。
- sentences to write yourself: 0

## sense 85720: 多

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容词，数量大，与“少”相对；也表示超出。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
