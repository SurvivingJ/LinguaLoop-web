# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0929`

Read `data/exercise_seeding/zh/wf2/r0929/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0929/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103285: 偏僻

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 偏僻是说一个地方离城很远，路很少，人也很少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，有关司机故意绕路、言语骚扰乃至侵害乘客的报道屡见不鲜，这类事件往往发生在深夜、偏僻路段或行驶轨迹明显异常的情况下，而乘客与司机彼此陌生，一旦遭遇危险，往往难以判断对方的真实意图，也难以及时求助。
- sentences to write yourself: 9

## sense 103286: 偏僻

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容地方离城市或人多的地方很远，交通不方便，很少有人来往；也可形容人的性情古怪、不合群，或词语、事物不常见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103287: 发力

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 发力就是用力，把自己的力气用出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 唯有平台、监管部门与乘客三方共同发力，才能真正筑牢出行安全的防线。
- sentences to write yourself: 9

## sense 103288: 发力

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指集中使出力量或加大力度，多用于体育、劳动，也可比喻在工作、竞争中加把劲，开始发挥作用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103289: 网约车

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用手机叫来的车，车会来接你，带你去想去的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 网约车为人们的出行带来了极大的便利，然而其背后潜藏的安全隐患却不容忽视。
- sentences to write yourself: 9

## sense 103290: 网约车

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 网约车是指通过手机软件或网络平台预约的出租汽车服务，乘客在线下单，司机接单后按路线接送乘客，费用多由平台按里程和时间计算。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
