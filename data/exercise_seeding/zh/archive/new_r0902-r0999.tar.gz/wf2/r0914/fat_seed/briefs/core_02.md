# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0914`

Read `data/exercise_seeding/zh/wf2/r0914/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0914/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102977: 求医

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 人生病了，去找医生看病。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这种模式的兴起，折射出医疗资源分布不均的深层矛盾：优质医师集中于大城市，而偏远地区的居民往往求医无门。
  1. 这项制度看似寻常，实则体现了一种朴素的关怀：与其等到病痛袭来才四处求医，不如在身体尚未拉响警报之时，主动去了解它真实的状况。
- sentences to write yourself: 8

## sense 102978: 求医

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指生病或受伤后去找医生检查和治疗，多用于书面语或较正式的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103391: 个人隐私

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 个人隐私是你自己的事，你不想让别人知道，别人就不能乱看乱问。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 当然，在挖掘数据价值的同时，如何保护个人隐私，仍是必须审慎对待的课题。
  1. 当客厅、厨房和卫生间被四五个人共享，个人隐私便让位于彼此迁就：谁先用洗手间、谁该倒垃圾、深夜归来的脚步声有多响，都成了需要反复协商的议题。
- sentences to write yourself: 8

## sense 103392: 个人隐私

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指个人不愿公开、不希望别人知道或打听的私人信息和私生活，如家庭情况、通信内容、健康状况、住址等，受到法律保护。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102823: 屋檐下

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 屋檐下是房子边上伸出来的屋顶下面，可以躲雨。也可以说在别人家里住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 倘若每位饲主都能体谅他人对安宁与洁净的期待，人与宠物便可在同一屋檐下安然共存。
  1. 来自不同地域、习惯各异的室友被安排在同一屋檐下，朝夕相处。
- sentences to write yourself: 8

## sense 102824: 屋檐下

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指房屋檐口下面的地方，常用来躲雨、乘凉；也比喻在同一个家里或别人的家中生活，如“同一屋檐下”“寄人篱下”的处境。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
