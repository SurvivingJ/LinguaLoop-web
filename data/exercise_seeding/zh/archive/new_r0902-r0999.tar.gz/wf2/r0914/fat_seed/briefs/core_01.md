# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0914`

Read `data/exercise_seeding/zh/wf2/r0914/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0914/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 92074: 面试

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 当面考察应试者的能力和素质。
- learner tier: T3
- surface forms seen in tests: ["面试"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 求职者一旦进入这一区间，简历可能被快速过滤，面试机会也随之减少。
  1. 在求职过程中，面试不仅是展示能力的机会，也是判断岗位是否适合自己的重要环节。
  2. 准备面试时，求职者应当先研究公司背景、岗位职责和行业发展，再结合自己的经历整理出清晰的项目案例。
- sentences to write yourself: 7

## sense 92073: 面试

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 见面问你问题，看你合不合适。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100168: 餐

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 餐指食物，也指吃饭的场合或时间。
- learner tier: T3
- surface forms seen in tests: ["餐"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (5, keep verbatim, put first):
  0. 午餐这件小事，往往最能折射出一个人的生活方式。
  1. 若单从性价比来看，食堂似乎更具优势——无需采购、无需烹饪，刷卡即可解决一餐，时间成本被压缩到最低。
  2. 当然，带饭并非毫无代价，早起备餐的辛苦、微波炉前的排队，都是需要接受的现实。
  3. 其实，适量点菜、按需取餐，是每个人都能做到的节约方式。
  4. 当越来越多的人把光盘行动融入日常用餐，餐厅浪费现象有望得到更有效的改善。
- sentences to write yourself: 5

## sense 100167: 餐

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 餐就是饭，比如早餐、午餐、晚餐。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101521: 审慎

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 小心地
- learner tier: T3
- surface forms seen in tests: ["审慎"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 决策者既要解读曲线，也要在科学判断与社会成本之间审慎权衡。
  1. 当然，在挖掘数据价值的同时，如何保护个人隐私，仍是必须审慎对待的课题。
- sentences to write yourself: 8

## sense 101522: 审慎

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 形容做事很小心，不随便行动
- learner tier: T3
- surface forms seen in tests: ["审慎"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 贝叶斯思维的核心在于：面对新证据时，我们不应全盘推翻原有判断，而应据此审慎地修正信念。
- sentences to write yourself: 9
