# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0947`

Read `data/exercise_seeding/zh/wf2/r0947/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0947/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103437: 防暑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 天很热的时候，做事让身体不被热坏。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对普通市民而言，防暑的意义远不止于关掉空调：及时补水、减少正午外出、留意老人与儿童的身体状况，同样是度过酷暑的关键。
- sentences to write yourself: 9

## sense 103438: 防暑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在炎热的夏天采取措施，防止中暑或减轻高温对身体的伤害，比如多喝水、避开烈日、使用降温用品等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103523: 说到底

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 说到底就是说到最要紧的地方，讲最后的原因。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 说到底，极端高温考验的不只是电力供应能力，更是一座城市在气候压力下的应变智慧与公共治理能力。
- sentences to write yourself: 9

## sense 103524: 说到底

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 用在句子开头或中间，表示抓住事情的根本和关键，指出最终的原因或实质，引出结论，有“归根结底”的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103525: 限电

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 限电就是不让大家随便用电，有时会停电。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了防范大面积停电，有关部门不得不启动限电措施，对高耗能企业的生产计划加以调整，同时倡导公众将空调温度设定在二十六摄氏度左右，并避开用电高峰时段使用大功率电器。
- sentences to write yourself: 9

## sense 103526: 限电

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指因为电力不够用，由有关部门规定用电的时间或数量，限制企业或居民用电。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
