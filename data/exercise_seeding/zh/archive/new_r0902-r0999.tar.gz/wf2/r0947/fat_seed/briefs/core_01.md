# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0947`

Read `data/exercise_seeding/zh/wf2/r0947/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0947/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103427: 盛夏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 盛夏就是一年里最热的那段日子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢盛夏，持续的高温往往会将城市的能源系统推向极限。
- sentences to write yourself: 9

## sense 103428: 盛夏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指夏天最热的时期，一般是农历六月前后，也就是夏季的中间一段时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103429: 身体状况

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 身体好不好，有没有生病，就是身体状况。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对普通市民而言，防暑的意义远不止于关掉空调：及时补水、减少正午外出、留意老人与儿童的身体状况，同样是度过酷暑的关键。
- sentences to write yourself: 9

## sense 103430: 身体状况

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人身体健康或不健康的情况，包括有没有疾病、体力好不好、精神怎么样等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103431: 成倍增长

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 成倍增长就是变得越来越多，一次比一次多好几倍。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当气温攀升至四十摄氏度上下，居民对空调的依赖便骤然加剧，用电高峰随之出现，电网负荷在午后几个小时内成倍增长。
- sentences to write yourself: 9

## sense 103432: 成倍增长

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指数量一次次按倍数增加，比原来多出一倍或好几倍，增加得又快又多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
