# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0966`

Read `data/exercise_seeding/zh/wf2/r0966/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0966/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101684: 降低成本

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 减少开支，使成本降低
- learner tier: T3
- surface forms seen in tests: ["降低成本"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了降低成本、加快进度，许多企业采用众包模式，将任务拆解后分发给世界各地的兼职者。
- sentences to write yourself: 9

## sense 101683: 降低成本

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 让花的钱变少
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104793: 默默耕耘

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 默默耕耘是不说话，只是一直认真做事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 人们谈起人工智能，往往惊叹于算法的精妙，却很少留意其背后默默耕耘的庞大群体。
- sentences to write yourself: 9

## sense 104794: 默默耕耘

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指不声张、不图名利，一直踏实地努力工作或付出，多含赞扬之意。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104799: 扣薪

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 老板少给你一些工资，因为你做错了事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与此同时，为了确保数据准确，平台还设有严格的质量控制机制，例如多人交叉核对、抽查复审，错误率偏高者会被扣薪甚至清退。
- sentences to write yourself: 9

## sense 104800: 扣薪

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指单位或雇主因员工迟到、犯错或违反规定，从其应得的工资中扣除一部分钱，是一种处罚方式。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
