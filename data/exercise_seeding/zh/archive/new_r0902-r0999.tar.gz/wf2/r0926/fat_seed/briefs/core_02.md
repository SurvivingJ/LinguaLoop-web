# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0926`

Read `data/exercise_seeding/zh/wf2/r0926/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0926/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102843: 揣摩

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 揣摩就是用心想，去猜别人心里是什么想法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对要求格外严格的上级，与其揣摩其心思、迎合其偏好，不如建立起一种以专业与信任为基础的相处方式：主动汇报进展，坦率承认失误，在做出承诺之前审慎评估自己的承受边界。
- sentences to write yourself: 9

## sense 102844: 揣摩

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指反复思考、推测，设法弄明白别人的心思、意图或事物的含义，也指反复钻研、体会某种道理或技巧。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102845: 无可挑剔

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 这个东西太好了，一点坏处也找不到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多新人天真地以为，只要把分内之事做到无可挑剔，与同事保持礼貌的距离，便能在组织中安然立足；然而现实是，当部门内部出现分歧，甚至形成隐形的派系时，"站队"的压力会悄然逼近每一个人。
- sentences to write yourself: 9

## sense 102846: 无可挑剔

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容非常完美，没有任何缺点或错误可以指出。多用来称赞人的表现、作品或做法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101479: 务必

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 一定要
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 92307: 求助

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 求助是请别人来帮忙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，有关司机故意绕路、言语骚扰乃至侵害乘客的报道屡见不鲜，这类事件往往发生在深夜、偏僻路段或行驶轨迹明显异常的情况下，而乘客与司机彼此陌生，一旦遭遇危险，往往难以判断对方的真实意图，也难以及时求助。
- sentences to write yourself: 9
