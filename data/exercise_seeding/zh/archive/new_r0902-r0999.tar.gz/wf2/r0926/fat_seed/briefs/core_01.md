# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0926`

Read `data/exercise_seeding/zh/wf2/r0926/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0926/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102625: 出现分歧

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大家想的不一样，意见不同。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多新人天真地以为，只要把分内之事做到无可挑剔，与同事保持礼貌的距离，便能在组织中安然立足；然而现实是，当部门内部出现分歧，甚至形成隐形的派系时，"站队"的压力会悄然逼近每一个人。
- sentences to write yourself: 9

## sense 102626: 出现分歧

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人们在看法、意见或做法上不一致，各有各的想法，难以达成一致。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102745: 背锅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 别人做错了事，你却要受罚，这就是背锅。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 选择亲近某位领导，固然可能获得资源与庇护，却也意味着在关键时刻替其"背锅"的风险。
- sentences to write yourself: 9

## sense 102746: 背锅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指替别人承担错误或责任，自己没有做错却被责怪或受罚。多用于口语，常带有无奈或不公平的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102747: 分内之事

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 分内之事是你本来就该做的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多新人天真地以为，只要把分内之事做到无可挑剔，与同事保持礼貌的距离，便能在组织中安然立足；然而现实是，当部门内部出现分歧，甚至形成隐形的派系时，"站队"的压力会悄然逼近每一个人。
- sentences to write yourself: 9

## sense 102748: 分内之事

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指按照自己的职责、身份或本分应当做的事情，常用来表示做这件事不需要特别感谢或夸奖。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
