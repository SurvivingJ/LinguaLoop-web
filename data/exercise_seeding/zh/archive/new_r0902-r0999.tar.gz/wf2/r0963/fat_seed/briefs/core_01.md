# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0963`

Read `data/exercise_seeding/zh/wf2/r0963/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0963/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103843: 挂断

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 打电话时，按一下，让电话不再通话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 真正的反诈，不在于事后补救，而在于事前那份从容的怀疑——挂断电话，核实身份，便足以让骗子的伎俩无处遁形。
- sentences to write yourself: 9

## sense 103844: 挂断

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指结束电话通话，把电话线路切断，也指用手机或座机按键结束通话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103847: 积攒

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把一点一点的东西放在一起，越放越多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多老人一生积攒的养老钱，就这样在几分钟内被转走，追悔莫及。
- sentences to write yourself: 9

## sense 103848: 积攒

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指一点一点地聚集起来、慢慢存起来，多用于钱、物品、经验等，强调逐渐增多的过程。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103849: 遁形

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 遁形就是藏起来，让人看不见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 真正的反诈，不在于事后补救，而在于事前那份从容的怀疑——挂断电话，核实身份，便足以让骗子的伎俩无处遁形。
- sentences to write yourself: 9

## sense 103850: 遁形

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指隐藏起形体，不让人发现；多用于坏人、坏事或不好的东西无法再躲藏的情况，常与“无处”连用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
