# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0963`

Read `data/exercise_seeding/zh/wf2/r0963/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0963/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103851: 令人窒息

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 令人窒息是说让人觉得很闷，好像喘不过气来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们冒充公安、银行职员或远在他乡的子女，谎称账户涉案、银行卡被盗刷，甚至编造车祸、住院等紧急情形，刻意制造令人窒息的紧张氛围，迫使受害者在慌乱中失去判断力。
- sentences to write yourself: 9

## sense 103852: 令人窒息

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容环境、气氛、压力或美景等强烈得让人喘不过气，既可指紧张、压抑、难受的感觉，也可指美得让人屏住呼吸。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103853: 追悔莫及

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 做错了事，现在很难过，可是已经不能改了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多老人一生积攒的养老钱，就这样在几分钟内被转走，追悔莫及。
- sentences to write yourself: 9

## sense 103854: 追悔莫及

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容对过去所做的错事或错过的机会感到非常后悔，但事情已经无法挽回，后悔也来不及了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103855: 深谙

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 深谙就是对一件事懂得很多，也很明白里面的道理。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，针对老年人的电信诈骗愈发猖獗，骗子往往深谙老年人的心理弱点，以亲情为突破口，步步为营。
- sentences to write yourself: 9

## sense 103857: 深谙

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 非常熟悉并透彻地了解（某种道理、规律、技艺或事情），多用于书面语，常带有对其精通、有经验的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
