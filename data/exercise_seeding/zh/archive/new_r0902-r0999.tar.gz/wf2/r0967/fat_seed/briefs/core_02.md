# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0967`

Read `data/exercise_seeding/zh/wf2/r0967/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0967/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104459: 突发事件

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 突发事件是忽然发生的坏事，大家都没有想到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦遇到突发事件，历史规律就可能失效，因此，分析人员还需结合实时数据不断修正模型，使预测结果更贴近现实，从而为售票安排、车次增开和站内疏导提供可靠依据。
- sentences to write yourself: 9

## sense 104460: 突发事件

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指突然发生、事先没有预料到的、需要马上处理的事情，多指地震、火灾、事故等带来危害的情况。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104463: 偶发

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 偶发就是不常发生，只是偶尔出现一次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其一是趋势，即客流量随经济发展、人口流动而呈现的长期增减走向；其二是季节性，指每年春节前后反复出现的周期性高峰；其三是偶发因素，比如极端天气或临时政策调整所造成的波动。
- sentences to write yourself: 9

## sense 104464: 偶发

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指事情不是经常发生，而是偶然间出现，没有规律，也不一定会再次发生。常用来形容事件、情况、疾病、故障等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101463: 万无一失

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 一定不会出错
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当然，预测并非万无一失。
- sentences to write yourself: 9

## sense 100963: 每逢

- reading: (none)
- dictionary POS hint: 连词. The enum below wins over this hint.
- existing definition: 每次到了某个时候
- learner tier: T3
- surface forms seen in tests: ["每逢"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢春运，全国铁路、公路和航空客流都会在短时间内急剧攀升，给运输部门带来巨大压力。
- sentences to write yourself: 9
