# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0967`

Read `data/exercise_seeding/zh/wf2/r0967/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0967/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104450: 失效

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指失去原有的作用或效力，如药物、证件、合同、方法等不再起作用或不再有效。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦遇到突发事件，历史规律就可能失效，因此，分析人员还需结合实时数据不断修正模型，使预测结果更贴近现实，从而为售票安排、车次增开和站内疏导提供可靠依据。
- sentences to write yourself: 9

## sense 104449: 失效

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 东西不能再用了，或者没有用了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104451: 周期性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 每过一段时间，同样的事就会再来一次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其一是趋势，即客流量随经济发展、人口流动而呈现的长期增减走向；其二是季节性，指每年春节前后反复出现的周期性高峰；其三是偶发因素，比如极端天气或临时政策调整所造成的波动。
- sentences to write yourself: 9

## sense 104452: 周期性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指事物每隔一定的时间就重复出现或发生的特点，有规律地一次次循环。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104455: 售票

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 售票就是把车票或电影票卖给别人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦遇到突发事件，历史规律就可能失效，因此，分析人员还需结合实时数据不断修正模型，使预测结果更贴近现实，从而为售票安排、车次增开和站内疏导提供可靠依据。
- sentences to write yourself: 9

## sense 104456: 售票

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 出售车票、船票、电影票、门票等各种票券。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
