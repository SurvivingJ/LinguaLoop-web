# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0919`

Read `data/exercise_seeding/zh/wf2/r0919/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0919/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 95061: 弱

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 弱是力气小，不强壮。
- learner tier: T3
- surface forms seen in tests: ["弱"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 虽然有些公司说他们在改进，但是整个供应链的监管还很弱。
- sentences to write yourself: 9

## sense 95062: 弱

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 力量小、不强壮；与“强”相对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102437: 旧账

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 旧账是以前欠下的钱，也可以是以前做错的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 至于份子钱，明面上大家心照不宣，实则暗含一套约定俗成的尺度：亲疏远近、往来旧账，都在这只红包里悄然结算。
- sentences to write yourself: 9

## sense 102438: 旧账

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指以前欠下还没有还清的账目，也比喻过去留下的矛盾、错误或不愉快的事。常用在“翻旧账”“算旧账”等说法里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102439: 登门

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 走到别人家的门口，去看望人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 请帖的寄送也讲究次序，父母一辈的至亲宜由家中长辈亲自登门相邀，同事与朋友则可托人转交，礼数上的分寸往往比形式本身更受重视。
- sentences to write yourself: 9

## sense 102440: 登门

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指到别人家里去拜访，多用于正式或礼貌的场合，如看望、道谢、道歉或有事相求。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
