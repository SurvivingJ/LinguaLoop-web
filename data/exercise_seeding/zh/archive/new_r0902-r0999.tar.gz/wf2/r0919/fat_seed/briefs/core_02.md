# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0919`

Read `data/exercise_seeding/zh/wf2/r0919/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0919/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102441: 人情世故

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人情世故是人和人相处时要懂的事，比如怎么说话，怎么做事，别人才高兴。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一场体面的婚礼，与其说是排场的较量，不如说是对人情世故的一次细致打理。
- sentences to write yourself: 9

## sense 102442: 人情世故

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人与人之间交往相处的各种道理和规矩，包括礼节、情面、说话办事的方式等。常说“懂人情世故”或“不通人情世故”，表示是否善于与人相处、处事是否圆滑成熟。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102443: 心照不宣

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 大家心里都明白，但是谁也不说出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 至于份子钱，明面上大家心照不宣，实则暗含一套约定俗成的尺度：亲疏远近、往来旧账，都在这只红包里悄然结算。
- sentences to write yourself: 9

## sense 102444: 心照不宣

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容双方或大家心里都明白是怎么回事，不必明说，彼此已经默默理解。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102501: 相邀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 相邀就是大家你叫我，我叫你，一起去做一件事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 请帖的寄送也讲究次序，父母一辈的至亲宜由家中长辈亲自登门相邀，同事与朋友则可托人转交，礼数上的分寸往往比形式本身更受重视。
- sentences to write yourself: 9

## sense 102502: 相邀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 互相邀请，彼此约定一起做某事；也指邀请对方一同前往或参加。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
