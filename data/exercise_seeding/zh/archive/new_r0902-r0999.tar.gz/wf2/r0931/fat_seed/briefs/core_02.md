# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0931`

Read `data/exercise_seeding/zh/wf2/r0931/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0931/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102463: 家庭暴力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 家里的人打人或骂人，让家人很痛，也很怕。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对遭受家庭暴力的一方而言，多等三十天便意味着多一分风险；而在涉及子女抚养权与财产分割时，若双方始终无法达成一致，就只能转向诉讼。
- sentences to write yourself: 9

## sense 102464: 家庭暴力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指发生在家庭成员之间的暴力行为，如殴打、辱骂、威胁、限制自由等，会给受害者的身体和心理造成伤害，多发生在夫妻之间，也可发生在父母与子女之间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102465: 抚养权

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 爸爸妈妈分开后，孩子跟谁住、由谁来照顾，这是抚养权。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对遭受家庭暴力的一方而言，多等三十天便意味着多一分风险；而在涉及子女抚养权与财产分割时，若双方始终无法达成一致，就只能转向诉讼。
- sentences to write yourself: 9

## sense 102466: 抚养权

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指父母离婚后，依法由谁来照顾、教育和抚养未成年子女的权利。通常由法院或父母双方协商决定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 93443: 勉强

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 勉强是不太想做，可还是用力去做。
- learner tier: T3
- surface forms seen in tests: ["勉强"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 过去，离婚常被视为难以启齿的事；如今，越来越多人承认，一段无法修复的关系，与其勉强维持，不如坦然结束。
- sentences to write yourself: 9

## sense 93444: 勉强

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 能力不足而尽力去做；不情愿；不充分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
