# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0931`

Read `data/exercise_seeding/zh/wf2/r0931/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0931/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104245: 兴趣爱好

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 兴趣爱好是你很喜欢做的事，比如画画、唱歌、踢球。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 画像中包含年龄、地域、收入水平、兴趣爱好等信息，平台再据此给每个人贴上不同的标签，比如“学生党”“母婴人群”“价格敏感型”。
- sentences to write yourself: 9

## sense 104246: 兴趣爱好

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个人因为喜欢而经常去做的事情或活动，比如读书、画画、运动、听音乐等，多在业余时间进行，能带来快乐。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104383: 母婴

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 母婴是妈妈和她的小宝宝。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 画像中包含年龄、地域、收入水平、兴趣爱好等信息，平台再据此给每个人贴上不同的标签，比如“学生党”“母婴人群”“价格敏感型”。
- sentences to write yourself: 9

## sense 104384: 母婴

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指母亲和婴儿，常用来指与母亲和婴儿有关的事物，如母婴健康、母婴用品、母婴护理等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102461: 到场

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 到场就是人去了那个地方，在那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照规定，双方若协议离婚，须先提交申请，此后三十天内任何一方都可以撤回；期满还须共同到场，方能领取离婚证。
- sentences to write yourself: 9

## sense 102462: 到场

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人亲自来到某个活动或事情发生的现场，常用于会议、仪式、事故处理等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
