# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0909`

Read `data/exercise_seeding/zh/wf2/r0909/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0909/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102766: 按期

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 按照规定或约定的时间，不提前也不拖延；多用来表示完成任务、交付、还款、举行活动等准时进行。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101627: 剔除

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 去掉不需要的东西
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 其基本流程大致如下：首先对评论进行清洗，剔除广告和重复内容；接着借助分词技术，把连续的句子切分成独立的词语，因为中文词与词之间没有天然的空格；然后提取关键词，并对照情感词典或训练好的模型，判断每条评论倾向于正面、负面还是中立。
  1. 面对分散在不同系统中的海量记录，她编写查询语句，逐一提取所需字段，并剔除重复和异常的数据。
- sentences to write yourself: 8

## sense 103513: 随身携带

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西带在自己身上，不放下。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，越来越多人选择随身携带环保袋和可重复使用的水杯，把减少塑料用量变成一种生活方式。
  1. 居民只需在摄像头前稍作停留，大门便会自动开启，既省去了随身携带卡片的麻烦，也在一定程度上降低了陌生人随意进入的风险。
- sentences to write yourself: 8

## sense 103514: 随身携带

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把某种物品带在身边，不离开自己，方便随时使用或以防需要。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103585: 补水

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 给身体或皮肤加水，让它不干。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 环保袋不仅能反复清洗、长期使用，还能承载更重的物品；可重复使用的水杯则让人们在通勤、上课和旅行时随时补水，避免频繁购买瓶装饮料。
  1. 对普通市民而言，防暑的意义远不止于关掉空调：及时补水、减少正午外出、留意老人与儿童的身体状况，同样是度过酷暑的关键。
- sentences to write yourself: 8

## sense 103586: 补水

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 给身体、皮肤或植物等补充水分，使其不缺水、不干燥。也可指给容器、设备等补充水。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
