# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0909`

Read `data/exercise_seeding/zh/wf2/r0909/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0909/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100117: 从业者

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 做某种工作的人
- learner tier: T3
- surface forms seen in tests: ["从业者"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在数据分析领域，Python几乎成了从业者的“标配”，而pandas则是其中最受青睐的工具库。
  1. 真正成熟的从业者，总能在两者之间找到那条微妙的界线。
- sentences to write yourself: 8

## sense 87606: 惯例

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 长期沿用而形成的常规做法。
- learner tier: T3
- surface forms seen in tests: ["惯例"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，“996”逐渐从个别企业的内部规定，演变成一种被默认接受的行业惯例。
  1. 与之相近的是经验主义，即过度依赖过往成功的惯例，忽视环境已然发生的变化。
- sentences to write yourself: 8

## sense 87605: 惯例

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 惯例是大家一直都这样做的老办法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102835: 明确规定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把事情说得很清楚，让大家都知道该怎么做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 法律明确规定了每日和每月加班的上限，但在实际执行中，取证困难、担心失业等因素让许多人望而却步。
  1. 为此，我国出台了《个人信息保护法》，明确规定处理个人信息必须取得本人授权，并遵循最小必要原则，不得过度收集。
- sentences to write yourself: 8

## sense 102836: 明确规定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指用清楚、不含糊的话把事情的要求、范围或做法定下来，使人知道该怎么做。也指已经定好的清楚条文。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102765: 按期

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 按期就是在说好的那一天做完或到达，不早也不晚。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 如今，银行借助大数据构建信用评分体系：系统汇总借款人的收入、还款记录和负债比例，再通过统计模型换算成一个分数，分数越高，按期还款的可能性越大。
  1. 这份奖金并非人人相同，它与全年的绩效评估直接挂钩：项目是否按期交付、客户满意度如何、团队协作是否顺畅，都会体现在最终的考核表上。
- sentences to write yourself: 8
