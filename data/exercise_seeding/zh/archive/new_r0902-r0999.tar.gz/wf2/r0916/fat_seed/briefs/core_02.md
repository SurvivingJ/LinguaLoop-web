# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0916`

Read `data/exercise_seeding/zh/wf2/r0916/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0916/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102424: 祖辈

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指祖父母以及更早的前辈亲人，也泛指一个家族中已经去世或年纪很大的先人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 在城市的幼儿园里，孩子们说着一口标准的普通话，流畅而清晰；可回到家中，祖辈口中的乡音却常常让他们感到陌生。
  1. 老人带娃往往意味着更稳定的日常照料，却也容易带来教育观念上的张力：祖辈倾向于满足孩子的物质需求，父母则更重视学习习惯与独立能力的培养。
  2. 对于留守儿童而言，长期缺少父母的陪伴，可能使他们既感受到亲情的缺失，也在祖辈的呵护中学会体谅与自立。
  3. 家庭内部若能保持坦诚沟通，让老人理解年轻一代的养育期待，同时让父母尊重祖辈的辛劳与经验，隔代抚养便能减少摩擦，转化为三代人共同成长的契机。
- sentences to write yourself: 6

## sense 102423: 祖辈

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 祖辈是爷爷奶奶，还有比他们更早的家人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100515: 求职者

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 找工作的人
- learner tier: T3
- surface forms seen in tests: ["求职者"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 求职者一旦进入这一区间，简历可能被快速过滤，面试机会也随之减少。
  1. 然而，岗位门槛并不低，求职者需要具备扎实的技能组合。
- sentences to write yourself: 8

## sense 101093: 高强度

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 很强大，很厉害
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 企业担心成本上升，也担心员工难以接受高强度变化，于是把年龄视为风险信号。
  1. 他们愿意用不确定性换取可能性，用高强度的付出换取更快的回报。
- sentences to write yourself: 8

## sense 93592: 季

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一年中按气候分成的四个时期之一，也指某一段时期。
- learner tier: T3
- surface forms seen in tests: ["季"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 每年毕业季，考公都会成为许多年轻人绕不开的话题。
  1. 每逢选举季，媒体公布民调结果时，总会附上一行小字：“误差范围为正负三个百分点。
- sentences to write yourself: 8

## sense 93591: 季

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 季是一年中的一段时间。一年有四个季。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
