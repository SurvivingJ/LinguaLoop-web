# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0916`

Read `data/exercise_seeding/zh/wf2/r0916/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0916/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102003: 围坐在

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大家坐成一圈，把中间的东西围在中间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 除夕这天，天还没黑，一家人就已经围坐在厨房的长桌旁包饺子了。
  1. 人们真正在意的，或许并非财运，而是全家人能再一次围坐在一起，把平安与顺遂的愿望，一并包进那层薄薄的面皮里。
  2. 除夕之夜，一家人围坐在电视机前，等着春晚开场。
- sentences to write yourself: 7

## sense 102004: 围坐在

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 许多人坐在某个人或某个物体的四周，形成一圈，后面常接中心的人或物，如“围坐在桌旁”“围坐在火炉边”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 91320: 味

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 味道；舌头尝到或鼻子闻到的感觉。
- learner tier: T3
- surface forms seen in tests: ["味"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 有人无辣不欢，声称唯有那股直冲鼻腔的麻辣才算得上真正的滋味；有人则一闻花椒便额头冒汗，只敢点微辣。
  1. 所谓投缘，或许并不在于口味完全一致，而在于彼此愿意为对方留出一半清汤的余地。
- sentences to write yourself: 8

## sense 91319: 味

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 吃东西时，舌头尝到的感觉。
- learner tier: T3
- surface forms seen in tests: ["味"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 92952: 关怀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 关心并爱护。
- learner tier: T3
- surface forms seen in tests: ["关怀"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这项制度看似寻常，实则体现了一种朴素的关怀：与其等到病痛袭来才四处求医，不如在身体尚未拉响警报之时，主动去了解它真实的状况。
  1. 整个器官捐献与移植的流程，从捐献者的决定到受者的康复，都体现了生命的延续和人道的关怀。
- sentences to write yourself: 8

## sense 92951: 关怀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 关怀是心里想着别人，问他好不好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
