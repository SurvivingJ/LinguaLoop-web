# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0949`

Read `data/exercise_seeding/zh/wf2/r0949/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0949/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103247: 钻孔

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用工具在东西上打出一个洞。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 楼下住着一对刚生完孩子的年轻夫妇，婴儿白天要睡三个小时，而砸墙、钻孔产生的噪音恰好集中在上午。
- sentences to write yourself: 9

## sense 103248: 钻孔

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用钻头等工具在物体上打出圆形的孔或洞；也指这样打出来的孔。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103249: 踱步

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 踱步就是一步一步慢慢地走来走去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 但当我看到那位母亲抱着哭闹的孩子在楼道里来回踱步时，心里还是软了下来。
- sentences to write yourself: 9

## sense 103250: 踱步

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在较小的范围内来回缓慢地走，常表示在思考问题、心里着急或等待时的状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103333: 年轻夫妇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 年轻夫妇是刚结婚不久、年纪不大的一男一女，他们是一家人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 楼下住着一对刚生完孩子的年轻夫妇，婴儿白天要睡三个小时，而砸墙、钻孔产生的噪音恰好集中在上午。
- sentences to write yourself: 9

## sense 103334: 年轻夫妇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指年纪较轻、结婚时间不长的一对夫妻，常用来描述刚组建家庭、正在适应婚姻和生活的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
