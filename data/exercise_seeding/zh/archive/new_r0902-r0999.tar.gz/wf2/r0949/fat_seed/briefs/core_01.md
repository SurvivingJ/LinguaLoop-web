# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0949`

Read `data/exercise_seeding/zh/wf2/r0949/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0949/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103185: 打个招呼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 见到人，说一句“你好”，让他知道你看到他了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老房子管道老化，墙皮脱落，我原本以为只要提前跟邻居打个招呼，就能相安无事。
- sentences to write yourself: 9

## sense 103186: 打个招呼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指与人见面时用话语、手势或点头等方式简单问候，也指事先简短地通知或告知某人一声，以便对方知道或有所准备。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103243: 墙皮

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 墙皮是墙外面那一层薄薄的东西，旧了会掉下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老房子管道老化，墙皮脱落，我原本以为只要提前跟邻居打个招呼，就能相安无事。
- sentences to write yourself: 9

## sense 103244: 墙皮

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指墙壁表面抹的那层石灰、涂料或腻子等，时间长了或受潮后容易起皮、脱落。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103245: 收工

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 收工就是一天的活干完了，不再干了，可以回家。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我们最终商定，把高噪音的工序调整到下午两点以后，每天提前半小时收工。
- sentences to write yourself: 9

## sense 103246: 收工

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指一天或一段时间的工作结束，停止干活，通常指在工地、田间、工厂等地方下班。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
