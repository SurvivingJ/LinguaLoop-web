# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0973`

Read `data/exercise_seeding/zh/wf2/r0973/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0973/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101811: 虫蛀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 虫子把东西咬坏了，东西上就有小洞。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 见面时我仔细检查了桌面的成色与结构，确认没有开裂或虫蛀，便当场转账，又叫了辆小货车把桌子运回家。
- sentences to write yourself: 9

## sense 101812: 虫蛀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指虫子啃咬书籍、衣物、木头或牙齿等，使其受到损坏；也指被虫子咬坏的状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101815: 九成新

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 东西很新，只用过一点点，看起来差不多像新的一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 刷了半小时，我看中一张实木餐桌，卖家描述说九成新，成色几乎与新品无异，标价却只有原价的三分之一。
- sentences to write yourself: 9

## sense 101816: 九成新

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指物品使用过但保养得很好，外观和性能都接近全新，大约保留了原来的百分之九十，常用于二手商品的买卖。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100070: 小吃

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小吃指分量较小的食物，通常作为零食或点心食用。
- learner tier: T3
- surface forms seen in tests: ["小吃"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 屏幕那端，母亲系着围裙，手里正握着锅铲，准备手把手地教她做那道从小吃到大的家常菜——番茄炒蛋。
- sentences to write yourself: 9

## sense 100069: 小吃

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小吃是小的食物，比如点心。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
