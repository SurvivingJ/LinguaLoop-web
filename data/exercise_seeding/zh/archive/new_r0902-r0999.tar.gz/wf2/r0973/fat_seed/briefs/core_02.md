# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0973`

Read `data/exercise_seeding/zh/wf2/r0973/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0973/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102931: 咨询室

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 咨询室是人们去问问题、请人帮忙出主意的房间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 令人遗憾的是，真正需要帮助的人往往迟迟不敢走进心理咨询室。
- sentences to write yourself: 9

## sense 102932: 咨询室

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指专业人员（如心理咨询师、法律顾问、医生等）接待来访者，为他们解答问题、提供意见或帮助的房间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102933: 来访者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 来访者是到别人家里或别的地方来看人、找人的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 事实上，心理咨询并非替人做决定，而是协助来访者梳理紊乱的认知、重建与情绪共处的能力。
- sentences to write yourself: 9

## sense 102934: 来访者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指前来拜访、探望或咨询的人，常用于办公室、学校、医院、心理咨询等场合，也可指到某地参观访问的客人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102935: 侧目

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 侧目是歪着头看人，因为又怕又气，或者觉得很奇怪。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 横亘其间的并非费用，而是一种根深蒂固的偏见：有人把情绪困扰等同于意志薄弱，认为寻求专业支持是"软弱"的标签；也有人担心一旦留下记录，便会招致旁人的侧目与议论。
- sentences to write yourself: 9

## sense 102936: 侧目

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 向旁边斜着看，形容对人或事又畏惧又愤恨，或感到惊讶、不以为然而不敢正视。常用来说某种行为引起旁人的注意和不满。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
