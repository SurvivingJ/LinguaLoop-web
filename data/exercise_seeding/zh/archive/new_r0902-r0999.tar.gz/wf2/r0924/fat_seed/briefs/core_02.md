# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0924`

Read `data/exercise_seeding/zh/wf2/r0924/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0924/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100983: 隐忧

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 隐忧是藏在心里的担心。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当然，团长的权威高度依赖个人信誉，一旦品控失守，社群的黏性与复购率便会迅速瓦解，这或许正是该模式难以规模化扩张的隐忧。
- sentences to write yourself: 9

## sense 102019: 团购

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 很多人一起买同一样东西，价钱会便宜一些。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，社区团购迅速兴起，悄然重塑了城市家庭的日常采买方式。
- sentences to write yourself: 9

## sense 102020: 熟人

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 熟人是你认识的人，你们见过很多次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9

## sense 102022: 商品信息

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 商品信息就是告诉你这个东西是什么、多少钱的话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9

## sense 102029: 预售

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 东西还没做好，就先让人买。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对消费者而言，这种模式同时缓解了价格与便利的双重焦虑——平台以预售制压缩库存风险，从而让出部分利润；省去最后一公里的配送成本，又使生鲜价格明显低于传统商超。
- sentences to write yourself: 9

## sense 102030: 预售

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指商品或房屋等在还没有正式完成或上市之前，先向顾客提前出售。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
