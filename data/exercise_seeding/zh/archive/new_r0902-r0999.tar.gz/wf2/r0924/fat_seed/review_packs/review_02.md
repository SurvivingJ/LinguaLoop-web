# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0924`

Read `data/exercise_seeding/zh/wf2/r0924/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r0924/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r0924/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r0924/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r0924/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 100983: 隐忧
- sense 102019: 团购
- sense 102020: 熟人
- sense 102022: 商品信息
- sense 102029: 预售
- sense 102030: 预售
