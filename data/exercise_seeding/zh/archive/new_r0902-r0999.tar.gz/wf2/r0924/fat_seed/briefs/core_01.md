# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0924`

Read `data/exercise_seeding/zh/wf2/r0924/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0924/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101939: 失守

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 失守就是本来守住的地方，被别人抢走了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当然，团长的权威高度依赖个人信誉，一旦品控失守，社群的黏性与复购率便会迅速瓦解，这或许正是该模式难以规模化扩张的隐忧。
- sentences to write yourself: 9

## sense 101940: 失守

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指防守的地方或阵地被敌人攻占；也比喻原有的立场、防线或原则没有守住，被突破或放弃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101941: 生鲜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 生鲜是刚买来的菜、肉、鱼和水果，不能放太久。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对消费者而言，这种模式同时缓解了价格与便利的双重焦虑——平台以预售制压缩库存风险，从而让出部分利润；省去最后一公里的配送成本，又使生鲜价格明显低于传统商超。
- sentences to write yourself: 9

## sense 101942: 生鲜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指蔬菜、水果、肉类、水产、蛋奶等容易变坏、需要保持新鲜的食品，常用来指这类食品的销售类别。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101943: 邻里关系

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 住得近的人，天天见面，互相有没有帮忙、好不好，就是邻里关系。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9

## sense 101944: 邻里关系

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指住在同一个小区、同一条街或相邻住处的人们之间的相处情况和联系，例如是否友好、互相帮助、来往多少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
