# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0904`

Read `data/exercise_seeding/zh/wf2/r0904/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0904/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103190: 据此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: 连词，意思是根据上文所说的情况或内容，常用来引出由此得出的结论、判断或做法，多用于书面语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 88832: 分数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 考试或比赛所得的成绩；表示几分之几的数。
- learner tier: T3
- surface forms seen in tests: ["分数"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 如今，银行借助大数据构建信用评分体系：系统汇总借款人的收入、还款记录和负债比例，再通过统计模型换算成一个分数，分数越高，按期还款的可能性越大。
  1. 它之所以令人望而生畏，并非仅仅因为试题本身，而在于它承载着某种近乎宿命的期待——在许多父母眼中，孩子的分数几乎等同于家庭的体面与前程。
  2. 当家庭学会把分数还原为分数，把志愿交还给孩子的兴趣，那份压力才会真正松动。
  3. 若两组成绩的均值相同，一组分数集中在均值附近，另一组则高低悬殊，那么仅凭平均数便难以分辨二者的优劣。
- sentences to write yourself: 6

## sense 88831: 分数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 分数是考试得到的成绩，也是几分之几的数。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103183: 楼道

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 楼道是楼房里的走路的地方，在家门外面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 但当我看到那位母亲抱着哭闹的孩子在楼道里来回踱步时，心里还是软了下来。
  1. 新的回迁楼明亮、整洁，电梯取代了爬不完的楼梯，可楼道里再也听不见隔着窗子的招呼声。
  2. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 7

## sense 103184: 楼道

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 楼房里供人行走的通道，连接各层楼梯和各家各户的门，一般在楼梯间或每层的房门之外。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101155: 判断力

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 判断力是知道事情好坏的能力。
- learner tier: T3
- surface forms seen in tests: ["判断力"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 更微妙的是对时间的掌控——最优惠的组合往往安排在深夜推出，此时人的理性判断力最为薄弱，冲动消费便顺理成章地发生。
  1. 异常值则更考验判断力：它可能是录入错误，也可能是真正值得追踪的极端现象，草率删除等于抹去最有价值的线索。
  2. 这种观念忽略了一个事实：经验、判断力与职业稳定性，往往在中年阶段更加成熟。
- sentences to write yourself: 7
