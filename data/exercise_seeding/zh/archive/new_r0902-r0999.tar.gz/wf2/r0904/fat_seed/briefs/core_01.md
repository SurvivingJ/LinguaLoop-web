# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0904`

Read `data/exercise_seeding/zh/wf2/r0904/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0904/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 87730: 相应

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容词，相互照应或对应的。
- learner tier: T3
- surface forms seen in tests: ["相应"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 然而，学历的提升并未带来相应的回报，硕士毕业生同样面临激烈的岗位争夺，"内卷"由此从校园蔓延至整个劳动力市场。
  1. 它的核心功能是查询：用户只需通过简洁的语句，说明想要哪些数据、满足什么条件，系统便会返回相应结果。
- sentences to write yourself: 8

## sense 87729: 相应

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 相应是跟另一件事配得上，也跟着变。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102953: 可视化

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把看不见的东西变成能看见的图或画。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这种可视化的坚持，让枯燥的重复变得有意义——塑造身体的从来不是一时的决心，而是日复一日的自律。
  1. 其次，Python凭借丰富的程序库，在数据清洗、统计建模和可视化方面发挥着重要作用。
- sentences to write yourself: 8

## sense 102954: 可视化

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把数据、信息或抽象的内容用图表、图像、动画等形式表现出来，让人更容易看懂和理解。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101351: 海量

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 海量就是非常多，像大海一样多。
- learner tier: T3
- surface forms seen in tests: ["海量"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 数据看板正是为此而生的管理工具：它将分散在销售、物流、客服等系统中的海量信息加以整合，以图表的形式集中呈现在同一界面上。
  1. 随着社交平台的普及，网民每天都会留下海量评论，这些看似零散的文字背后，往往蕴藏着公众对产品、事件乃至政策的真实态度。
  2. 面对分散在不同系统中的海量记录，她编写查询语句，逐一提取所需字段，并剔除重复和异常的数据。
- sentences to write yourself: 7

## sense 103189: 据此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: 据此就是照着前面说的话或事情，然后做下一步。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 前者受业主委托，负责安保、保洁与设施维护，并据此收取物业费；后者作为基层群众性自治组织，更多承担政策宣传、纠纷调解一类职能。
  1. 企业和政府部门可据此监测舆情走向，及时发现潜在的危机。
  2. 经过这样的转换，杂乱的信息才逐渐变得可以分析，企业也能据此改进服务。
- sentences to write yourself: 7
