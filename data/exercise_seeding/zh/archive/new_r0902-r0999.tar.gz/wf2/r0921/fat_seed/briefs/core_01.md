# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0921`

Read `data/exercise_seeding/zh/wf2/r0921/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0921/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102059: 杯中酒

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 杯子里的酒。有人用它说爱喝酒的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 白酒因其度数高、后劲足，长期占据着宴请场合的中心位置；主人一声"干杯"，杯中酒必须一饮而尽，否则便可能被解读为对东道主的轻视。
- sentences to write yourself: 9

## sense 102060: 杯中酒

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 字面指杯子里盛着的酒，常用来指饮酒这件事，多带有借酒消愁或沉迷饮酒的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101983: 一饮而尽

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 一口气把杯子里的水或酒全部喝完。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 白酒因其度数高、后劲足，长期占据着宴请场合的中心位置；主人一声"干杯"，杯中酒必须一饮而尽，否则便可能被解读为对东道主的轻视。
- sentences to write yourself: 9

## sense 101984: 一饮而尽

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容把杯中的酒、水等饮料一口气全部喝光，中间不停顿，多用于喝酒或喝药的场合，带有干脆、豪爽的意味。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101979: 酒桌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 大家一起吃饭喝酒时用的桌子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在中国的商务宴请中，酒桌文化往往被视为一种微妙的沟通语言。
  1. 当"能喝"不再等同于"能办事"，这套延续多年的酒桌文化，也在悄然松动。
- sentences to write yourself: 8

## sense 101980: 酒桌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人们聚在一起吃饭、喝酒时所用的桌子，也常指饮酒聚餐的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
