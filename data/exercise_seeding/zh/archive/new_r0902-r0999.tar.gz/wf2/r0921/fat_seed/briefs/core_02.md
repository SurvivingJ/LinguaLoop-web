# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0921`

Read `data/exercise_seeding/zh/wf2/r0921/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0921/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101987: 婉言谢绝

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用好听、客气的话，说不要或不能接受。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人以身体为由婉言谢绝，也有人用茶代酒，试图在人情往来与自我边界之间寻找平衡。
- sentences to write yourself: 9

## sense 101988: 婉言谢绝

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用委婉、客气的话语拒绝别人的邀请、请求或赠送，既表明不接受，又不让对方难堪。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101905: 每斤

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 买东西时，每一斤东西都是这个价钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们的采购堪称一门学问：先绕场一周，把各摊位的报价默默记在心里，再折回来精挑细选；有人甚至把三家摊子的单价换算成每斤多少钱，力求一目了然。
- sentences to write yourself: 9

## sense 101906: 每斤

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 表示每一斤重量的东西，常用在说价格或数量的时候，意思是按每一斤来算。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101909: 摊主

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 摊主是在路边摆东西卖的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 摊主们大多心知肚明，遇上这样的老主顾，往往笑着抹去零头。
- sentences to write yourself: 9

## sense 101910: 摊主

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在市场、街边或集市上摆摊做生意的人，也指摊位的主人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
