# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0948`

Read `data/exercise_seeding/zh/wf2/r0948/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0948/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103527: 电力供应

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 电力供应就是把电送到家里和工厂，让灯亮，让机器动。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 说到底，极端高温考验的不只是电力供应能力，更是一座城市在气候压力下的应变智慧与公共治理能力。
- sentences to write yourself: 9

## sense 103528: 电力供应

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指发电厂等单位通过电网把电能输送并提供给居民、企业和各种设施使用的过程，也指所提供电的数量和稳定情况。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103529: 大功率

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 大功率的机器力气很大，能做很多事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了防范大面积停电，有关部门不得不启动限电措施，对高耗能企业的生产计划加以调整，同时倡导公众将空调温度设定在二十六摄氏度左右，并避开用电高峰时段使用大功率电器。
- sentences to write yourself: 9

## sense 103530: 大功率

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指设备或机器单位时间内做功或消耗、输出的能量很大，功率高。常用来修饰电器、发动机、电机等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103531: 骤然

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 骤然就是一下子，很快，没想到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当气温攀升至四十摄氏度上下，居民对空调的依赖便骤然加剧，用电高峰随之出现，电网负荷在午后几个小时内成倍增长。
- sentences to write yourself: 9

## sense 103532: 骤然

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 副词，表示某种情况突然发生，来得很快，让人没有准备，多用于书面语，常用来描写天气、声音、气氛、情绪等的急剧变化。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
