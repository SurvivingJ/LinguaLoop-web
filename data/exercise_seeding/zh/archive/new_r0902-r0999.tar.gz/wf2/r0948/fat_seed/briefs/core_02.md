# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0948`

Read `data/exercise_seeding/zh/wf2/r0948/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0948/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103533: 酷暑

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 酷暑就是夏天特别特别热的时候。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对普通市民而言，防暑的意义远不止于关掉空调：及时补水、减少正午外出、留意老人与儿童的身体状况，同样是度过酷暑的关键。
- sentences to write yourself: 9

## sense 103534: 酷暑

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指夏天非常炎热的天气或时期，通常指气温很高、让人觉得难受的盛夏时节。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103535: 高耗能

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 用很多电或煤气，一下子就用掉很多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了防范大面积停电，有关部门不得不启动限电措施，对高耗能企业的生产计划加以调整，同时倡导公众将空调温度设定在二十六摄氏度左右，并避开用电高峰时段使用大功率电器。
- sentences to write yourself: 9

## sense 103536: 高耗能

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指生产或使用过程中消耗大量能源（如电、煤、石油、天然气）的，常用来形容行业、企业、设备或产品。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103181: 商定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大家一起说好，然后定下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我们最终商定，把高噪音的工序调整到下午两点以后，每天提前半小时收工。
- sentences to write yourself: 9

## sense 103182: 商定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 经过商量后确定下来，指双方或多方通过讨论就某件事达成一致的决定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
