# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0933`

Read `data/exercise_seeding/zh/wf2/r0933/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0933/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102341: 难以启齿

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 有些话让人觉得不好意思，不敢说出口。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 过去，离婚常被视为难以启齿的事；如今，越来越多人承认，一段无法修复的关系，与其勉强维持，不如坦然结束。
- sentences to write yourself: 9

## sense 102342: 难以启齿

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指因为害羞、尴尬、愧疚或顾虑等原因，心里想说的话很不好意思开口说出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103187: 维权

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 别人对你不好，你站出来保护自己应得的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来的一个突出矛盾集中在维修资金与公共收益的支配上：部分业主质疑物业公司账目不清，遂联合成立业主委员会，希望通过集体谈判与依法维权来约束其行为；居委会则倾向于居中调停，避免因对立激化而影响社区稳定。
- sentences to write yourself: 9

## sense 103188: 维权

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 维护自己的合法权益，当权利受到侵害时，通过正当的方式（如投诉、协商、诉讼等）争取和保护应有的权利。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103191: 安保

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 安保就是保护大家的安全，不让坏人做坏事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 前者受业主委托，负责安保、保洁与设施维护，并据此收取物业费；后者作为基层群众性自治组织，更多承担政策宣传、纠纷调解一类职能。
- sentences to write yourself: 9

## sense 103192: 安保

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指为保护人员、场所或活动的安全而采取的防范和保卫工作，也指做这类工作的人员。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
