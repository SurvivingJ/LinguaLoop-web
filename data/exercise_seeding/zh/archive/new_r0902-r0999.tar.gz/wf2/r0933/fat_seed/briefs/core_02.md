# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0933`

Read `data/exercise_seeding/zh/wf2/r0933/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0933/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103193: 物业公司

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 物业公司是帮住在小区里的人打扫、修东西、看大门的公司。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在许多城市的小区里，物业公司与居委会之间的摩擦由来已久。
  1. 近年来的一个突出矛盾集中在维修资金与公共收益的支配上：部分业主质疑物业公司账目不清，遂联合成立业主委员会，希望通过集体谈判与依法维权来约束其行为；居委会则倾向于居中调停，避免因对立激化而影响社区稳定。
- sentences to write yourself: 8

## sense 103194: 物业公司

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专门为住宅小区或写字楼提供管理和服务的公司，负责保洁、保安、绿化、设施维修和收取物业费等工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103195: 保洁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 保洁就是把地方打扫干净，并让它一直保持干净。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 前者受业主委托，负责安保、保洁与设施维护，并据此收取物业费；后者作为基层群众性自治组织，更多承担政策宣传、纠纷调解一类职能。
- sentences to write yourself: 9

## sense 103196: 保洁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指负责打扫并保持环境整洁干净，多用于公共场所、小区、办公楼等；也指从事这种工作的人员。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103253: 越权

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 越权就是做了不该你做的事，超出了你能管的范围。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 二者的职责边界本就模糊，一旦小区出现停车混乱、公共空间被占用之类的问题，双方便容易相互推诿，指责对方越权或缺位。
- sentences to write yourself: 9

## sense 103254: 越权

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 超出自己的职权范围去做事或作决定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
