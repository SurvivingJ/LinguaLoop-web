# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0950`

Read `data/exercise_seeding/zh/wf2/r0950/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0950/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100269: 体谅

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 体谅就是理解别人的难处，不责怪他们。
- learner tier: T3
- surface forms seen in tests: ["体谅"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这件事让我明白，城市生活里的摩擦往往并非源于恶意，而是源于彼此缺乏体谅与沟通。
- sentences to write yourself: 9

## sense 100917: 消防通道

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 消防通道是消防车走的路。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，共享单车在缓解短途出行压力、衔接公共交通方面发挥了积极作用，然而乱停乱放现象却不断侵蚀人行道、盲道和消防通道，使公共空间面临新的治理难题。
- sentences to write yourself: 9

## sense 23228: 公共交通

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 大家都能用的车和路，比如公交车和地铁。
- learner tier: T3
- surface forms seen in tests: ["公共交通"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，共享单车在缓解短途出行压力、衔接公共交通方面发挥了积极作用，然而乱停乱放现象却不断侵蚀人行道、盲道和消防通道，使公共空间面临新的治理难题。
- sentences to write yourself: 9

## sense 103107: 商圈

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 商圈是很多商店聚在一起的地方，人们常去那里买东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一些用户为图方便，扫码后随意停放车辆，甚至将车堆放在小区门口、地铁出口和商圈周边，影响老人、儿童和残障人士通行。
- sentences to write yourself: 9

## sense 103108: 商圈

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指以某个商业中心为核心，周围商店、餐厅、娱乐场所集中，并能吸引顾客前来消费的区域。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101781: 顺理成章

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 事情照着道理一步一步做，结果自然就出来了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更微妙的是对时间的掌控——最优惠的组合往往安排在深夜推出，此时人的理性判断力最为薄弱，冲动消费便顺理成章地发生。
- sentences to write yourself: 9
