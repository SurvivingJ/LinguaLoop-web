# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0950`

Read `data/exercise_seeding/zh/wf2/r0950/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0950/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103335: 哭闹

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 小孩一边大声哭，一边吵，不肯停。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 但当我看到那位母亲抱着哭闹的孩子在楼道里来回踱步时，心里还是软了下来。
- sentences to write yourself: 9

## sense 103336: 哭闹

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人（多指小孩）又哭又喊，吵闹不休，常常是为了发泄不满或达到某种要求。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103337: 委婉

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 委婉就是说话很温和，不直接说难听的话，怕别人难过。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们起初只是上门委婉地提醒，后来见施工时间一再延长，便直接向物业投诉。
- sentences to write yourself: 9

## sense 103338: 委婉

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容说话含蓄、温和，不直截了当，用比较柔和的方式表达，以免让对方难堪或不高兴。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103339: 相安无事

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 大家在一起，不吵架，也不打架，很平静。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老房子管道老化，墙皮脱落，我原本以为只要提前跟邻居打个招呼，就能相安无事。
- sentences to write yourself: 9

## sense 103340: 相安无事

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指彼此之间没有争吵或冲突，能够平静地共同相处。多用于人与人、群体或国家之间，常带有勉强维持平静的意味。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
