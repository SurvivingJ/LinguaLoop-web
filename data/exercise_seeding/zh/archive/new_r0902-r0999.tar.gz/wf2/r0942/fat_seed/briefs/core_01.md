# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0942`

Read `data/exercise_seeding/zh/wf2/r0942/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0942/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103581: 习惯于

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 做一件事做久了，就觉得很平常，也不难受。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 过去，许多消费者习惯于在超市购买商品时顺手索取一次性塑料袋，也习惯在外卖和饮品店使用塑料杯和塑料吸管。
- sentences to write yourself: 9

## sense 103582: 习惯于

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指对某种环境、做法或情况长期接触后，已经适应，不再感到不自然或不舒服，常后接名词、动词或小句。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103583: 塑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 塑就是用泥或别的软东西做出一个样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103584: 塑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用泥、石膏、塑料等材料做出人或物的形象；也指塑料，常用于“塑造”“雕塑”“塑料”等词中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103587: 瓶装

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 把水或饮料放在瓶子里卖，就叫瓶装。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 环保袋不仅能反复清洗、长期使用，还能承载更重的物品；可重复使用的水杯则让人们在通勤、上课和旅行时随时补水，避免频繁购买瓶装饮料。
- sentences to write yourself: 9

## sense 103588: 瓶装

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指把液体等东西装在瓶子里的，常用来说明饮料、水、调料等商品的包装方式。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
