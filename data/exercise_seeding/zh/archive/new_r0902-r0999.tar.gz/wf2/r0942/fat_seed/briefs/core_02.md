# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0942`

Read `data/exercise_seeding/zh/wf2/r0942/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0942/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103423: 塑料杯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 塑料杯是用塑料做的杯子，可以用来喝水。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 过去，许多消费者习惯于在超市购买商品时顺手索取一次性塑料袋，也习惯在外卖和饮品店使用塑料杯和塑料吸管。
- sentences to write yourself: 9

## sense 103424: 塑料杯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用塑料制成的杯子，质地轻，不容易摔破，常用来装水、饮料等，有的可以重复使用，有的是一次性的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104051: 影视剧

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 影视剧是在电视或电影里演的故事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 它不再是博物馆橱窗里僵硬的陈列品，也不是影视剧中虚构的想象，而是被年轻人主动穿进地铁、校园与咖啡馆的鲜活存在。
- sentences to write yourself: 9

## sense 104052: 影视剧

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指电影和电视剧的合称，也泛指在银幕或荧屏上播放的、由演员表演的故事类作品。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104053: 鲜活

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 鲜活是说东西有生命，看起来很新，很有精神。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 它不再是博物馆橱窗里僵硬的陈列品，也不是影视剧中虚构的想象，而是被年轻人主动穿进地铁、校园与咖啡馆的鲜活存在。
- sentences to write yourself: 9

## sense 104054: 鲜活

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容生物生机勃勃、充满活力；也指事物（如语言、形象、事例）生动真实、富有生活气息，不呆板。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
