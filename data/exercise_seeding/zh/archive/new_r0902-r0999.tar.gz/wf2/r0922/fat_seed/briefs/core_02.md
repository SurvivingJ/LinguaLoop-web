# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0922`

Read `data/exercise_seeding/zh/wf2/r0922/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0922/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101861: 两块钱

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 两块钱就是两元钱，是一点点钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近几年物价持续攀升，一把青菜从两块钱涨到五块，猪肉更是让人望而却步。
- sentences to write yourself: 9

## sense 101862: 两块钱

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 表示钱的数目是两元，口语中常用来说价格很低或金额很小，也可以指具体的两元钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101867: 收摊

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 小摊的人不卖东西了，把东西收好回家。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 傍晚收摊前，降价处理的蔬菜最受欢迎，几位老人围在一处交流心得，那份从容与默契，是超市冷柜里找不到的烟火气。
- sentences to write yourself: 9

## sense 101868: 收摊

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指摆摊做生意的人结束一天的营业，把货物和摊位收拾起来；也可比喻活动或工作结束。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101869: 交流心得

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把自己做事时学到的好办法和想法，讲给别人听，也听别人讲。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 傍晚收摊前，降价处理的蔬菜最受欢迎，几位老人围在一处交流心得，那份从容与默契，是超市冷柜里找不到的烟火气。
- sentences to write yourself: 9

## sense 101870: 交流心得

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人们互相分享在学习、工作或生活中得到的体会、经验和想法，彼此启发，共同进步。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
