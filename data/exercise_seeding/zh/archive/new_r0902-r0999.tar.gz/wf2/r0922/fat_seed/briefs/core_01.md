# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0922`

Read `data/exercise_seeding/zh/wf2/r0922/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0922/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101911: 冷柜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 冷柜是很冷的大柜子，里面可以放肉和冰淇淋，东西不会坏。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 傍晚收摊前，降价处理的蔬菜最受欢迎，几位老人围在一处交流心得，那份从容与默契，是超市冷柜里找不到的烟火气。
- sentences to write yourself: 9

## sense 101912: 冷柜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一种用电制冷的柜子，用来冷冻或冷藏食品、饮料等，常见于超市、饭店和家庭中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101915: 人声鼎沸

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 很多人在一起，声音很大，很吵。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨六点半，菜市场里已人声鼎沸。
- sentences to write yourself: 9

## sense 101916: 人声鼎沸

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人很多，说话、喊叫的声音嘈杂，像水烧开了一样热闹。多用来描写集市、车站、会场等人多喧闹的场面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101917: 不卑不亢

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 对人有礼貌，不怕人，也不看低自己，很稳。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 讨价还价时，他们并不急于开口，而是先夸一句菜新鲜，再顺势问一句能不能便宜些，语气不卑不亢，分寸拿捏得恰到好处。
- sentences to write yourself: 9

## sense 101918: 不卑不亢

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人在与人交往时，态度既不低声下气，也不骄傲自大，言行得体，有分寸。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
