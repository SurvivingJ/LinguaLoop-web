# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0935`

Read `data/exercise_seeding/zh/wf2/r0935/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0935/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103343: 倒逼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 事情有压力，人就被逼着去做，改变自己。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种张力并非全然消极，它在一定程度上倒逼服务质量的提升，也促使各方逐步探索协商共治的路径。
- sentences to write yourself: 9

## sense 103344: 倒逼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指由结果或外部压力反过来推动前面的环节或相关方采取行动、作出改变。常用于说明某种压力迫使人或机构改革、改进。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103345: 缺位

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 该有的人或东西不在，位子空着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 二者的职责边界本就模糊，一旦小区出现停车混乱、公共空间被占用之类的问题，双方便容易相互推诿，指责对方越权或缺位。
- sentences to write yourself: 9

## sense 103346: 缺位

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指应该有人担任的职位或应该在场的人、事物没有出现，处于空着的状态；也比喻本应起作用的角色或责任没有到位。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 98614: 防护

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 防备并保护，使免受损害。
- learner tier: T3
- surface forms seen in tests: ["防护"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 当雾霾天气持续加重，气象部门发布预警后，居民应把健康防护放在优先位置。
  1. 此外，定期更换滤芯，并在空气质量好转时适度通风，才能让防护与舒适达到更好的平衡。
- sentences to write yourself: 8

## sense 98613: 防护

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 防护是做好准备，不让东西受到伤害。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
