# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0935`

Read `data/exercise_seeding/zh/wf2/r0935/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0935/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104019: 持续增长

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 一直变多，一直变大，不会停下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此外，活跃的开源社区不断贡献新的扩展，让这套工具的能力持续增长。
- sentences to write yourself: 9

## sense 104020: 持续增长

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指数量、规模、水平等在一段较长的时间里不断增加或变大，中间没有停止。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104023: 究其原因

- reading: (none)
- dictionary POS hint: v. The enum below wins over this hint.
- existing definition: 就是去找一件事为什么会这样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 究其原因，首先在于pandas提供了数据框这一直观的结构，它如同一张可编程的电子表格，行与列清晰分明，分析师只需寥寥数行代码，便能完成筛选、分组、合并与缺失值处理等繁琐操作。
- sentences to write yourself: 9

## sense 104024: 究其原因

- reading: (none)
- dictionary POS hint: v. The enum below wins over this hint.
- existing definition: 固定说法，意思是深入探究事情发生的原因，常用在句首，引出对某种结果或现象的原因的分析和说明。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104207: 标配

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 买东西时，不用再加钱，本来就有的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在数据分析领域，Python几乎成了从业者的“标配”，而pandas则是其中最受青睐的工具库。
- sentences to write yourself: 9

## sense 104208: 标配

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指产品出厂时就包含在基本价格里的配置或功能，不需要另外付费加装。也可指标准的配置。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
