# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0907`

Read `data/exercise_seeding/zh/wf2/r0907/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0907/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 92457: 站队

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 站队是一个一个排成一行站好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101409: 牢

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 牢表示很稳固，不容易忘记。
- learner tier: T3
- surface forms seen in tests: ["牢"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 上午的时间几乎都耗在这一环节，可她深知，地基不牢，再精美的图表也不过是空中楼阁。
  1. 唯有平台、监管部门与乘客三方共同发力，才能真正筑牢出行安全的防线。
- sentences to write yourself: 8

## sense 100941: 路段

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 路段是道路的一段。
- learner tier: T3
- surface forms seen in tests: ["路段"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
  1. 近年来，有关司机故意绕路、言语骚扰乃至侵害乘客的报道屡见不鲜，这类事件往往发生在深夜、偏僻路段或行驶轨迹明显异常的情况下，而乘客与司机彼此陌生，一旦遭遇危险，往往难以判断对方的真实意图，也难以及时求助。
- sentences to write yourself: 8

## sense 100942: 路段

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 路段指道路的一部分，通常指一段特定的道路。
- learner tier: T3
- surface forms seen in tests: ["路段"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老人、儿童以及呼吸道敏感者应减少不必要的户外活动；外出时，最好佩戴符合标准的口罩，并避开交通繁忙的时段和路段。
- sentences to write yourself: 9

## sense 103113: 监管部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 监管部门是管事情、查有没有做错的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 唯有平台、监管部门与乘客三方共同发力，才能真正筑牢出行安全的防线。
  1. 城市监管部门虽已尝试通过划定电子围栏、增设停车点、收取押金和信用分等方式加强管理，但由于车辆投放规模庞大、潮汐流动明显，单靠事后清理往往难以奏效。
- sentences to write yourself: 8

## sense 103114: 监管部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指政府或相关机构中负责监督和管理某个行业、领域或活动，检查是否遵守规定的部门。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
