# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0907`

Read `data/exercise_seeding/zh/wf2/r0907/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0907/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101487: 配送

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把东西送到别人那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
  1. 对消费者而言，这种模式同时缓解了价格与便利的双重焦虑——平台以预售制压缩库存风险，从而让出部分利润；省去最后一公里的配送成本，又使生鲜价格明显低于传统商超。
  2. 医生开具电子处方后，药品由合作的药房配送到家，部分费用还可通过医保在线结算，患者的经济负担随之减轻。
- sentences to write yourself: 7

## sense 102031: 疏离

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 疏离就是人和人离得远，不亲近，心里也不想靠近。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 更值得关注的是其社会效应：原本彼此疏离的现代邻里，因一次次取货时的寒暄而重新建立起最低限度的往来。
  1. 这种疏离未必是冷漠，更像是一种自我保护——毕竟下一次涨租，随时可能让人搬走。
- sentences to write yourself: 8

## sense 102032: 疏离

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指人与人之间关系冷淡、感情不亲近，彼此有距离感；也可指人与群体、环境之间缺少联系和融入感。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102627: 依附于

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 依附于就是靠着别的东西，才能活下去或者待着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 真正的职业安全感，从来不是依附于某个人而获得的，而是源于不可替代的能力与清晰的自我边界。
  1. 补偿与回迁方案固然提供了物质安置，却难以承接那些依附于具体地点的情感。
- sentences to write yourself: 8

## sense 102628: 依附于

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指某人或某事物不能独立存在，必须依靠、附着在另一个人或事物上，才能生存或发展。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 92458: 站队

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 按顺序排成队伍；比喻选择支持哪一方。
- learner tier: T3
- surface forms seen in tests: ["站队"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 许多新人天真地以为，只要把分内之事做到无可挑剔，与同事保持礼貌的距离，便能在组织中安然立足；然而现实是，当部门内部出现分歧，甚至形成隐形的派系时，"站队"的压力会悄然逼近每一个人。
  1. 真正的智慧或许不在于站队，而在于灵活调配：工作日以食堂为主，疲惫时以便当调剂，让省钱与健康在同一张餐桌上达成和解。
- sentences to write yourself: 8
