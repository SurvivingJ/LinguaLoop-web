# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0959`

Read `data/exercise_seeding/zh/wf2/r0959/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0959/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101163: 促销

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 促销就是让东西便宜一点，让更多人买。
- learner tier: T3
- surface forms seen in tests: ["促销"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 业务部门昨晚留言，希望了解新用户在促销期间的留存情况。
- sentences to write yourself: 9

## sense 104311: 精美

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 精美就是做得很好看，很细致，让人喜欢。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上午的时间几乎都耗在这一环节，可她深知，地基不牢，再精美的图表也不过是空中楼阁。
- sentences to write yourself: 9

## sense 104312: 精美

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容物品或作品制作得精细、美观，质量好，让人觉得漂亮。常用来形容礼物、图案、餐具、包装等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104313: 周报

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 周报是每星期出一次的报纸，或者每星期写一次的工作小结。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 临近傍晚，她着手撰写周报，把结论提炼成简明的文字，并配以直观的图表，使不懂技术的同事也能一目了然。
- sentences to write yourself: 9

## sense 104314: 周报

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指每周发行一次的报纸或刊物；也指每周向上级或团队提交的工作情况总结报告。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101245: 字段

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 字段是数据中的一种信息。
- learner tier: T3
- surface forms seen in tests: ["字段"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对分散在不同系统中的海量记录，她编写查询语句，逐一提取所需字段，并剔除重复和异常的数据。
- sentences to write yourself: 9
