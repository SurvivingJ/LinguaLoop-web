# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0959`

Read `data/exercise_seeding/zh/wf2/r0959/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0959/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104637: 地基

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 地基是房子最下面的一层，埋在地里，让房子站得稳。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上午的时间几乎都耗在这一环节，可她深知，地基不牢，再精美的图表也不过是空中楼阁。
- sentences to write yourself: 9

## sense 104638: 地基

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 建筑物最下面埋在地下的部分，用来承受整座建筑的重量，使建筑稳固；也可比喻事物发展的基础。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101583: 表述

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 说的话
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这类需求往往表述含糊，她必须先与对方反复沟通，弄清他们究竟想验证什么假设、需要精确到哪个时间粒度，否则后续工作极易南辕北辙。
- sentences to write yourself: 9

## sense 101585: 含糊

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 意思不清楚。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这类需求往往表述含糊，她必须先与对方反复沟通，弄清他们究竟想验证什么假设、需要精确到哪个时间粒度，否则后续工作极易南辕北辙。
- sentences to write yourself: 9

## sense 104231: 分析师

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 分析师是专门研究事情，再告诉大家结果的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨九点，数据分析师林岚打开电脑，第一件事不是埋头敲代码，而是梳理当天的待办事项。
- sentences to write yourself: 9

## sense 104232: 分析师

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指专门从事某一领域的资料研究和分析，并提出判断或建议的专业人员，常见于金融、市场、数据等行业。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
