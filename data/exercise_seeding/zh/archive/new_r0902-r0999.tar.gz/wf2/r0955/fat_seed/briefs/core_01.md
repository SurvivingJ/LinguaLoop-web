# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0955`

Read `data/exercise_seeding/zh/wf2/r0955/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0955/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104597: 令人信服

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 说得很好，让人相信。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 来源不明或无法核查的数字，即便看上去精确，也难以令人信服。
- sentences to write yourself: 9

## sense 104598: 令人信服

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容理由、证据或说法很有说服力，使人愿意相信、接受。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104601: 失业者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 失业者是没有工作的人，他们想工作，可是找不到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 例如同样是“失业率”，有的只统计登记失业者，有的则涵盖主动放弃求职的人群，口径不同，结果自然悬殊，若将二者直接对比，难免得出误导性的判断。
- sentences to write yourself: 9

## sense 104602: 失业者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指有工作能力并且想工作，但是失去了工作或一直找不到工作的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104604: 几十人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 表示二十到九十几个人左右的大概数目，比几个人多，比几百人少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 仅调查几十人就断言“大多数消费者满意”，显然以偏概全；即便样本量庞大，倘若对象集中于某一年龄段，结论依然有偏差。
- sentences to write yourself: 9

## sense 104603: 几十人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 几十个人，不是很多，也不是很少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
