# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0955`

Read `data/exercise_seeding/zh/wf2/r0955/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0955/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104163: 样本量

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 样本量就是我们拿来看的东西有多少个。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 再次是样本量与抽样方式。
  1. 仅调查几十人就断言“大多数消费者满意”，显然以偏概全；即便样本量庞大，倘若对象集中于某一年龄段，结论依然有偏差。
- sentences to write yourself: 8

## sense 104164: 样本量

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在调查或实验中抽取的样本的数目，样本量越大，结果通常越可靠。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104719: 以偏概全

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 只看到一小part就说是全部，这样想是不对的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 仅调查几十人就断言“大多数消费者满意”，显然以偏概全；即便样本量庞大，倘若对象集中于某一年龄段，结论依然有偏差。
- sentences to write yourself: 9

## sense 104720: 以偏概全

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 用部分现象或个别例子代替整体，得出片面的结论。多用来批评看问题不全面、以点带面的做法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104569: 摄像

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 摄像就是用机器把看到的人和事拍成会动的画面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 分析人员借助传感器和摄像系统，记录每次投篮的位置、防守距离和出手时机，再用统计模型加以比对。
- sentences to write yourself: 9

## sense 104570: 摄像

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用摄像机等设备把人物、景物拍摄下来，形成动态的影像，并可以录制或播放。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
