# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0951`

Read `data/exercise_seeding/zh/wf2/r0951/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0951/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103119: 盲道

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 盲道是马路上给看不见的人走的路，地上有一条一条的纹。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，共享单车在缓解短途出行压力、衔接公共交通方面发挥了积极作用，然而乱停乱放现象却不断侵蚀人行道、盲道和消防通道，使公共空间面临新的治理难题。
- sentences to write yourself: 9

## sense 103120: 盲道

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 铺设在人行道等公共场所地面上、带有凸起条纹或圆点的特殊道路，供视力障碍者用脚和盲杖感知方向，安全行走。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 94908: 助

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 帮助，给人支持。
- learner tier: T3
- surface forms seen in tests: ["助"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 94907: 助

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 助是帮别人一把。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 87792: 来不及

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 时间短促，无法顾及或完成。
- learner tier: T3
- surface forms seen in tests: ["来不及"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 头部主播并不急于罗列商品参数，而是先营造稀缺感：屏幕上的库存数字飞速递减，秒杀链接只开放三十秒，倒计时与助播的高声提醒交织在一起，观众根本来不及思考。
- sentences to write yourself: 9

## sense 87791: 来不及

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 来不及是时间太短，已经做不完了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
