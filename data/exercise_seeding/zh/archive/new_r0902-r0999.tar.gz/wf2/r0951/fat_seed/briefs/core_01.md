# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0951`

Read `data/exercise_seeding/zh/wf2/r0951/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0951/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103109: 扫码

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用手机对着一个小方块图案照一下，就能看到里面的内容。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一些用户为图方便，扫码后随意停放车辆，甚至将车堆放在小区门口、地铁出口和商圈周边，影响老人、儿童和残障人士通行。
- sentences to write yourself: 9

## sense 103110: 扫码

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用手机等设备扫描二维码或条形码，以获取信息、付款或登录等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103111: 堆放

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把很多东西一个一个放在一起，放得高高的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一些用户为图方便，扫码后随意停放车辆，甚至将车堆放在小区门口、地铁出口和商圈周边，影响老人、儿童和残障人士通行。
- sentences to write yourself: 9

## sense 103112: 堆放

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把东西一层层或一件件地放在一处，使它们聚集在一起，常常放得比较多、比较乱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103115: 单靠

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 只用一个人或一样东西，不要别的帮忙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 城市监管部门虽已尝试通过划定电子围栏、增设停车点、收取押金和信用分等方式加强管理，但由于车辆投放规模庞大、潮汐流动明显，单靠事后清理往往难以奏效。
- sentences to write yourself: 9

## sense 103116: 单靠

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 只依靠某一个人、某一种方法或某一方面的条件，没有别的帮助或补充，常用于说明这样做不够或不行。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
