# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0957`

Read `data/exercise_seeding/zh/wf2/r0957/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0957/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104759: 跳投

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 打篮球时，人跳起来，在空中把球投向篮筐。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 结果发现，三分线外的命中率虽然略低，但每次出手的期望得分却高于大多数中距离跳投。
- sentences to write yourself: 9

## sense 104760: 跳投

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 篮球运动中指运动员双脚起跳后，在空中把球投向篮筐的投篮方式，也指这样投出的一球。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104761: 三分球

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 打篮球时，在很远的线外投篮进了，就得三分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这一发现促使许多球队大幅增加三分球的尝试次数，减少低效的中投，进攻战术也因此围绕拉开空间和快速传球重新设计。
- sentences to write yourself: 9

## sense 104762: 三分球

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 篮球比赛中，球员在三分线外投篮并命中，得三分的投篮；也指这样的投篮方式。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104507: 分析阶段

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 分析阶段是把一件事拆开，仔细看一看、想一想的那段时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 午后，她转入分析阶段，通过对比不同用户群体的行为差异，寻找隐藏在数字背后的规律。
- sentences to write yourself: 9

## sense 104508: 分析阶段

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指做事或研究过程中，对资料、问题或情况进行拆分、研究、判断的阶段，常在收集信息之后、做出决定或制定方案之前。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
