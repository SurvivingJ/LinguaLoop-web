# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0957`

Read `data/exercise_seeding/zh/wf2/r0957/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0957/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104509: 深知

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 深知就是心里非常清楚，知道得很明白。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上午的时间几乎都耗在这一环节，可她深知，地基不牢，再精美的图表也不过是空中楼阁。
- sentences to write yourself: 9

## sense 104510: 深知

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 非常清楚地知道或了解，多指对道理、情况、困难等有深刻而透彻的认识。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104511: 埋头

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 埋头就是低下头，一心一意地做事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨九点，数据分析师林岚打开电脑，第一件事不是埋头敲代码，而是梳理当天的待办事项。
- sentences to write yourself: 9

## sense 104512: 埋头

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 低下头，专心致志地做某件事，不顾其他；也指不抬头、不关注周围。常与“苦干”“读书”“工作”等搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104514: 空中楼阁

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 原指悬在半空中的楼房，后比喻不切实际的想法、计划或脱离现实、没有基础的事物。常用来批评空想、不可能实现的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上午的时间几乎都耗在这一环节，可她深知，地基不牢，再精美的图表也不过是空中楼阁。
- sentences to write yourself: 9

## sense 104513: 空中楼阁

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 空中楼阁是天上的房子，其实没有，是假的，不能真的做到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
