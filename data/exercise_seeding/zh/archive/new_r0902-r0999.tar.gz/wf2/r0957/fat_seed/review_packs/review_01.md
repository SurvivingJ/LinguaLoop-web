# Fat-seed review 01 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0957`

Read `data/exercise_seeding/zh/wf2/r0957/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r0957/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r0957/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r0957/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r0957/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 104759: 跳投
- sense 104760: 跳投
- sense 104761: 三分球
- sense 104762: 三分球
- sense 104507: 分析阶段
- sense 104508: 分析阶段
