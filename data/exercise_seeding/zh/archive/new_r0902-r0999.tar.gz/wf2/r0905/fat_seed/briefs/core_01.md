# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0905`

Read `data/exercise_seeding/zh/wf2/r0905/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0905/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 86803: 肉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 肉是动物身上软软的、可以吃的部分。
- learner tier: T3
- surface forms seen in tests: ["肉"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 86804: 肉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人或动物体内附着在骨头上的柔软组织；供食用的这类组织。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100919: 留存

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 保留下来没有消失的东西
- learner tier: T3
- surface forms seen in tests: ["留存"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 业务部门昨晚留言，希望了解新用户在促销期间的留存情况。
  1. 一套科学的指标体系，应当紧扣企业的核心目标：若目标是扩大市场份额，就应关注新客户增长率与客户留存率；若目标是提升运营效率，则需要考察单位成本与交付周期。
  2. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
- sentences to write yourself: 7

## sense 99989: 客流

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 客流就是来买东西的人有多少
- learner tier: T3
- surface forms seen in tests: ["客流"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (6, keep verbatim, put first):
  0. 每逢春运，全国铁路、公路和航空客流都会在短时间内急剧攀升，给运输部门带来巨大压力。
  1. 时间序列分析正是其中常用的方法：它把按时间顺序记录的历史客流数据作为研究对象，从中提炼出内在规律。
  2. 把这些成分分离之后，模型便能更准确地捕捉到客流的变化节奏。
  3. 随着城市规模不断扩大，居民的出行需求日益多样，传统的公交线路规划往往依赖人工调查，样本有限、周期漫长，难以及时反映真实的客流变化。
  4. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
  5. 企业通过收集销售记录、顾客反馈与时段客流，经过分析后再调整排班。
- sentences to write yourself: 4

## sense 102979: 偏远地区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 偏远地区是离城市很远、人很少的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 这种模式的兴起，折射出医疗资源分布不均的深层矛盾：优质医师集中于大城市，而偏远地区的居民往往求医无门。
  1. 事实上，看病难不仅体现在挂号排队、专家难约，更体现在优质医疗资源过度集中于大城市，偏远地区的患者往往要辗转数小时才能看上专科门诊。
  2. 例如，某机构仅在网络上发布问卷，参与者往往以年轻人和熟悉互联网的人为主，老年人与偏远地区居民的意见几乎无从体现；又如电话访问若只拨打固定电话，也会遗漏大量只用手机的人。
- sentences to write yourself: 7

## sense 102980: 偏远地区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指远离城市和交通要道、交通不便、经济和生活条件相对落后的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
