# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0905`

Read `data/exercise_seeding/zh/wf2/r0905/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0905/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103461: 一盏灯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一盏灯就是一个会发光的灯。天黑了，它能让我们看得见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 许多室友从素不相识到逐渐熟悉，会分享家乡的食物，也会在对方加班时留一盏灯。
  1. 露营之所以风靡，恰恰因为它提供了一种"退一步"的自由：一顶帐篷、一盏灯、一炉炭火，就足以把城市里的焦虑暂时留在身后。
  2. 它把平日各扫门前雪的邻居重新聚到一处，让老人向孩子讲述旧时的规矩，也让外来者在一盏灯、一句谜面前，忽然觉得自己不再是过客。
- sentences to write yourself: 7

## sense 103462: 一盏灯

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个照明用的灯。“盏”是专门用来数灯的量词，“一盏灯”表示数量为一个灯，常用于说明屋里或路边有灯亮着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 91518: 例

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 可作依据或说明的事物；例子。
- learner tier: T3
- surface forms seen in tests: ["例"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 以某跨国企业研发的招聘筛选系统为例，工程师用过去十年的录用记录训练模型，而这些记录中男性占绝大多数。
  1. 以某城市的二手房数据为例，分析人员把房屋面积作为自变量，把成交价格作为因变量，然后将数百套房子的数据绘制在坐标图上。
- sentences to write yourself: 8

## sense 91517: 例

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 例是用来说明一件事的一个事情。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102069: 略显

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 略显就是有一点点显出来，但不太多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 然而，当甜品端上来时，期待感却悄然降温——造型虽美，奶油过于甜腻，饼底也略显潮湿。
  1. 奶奶揉面，母亲调馅，父亲擀皮，孩子们负责把那些形状略显笨拙的成品摆进竹筛——分工并不固定，却自有一种默契。
  2. 有趣的是，全家人对同一个节目的反应常常大相径庭：祖母笑得直抹眼泪，我却觉得台词略显陈旧，忍不住在手机上低声吐槽。
- sentences to write yourself: 7

## sense 102070: 略显

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 表示某种特征、状态或情绪稍微表现出来，程度不深，后面常接形容词或表示状态的词语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
