# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0952`

Read `data/exercise_seeding/zh/wf2/r0952/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0952/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104005: 拖入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西用力拉到一个地方里面去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 使用者只需选中原始数据区域，插入数据透视表，再把“地区”“产品”“月份”等字段分别拖入行、列和数值区域，系统便能在几秒钟内完成按不同维度的汇总，自动算出各地区、各产品的销售总额。
- sentences to write yourself: 9

## sense 104006: 拖入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把物体拉、拽或移动到某个范围、位置之中；在电脑操作中，也指用鼠标按住文件移到某个窗口或文件夹里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104185: 几秒钟

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 几秒钟就是很短很短的一小会儿，比一分钟还短。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 使用者只需选中原始数据区域，插入数据透视表，再把“地区”“产品”“月份”等字段分别拖入行、列和数值区域，系统便能在几秒钟内完成按不同维度的汇总，自动算出各地区、各产品的销售总额。
- sentences to write yourself: 9

## sense 104186: 几秒钟

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 表示很短的时间，指少数几秒，常用来强调事情发生得很快或所用时间很少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104187: 月度

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 月度是每个月的意思，一个月做一次或算一次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 正因如此，许多财务和销售人员在制作月度报表时，都将数据透视表视为不可或缺的工具，既提升了工作效率，又减少了人为失误，为管理层决策提供了可靠依据。
- sentences to write yourself: 9

## sense 104188: 月度

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 以月为单位的；每个月的。常用来修饰名词，如月度计划、月度报告、月度总结，表示按月进行或按月计算。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
