# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0952`

Read `data/exercise_seeding/zh/wf2/r0952/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0952/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101795: 精心设计

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 很用心地想好，再做出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 直播带货在双十一这样的购物节里，本质上是一场精心设计的心理博弈。
- sentences to write yourself: 9

## sense 101796: 精心设计

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指为了达到好的效果，事先花很多心思去构想、计划和设计，使事物细致、周到、巧妙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101797: 凑够

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 凑够就是一点一点把东西合起来，直到数目够了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 满减规则则被反复拆解成"每满三百减五十"这类便于口算的公式，一旦凑够金额，不买反而像是损失。
- sentences to write yourself: 9

## sense 101798: 凑够

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把零散的人、钱或东西聚集在一起，使数量达到所需要的数目。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104003: 销售总额

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 卖东西一共得到的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 使用者只需选中原始数据区域，插入数据透视表，再把“地区”“产品”“月份”等字段分别拖入行、列和数值区域，系统便能在几秒钟内完成按不同维度的汇总，自动算出各地区、各产品的销售总额。
- sentences to write yourself: 9

## sense 104004: 销售总额

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在一定时期内，企业或商店卖出商品或服务所得的全部金额，常用来衡量经营的规模和成绩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
