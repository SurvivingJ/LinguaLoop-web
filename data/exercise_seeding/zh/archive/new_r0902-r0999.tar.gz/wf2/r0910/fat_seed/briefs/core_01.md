# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0910`

Read `data/exercise_seeding/zh/wf2/r0910/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0910/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102321: 从何而来

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 问：这个东西是从哪里来的。就是问它最开始在哪里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 他们借由一针一线的仪式感，重新确认自己从何而来。
  1. 可见，读懂民意调查，不能只看数字本身，更要追问：样本从何而来，又是如何选出的？
- sentences to write yourself: 8

## sense 102322: 从何而来

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 询问事物、消息、想法、习惯等的来源或出处，也常用来反问对方某种说法或做法有什么根据。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100313: 取舍

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 决定要什么和不要什么
- learner tier: T3
- surface forms seen in tests: ["取舍"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这种取舍虽然令人无奈，却是保障居民基本生活用电的必要之举。
  1. 由此可见，预处理并非机械的技术操作，而是一场关于取舍的思辨。
- sentences to write yourself: 8

## sense 102557: 老房子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 老房子是住了很久、很旧的房子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 老房子管道老化，墙皮脱落，我原本以为只要提前跟邻居打个招呼，就能相安无事。
  1. 然而随着城市更新的推进，拆迁的告示贴上斑驳的砖墙，那些看似破败的老房子终究要退场。
- sentences to write yourself: 8

## sense 102558: 老房子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指建造年代较久、样子陈旧的房屋，有时也指有历史、有纪念意义的旧居。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100997: 罗列

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把事物一个一个列出来
- learner tier: T3
- surface forms seen in tests: ["罗列"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 头部主播并不急于罗列商品参数，而是先营造稀缺感：屏幕上的库存数字飞速递减，秒杀链接只开放三十秒，倒计时与助播的高声提醒交织在一起，观众根本来不及思考。
  1. 在她看来，这份工作的价值不在于罗列数字，而在于让数据开口说话，为决策提供可靠的依据。
- sentences to write yourself: 8
