# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0910`

Read `data/exercise_seeding/zh/wf2/r0910/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0910/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101673: 拆解

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把一样东西分成几块
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 满减规则则被反复拆解成"每满三百减五十"这类便于口算的公式，一旦凑够金额，不买反而像是损失。
  1. 分析人员通常将数据拆解为三个部分。
- sentences to write yourself: 8

## sense 101777: 居高不下

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 数字或价钱很高，一直降不下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 大促结束后居高不下的退货率恰好说明，下单那一刻的决定，更多是情绪而非真实需求的产物。
  1. 无论互联网、金融还是零售行业，都希望借助数据优化决策，对相关人才的需求居高不下。
- sentences to write yourself: 8

## sense 101778: 居高不下

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指价格、数量、温度、比率等一直保持在很高的水平，没有下降。多用于不希望数字太高的情况，如物价、房价、失业率等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103135: 正因如此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: “正因如此”是说：前面那件事，就是后面这件事发生的原因。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 正因如此，许多财务和销售人员在制作月度报表时，都将数据透视表视为不可或缺的工具，既提升了工作效率，又减少了人为失误，为管理层决策提供了可靠依据。
  1. 也正因如此，不少人将驾考看作对耐心与心态的双重考验：它衡量的不只是驾驶技术，更是一个人能否在压力之下保持冷静。
- sentences to write yourself: 8

## sense 103136: 正因如此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: 连接上下文的表达，用来强调前面所说的情况正是后面结果、做法或看法的原因，意思是“正是因为这样”。常放在句首，后面接结果。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101767: 各执一词

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 每个人都说自己的话，大家的想法不一样，谁也不听谁的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 双方各执一词，沟通几轮后陷入僵局。
  1. 业主们指责物业不作为，物业则声称自身并无执法权，双方各执一词，纠纷经年不断。
- sentences to write yourself: 8
