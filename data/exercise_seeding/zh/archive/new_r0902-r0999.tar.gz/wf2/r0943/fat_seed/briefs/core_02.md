# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0943`

Read `data/exercise_seeding/zh/wf2/r0943/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0943/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103749: 古镇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 古镇是有很多年历史的小镇，里面有老房子和老路。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 103750: 古镇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指历史悠久、保留着许多古代建筑和传统风貌的小城镇，常常是人们旅游参观的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103751: 袍

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 袍是一种又长又宽的衣服，穿在身上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多设计者在保留传统形制与纹样的同时，融入现代剪裁与日常化的面料，使宽袍大袖也能适应快节奏的都市生活。
- sentences to write yourself: 9

## sense 103752: 袍

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指长而宽松的中式长衣，也泛指某些长款外衣，如长袍、睡袍、浴袍、道袍等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103753: 佳节

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 佳节是很开心、很热闹的节日，比如春节。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 103754: 佳节

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指美好、令人愉快的节日，多用于春节、中秋节、重阳节等传统节日，常带有喜庆、祝福的意味，多用于书面语或祝福语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
