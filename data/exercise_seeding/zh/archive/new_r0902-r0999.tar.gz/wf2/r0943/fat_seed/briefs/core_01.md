# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0943`

Read `data/exercise_seeding/zh/wf2/r0943/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0943/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104055: 纹样

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 纹样就是画在东西上的好看的花样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多设计者在保留传统形制与纹样的同时，融入现代剪裁与日常化的面料，使宽袍大袖也能适应快节奏的都市生活。
- sentences to write yourself: 9

## sense 104056: 纹样

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指装饰在器物、织物、建筑等表面上的有规律的图案或花样，常有特定的形状、结构和文化含义。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104059: 一针一线

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 一针一线是说一根针、一条线，都很小，也很珍贵，要爱惜。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们借由一针一线的仪式感，重新确认自己从何而来。
- sentences to write yourself: 9

## sense 104060: 一针一线

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指一根针、一条线，比喻极少的东西或微小的物品，常用来强调爱惜、不浪费或不占公家、他人的便宜，也可指做事一点一滴、细致认真。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 96412: 潮

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 海水定时涨落的现象；也指像潮水一样的社会现象。
- learner tier: T3
- surface forms seen in tests: ["潮"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 96411: 潮

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 海水一会儿涨高，一会儿退下去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
