# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0911`

Read `data/exercise_seeding/zh/wf2/r0911/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0911/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104175: 误导性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 让人看错或想错，不知道真的是什么样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 例如同样是“失业率”，有的只统计登记失业者，有的则涵盖主动放弃求职的人群，口径不同，结果自然悬殊，若将二者直接对比，难免得出误导性的判断。
  1. 在商业汇报和新闻报道中，误导性图表屡见不鲜，其中最常见的手法便是截断纵轴。
- sentences to write yourself: 8

## sense 104176: 误导性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指说法、信息、标志等容易使人产生错误的理解或判断，把人引到错误的方向上，带有让人误会的性质。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101187: 逐一

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 一个一个地
- learner tier: T3
- surface forms seen in tests: ["逐一"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 面对分散在不同系统中的海量记录，她编写查询语句，逐一提取所需字段，并剔除重复和异常的数据。
  1. 在竞争日益激烈的零售行业，企业面临一个难题：客户数以百万计，却难以逐一了解他们的需求。
- sentences to write yourself: 8

## sense 100031: 拥堵

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 拥堵就是很多人或车挤在一起，走不了。
- learner tier: T3
- surface forms seen in tests: ["拥堵"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
  1. 若车辆能够移动且无人受伤，双方应尽快将车移至不妨碍交通的地方，避免造成拥堵。
- sentences to write yourself: 8

## sense 102633: 数以百万计

- reading: (none)
- dictionary POS hint: i. The enum below wins over this hint.
- existing definition: 说有很多很多，多到要用一百万来数，还不止一个一百万。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在竞争日益激烈的零售行业，企业面临一个难题：客户数以百万计，却难以逐一了解他们的需求。
  1. 数以百万计的劳动者告别了固定的工位，转而以零工的形式谋生——他们驾驶网约车穿行于大街小巷，在写字楼间递送餐食，或守在屏幕前等待派工。
- sentences to write yourself: 8

## sense 102634: 数以百万计

- reading: (none)
- dictionary POS hint: i. The enum below wins over this hint.
- existing definition: 形容数量极其庞大，多达好几个百万，常用来强调人或事物非常多，并不一定是准确的数字。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
