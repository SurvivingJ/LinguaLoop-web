# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0911`

Read `data/exercise_seeding/zh/wf2/r0911/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0911/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103779: 失真

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 失真就是和原来的样子不一样了，不再像真的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在描述一组数据的集中趋势时，人们习惯把平均数、中位数与众数当作可靠的答案，然而它们各自的敏感性并不相同，一旦数据的分布形态发生扭曲，结论便可能失真。
  1. 若直接把这些空缺当作零来处理，结论便会失真，因此分析者必须判断：究竟是舍弃整条记录，还是依据上下文推断出合理数值。
- sentences to write yourself: 8

## sense 103780: 失真

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指声音、图像、信息或事实在记录、传播或转述的过程中发生变化，与原来的样子不一致，不够真实、准确。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 97868: 口径

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 说话的口吻或所定的表述标准；也指器物的口的直径。
- learner tier: T3
- surface forms seen in tests: ["口径"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 其次要留意口径是否一致。
  1. 例如同样是“失业率”，有的只统计登记失业者，有的则涵盖主动放弃求职的人群，口径不同，结果自然悬殊，若将二者直接对比，难免得出误导性的判断。
  2. 确认口径后，她开始取数。
- sentences to write yourself: 7

## sense 97867: 口径

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 说话的方法，大家说的要一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104581: 反复推敲

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 一遍又一遍地想，把事情改得更好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 综合这些方面反复推敲，才不会被漂亮的数字牵着走。
  1. 在竞争激烈的零售行业，货架绝非随意摆放，而是数据反复推敲的结果。
- sentences to write yourself: 8

## sense 104582: 反复推敲

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指为了把文章、方案、决定等做得更好，一次又一次地认真思考、琢磨和修改。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
