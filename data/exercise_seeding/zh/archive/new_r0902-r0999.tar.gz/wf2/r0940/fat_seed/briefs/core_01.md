# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0940`

Read `data/exercise_seeding/zh/wf2/r0940/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0940/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103689: 流行语

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 流行语是很多人一段时间里都爱说的话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，语言的复杂性给分析带来了不小的挑战：反语、网络流行语和语境差异，常常使机器误判作者的真实意图。
- sentences to write yourself: 9

## sense 103690: 流行语

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在某一段时间内被许多人广泛使用、传播很快的词语或说法，常常来自网络、影视、歌曲或社会热点事件。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104353: 及时发现

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 很快就看见问题，没有等很久。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 企业和政府部门可据此监测舆情走向，及时发现潜在的危机。
- sentences to write yourself: 9

## sense 104354: 及时发现

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在问题、危险或变化刚出现、还没变严重的时候，很快就察觉到它。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99416: 放学

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 学校一天的课程结束，学生离校。
- learner tier: T3
- surface forms seen in tests: ["放学"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每天放学回家，莉莉都会把书包放在一边，然后跑到熊熊的身边，跟它分享学校里发生的一切。
- sentences to write yourself: 9

## sense 99415: 放学

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 放学就是学校里一天的课上完了，可以回家了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
