# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0940`

Read `data/exercise_seeding/zh/wf2/r0940/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0940/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 99420: 湖水

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 湖泊中的水。
- learner tier: T3
- surface forms seen in tests: ["湖水"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 熊熊的蓝色毛衣在莉莉的房间里，就像一片宁静的湖水，给莉莉带来了很多安慰和快乐。
- sentences to write yourself: 9

## sense 99419: 湖水

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 湖水就是湖里的水。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99424: 日夜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 白天和黑夜；也指日日夜夜，不分昼夜。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 它陪着莉莉长大，陪着她经历了无数个日夜。
- sentences to write yourself: 9

## sense 99423: 日夜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 日夜就是白天和晚上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101693: 垫付

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 别人没带钱，你先用自己的钱帮他给，以后他再还你。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 如今微信支付让这道难题有了折中的办法：一人先行垫付，随后在群里发起群收款，系统自动算出每人应付的份额，参与者只需轻点确认，钱款便悄然到账。
- sentences to write yourself: 9

## sense 101694: 垫付

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在应该由别人或某个单位付款的时候，自己先替他们付出钱款，以后再由对方偿还。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
