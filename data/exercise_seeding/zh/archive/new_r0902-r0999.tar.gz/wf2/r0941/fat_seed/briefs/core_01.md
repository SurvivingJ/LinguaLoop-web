# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0941`

Read `data/exercise_seeding/zh/wf2/r0941/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0941/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101695: 付账

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 买完东西后，把钱给店里的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人习惯抢着请客，把付账看作表达情谊的方式；也有人主张AA制，认为各付各的才清爽自在。
- sentences to write yourself: 9

## sense 101696: 付账

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在商店、饭馆等地方，把应该付的钱交给对方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101697: 收款

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 别人把钱给你，你把钱收下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 如今微信支付让这道难题有了折中的办法：一人先行垫付，随后在群里发起群收款，系统自动算出每人应付的份额，参与者只需轻点确认，钱款便悄然到账。
- sentences to write yourself: 9

## sense 101698: 收款

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指收取别人支付的钱款，多用于买卖、服务或还债等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101703: AA制

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 大家一起吃饭或玩，每个人自己给自己的那一份钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人习惯抢着请客，把付账看作表达情谊的方式；也有人主张AA制，认为各付各的才清爽自在。
- sentences to write yourself: 9

## sense 101704: AA制

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指聚餐、消费等活动中，费用由参加的人平均分摊，或各人付各人的那一份，不由某一个人全部负责。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
