# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0902`

Read `data/exercise_seeding/zh/wf2/r0902/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0902/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 85751: 用

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: “用”是拿一样东西来做事。
- learner tier: T3
- surface forms seen in tests: ["用"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (10, keep verbatim, put first):
  0. 公司用很多数据教软件。
  1. 人用软件时，要安全。
  2. 人类很早就开始利用自然的力量。
  3. 它和风车看起来有点像，但作用不同。
  4. 但经过不断创新，它变得越来越便宜，也更好用了。
  5. 未来，我们可能会用更多的清洁电力，减少对煤和石油的依赖。
  6. 做纺织品要用很多水。
  7. 水用多了，有些地方的人就没有干净水喝。
  8. 有些人用字母，有些人用数字。
  9. 几百年前，欧洲的作曲家用了新的记谱法。
- sentences to write yourself: 0

## sense 85752: 用

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，使物件、手段等发挥作用以达到目的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 95716: 清洗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用水等洗去脏东西。
- learner tier: T3
- surface forms seen in tests: ["清洗"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (9, keep verbatim, put first):
  0. 更重要的是，分析师可以把反复进行的清洗和统计步骤写成脚本，实现流程的自动化：每当新数据到来，只需运行脚本，就能在几分钟内得到结果，既避免了人工操作的疏漏，也使分析过程可以被复现和检验。
  1. 其基本流程大致如下：首先对评论进行清洗，剔除广告和重复内容；接着借助分词技术，把连续的句子切分成独立的词语，因为中文词与词之间没有天然的空格；然后提取关键词，并对照情感词典或训练好的模型，判断每条评论倾向于正面、负面还是中立。
  2. 但是，她的妈妈安慰她，并教她如何小心地清洗毛衣。
  3. 环保袋不仅能反复清洗、长期使用，还能承载更重的物品；可重复使用的水杯则让人们在通勤、上课和旅行时随时补水，避免频繁购买瓶装饮料。
  4. 其次是转换，数据工程师会对原始数据进行清洗、去重，统一日期和货币的格式，并依据业务逻辑计算出新的指标，以消除矛盾与冗余。
  5. 在任何数据分析工作开始之前，数据清洗都是一道无法绕过的关口。
  6. 清洗得过于激进，数据便失去原有的纹理；过于宽容，噪声又会淹没信号。
  7. 数据仓库主要存放经过清洗和整理的结构化数据，例如销售报表、财务记录等。
  8. 其次，Python凭借丰富的程序库，在数据清洗、统计建模和可视化方面发挥着重要作用。
- sentences to write yourself: 1

## sense 95715: 清洗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用水把东西洗干净。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 90682: 回忆

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 想起过去的事情。
- learner tier: T3
- surface forms seen in tests: ["回忆"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (10, keep verbatim, put first):
  0. 这件T恤不仅仅是一件衣服，它还承载着我很多美好的回忆。
  1. 它是一个毛绒玩具，一件蓝色的毛衣，更是一个承载着满满回忆的珍贵宝藏。
  2. 这只熊不仅仅是一个玩具，它承载着女孩的爱和回忆。
  3. 对我来说，它不仅仅是一件衣服，更是我生活中的一部分，承载着我的回忆和情感。
  4. 有时候，我会仔细地抚摸T恤上的猫的图片，回忆那些美好的时光。
  5. 我喜欢这件T恤，不仅仅是因为它的颜色和图案，更是因为它承载了很多美好的回忆。
  6. 它是我的“最喜欢的”衣服，因为它代表着舒适、快乐和珍贵的回忆。
  7. 这只毛绒玩具，承载着小明童年最美好的回忆。
  8. 这只熊不仅仅是一个玩具，它还承载了很多我的回忆。
  9. 它是我童年里不可缺少的一部分，也是我未来回忆里温暖的印记。
- sentences to write yourself: 0

## sense 90681: 回忆

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 回忆是想起以前发生过的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
