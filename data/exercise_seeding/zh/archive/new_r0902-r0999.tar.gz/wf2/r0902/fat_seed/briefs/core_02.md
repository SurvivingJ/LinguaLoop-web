# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0902`

Read `data/exercise_seeding/zh/wf2/r0902/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0902/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 85998: 分

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，使整体变成几部分；也指分配。
- learner tier: T3
- surface forms seen in tests: ["分"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (6, keep verbatim, put first):
  0. 过去，篮球教练主要依靠经验和直觉制定战术，球员的价值往往取决于得分多少。
  1. 结果发现，三分线外的命中率虽然略低，但每次出手的期望得分却高于大多数中距离跳投。
  2. 与此同时，球员评估的标准变得更加多元：除了得分，球队还关注防守贡献、无球跑动以及球员在场时球队的净胜分。
  3. 为了降低成本、加快进度，许多企业采用众包模式，将任务拆解后分发给世界各地的兼职者。
  4. 报酬按件计算，一条往往只值几分钱。
  5. 事实上，稳定与冒险之间并无高下之分。
- sentences to write yourself: 4

## sense 85997: 分

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: “分”是把一个东西分开，变成几个。
- learner tier: T3
- surface forms seen in tests: ["分"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 19991: 到

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 表示到达某个地点、时间或状态。
- learner tier: T3
- surface forms seen in tests: ["到"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (10, keep verbatim, put first):
  0. 她会告诉熊熊今天学了什么新词，和同学们玩了什么游戏，或者有没有遇到什么不开心的事。
  1. 人们看到这只穿着蓝色毛衣的泰迪熊，都会觉得它很特别。
  2. 它让熊感到温暖，也让女孩感到快乐。
  3. 每天，当女孩拥抱这只熊时，她都能感受到那份温暖和爱意。
  4. 我每次看到这个图案，都会觉得心情变好。
  5. 它让我感到很放松，很自在。
  6. 这件T恤的图案，那只微笑的小猫，也让我联想到很多关于快乐和友谊的东西。
  7. 每次看到它，我都会想起那些无忧无虑的日子，想起那些真心对我好的人。
  8. 我希望这件T恤能一直陪伴我，直到它变得非常非常旧，但即使那样，我也会把它好好收藏起来，作为一份美好的纪念。
  9. 在一个阳光明媚的下午，小明得到了一个特别的礼物。
- sentences to write yourself: 0

## sense 27568: 到

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从一个地方去另一个地方，或者时间到了。
- learner tier: T3
- surface forms seen in tests: ["到"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101701: 分寸

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 说话做事刚刚好，不过头，也不太少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (4, keep verbatim, put first):
  0. 请帖的寄送也讲究次序，父母一辈的至亲宜由家中长辈亲自登门相邀，同事与朋友则可托人转交，礼数上的分寸往往比形式本身更受重视。
  1. 当然，技术只能化解形式上的尴尬，真正的分寸仍取决于彼此的关系——若是多年至交，谁多付一点也不必计较；若是初识之人，账目清楚反倒是一种尊重。
  2. 看似只是指尖轻点，其中却暗藏着微妙的人情分寸。
  3. 在职场与家庭之中，微信早已取代电话成为日常沟通的主要渠道，然而不少人恰恰在这方寸屏幕前失了分寸。
- sentences to write yourself: 6

## sense 101702: 分寸

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指说话、做事时掌握的适当限度，既不过分也不不足，多指待人处事恰到好处的程度。常与“有”“没有”“把握”“掌握”等词搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
