# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0918`

Read `data/exercise_seeding/zh/wf2/r0918/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0918/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104326: 萌芽

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 本义指植物的种子长出嫩芽；常比喻新事物刚刚产生，还处在最初的阶段。可作名词，也可作动词。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104327: 仪表盘

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 仪表盘是汽车前面的一块板，上面有小表，能让人看到车跑得多快。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
- sentences to write yourself: 9

## sense 104328: 仪表盘

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指汽车、飞机等交通工具或机器上安装的面板，上面有速度表、油量表等各种仪表，用来显示设备运行的情况。也可指用图表集中展示数据的界面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100763: 刷新

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 刷新就是让页面上的信息变成最新的。
- learner tier: T3
- surface forms seen in tests: ["刷新"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 借助实时监控功能，订单量、转化率、库存周转等核心指标会随业务进展不断刷新，使团队得以及时捕捉细微的波动。
- sentences to write yourself: 9

## sense 101343: 报表

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 报表是写满数字和信息的表格。
- learner tier: T3
- surface forms seen in tests: ["报表"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
- sentences to write yourself: 9

## sense 101271: 摊子

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 摊子是在街上卖东西的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们的采购堪称一门学问：先绕场一周，把各摊位的报价默默记在心里，再折回来精挑细选；有人甚至把三家摊子的单价换算成每斤多少钱，力求一目了然。
- sentences to write yourself: 9
