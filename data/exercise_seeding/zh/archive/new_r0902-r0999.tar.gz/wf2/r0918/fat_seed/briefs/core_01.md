# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0918`

Read `data/exercise_seeding/zh/wf2/r0918/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0918/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104639: 周转

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 钱或东西转来转去，让人能够用上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 借助实时监控功能，订单量、转化率、库存周转等核心指标会随业务进展不断刷新，使团队得以及时捕捉细微的波动。
- sentences to write yourself: 9

## sense 104640: 周转

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指资金或物资在流通中不断转换、循环使用，也指资金一时不够用而需要调度、挪用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104641: 逐

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 逐是一个一个地、一步一步地。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104642: 逐

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 逐：按照顺序一个接一个地，一步一步地，常用于书面语，如“逐个”“逐步”“逐年”；也可表示追赶、驱赶，如“追逐”“驱逐”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100085: 成败

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 成功或失败
- learner tier: T3
- surface forms seen in tests: ["成败"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在竞争日益激烈的商业环境中，企业决策的速度与精度往往决定成败。
- sentences to write yourself: 9

## sense 104325: 萌芽

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 种子刚长出小小的嫩芽，也说新的东西刚开始出现。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更为关键的是预警机制：一旦某项指标超出预设的阈值，系统便会自动发出提示，提醒相关负责人排查原因、调整策略，从而把潜在的风险化解于萌芽状态。
- sentences to write yourself: 9
