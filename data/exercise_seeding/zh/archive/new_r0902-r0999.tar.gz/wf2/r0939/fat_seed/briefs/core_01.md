# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0939`

Read `data/exercise_seeding/zh/wf2/r0939/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0939/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101443: 误判

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 错误地判断
- learner tier: T3
- surface forms seen in tests: ["误判"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，语言的复杂性给分析带来了不小的挑战：反语、网络流行语和语境差异，常常使机器误判作者的真实意图。
- sentences to write yourself: 9

## sense 104537: 分词

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 分词就是把一句话分成一个一个的词。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其基本流程大致如下：首先对评论进行清洗，剔除广告和重复内容；接着借助分词技术，把连续的句子切分成独立的词语，因为中文词与词之间没有天然的空格；然后提取关键词，并对照情感词典或训练好的模型，判断每条评论倾向于正面、负面还是中立。
- sentences to write yourself: 9

## sense 104538: 分词

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把连续的汉字句子按照意思切分成一个个词语，也指语法中由动词变化而来、兼有动词和形容词作用的形式。常用于语言学习和计算机处理文字。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104539: 舆情

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 舆情就是很多人对一件事的看法和想法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 企业和政府部门可据此监测舆情走向，及时发现潜在的危机。
- sentences to write yourself: 9

## sense 104540: 舆情

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指公众对社会上发生的事件、政策或人物所表达的看法、态度和情绪，常指通过网络、媒体等渠道反映出来的民意。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104541: 空格

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 空格是字和字中间没有写字的一小块地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其基本流程大致如下：首先对评论进行清洗，剔除广告和重复内容；接着借助分词技术，把连续的句子切分成独立的词语，因为中文词与词之间没有天然的空格；然后提取关键词，并对照情感词典或训练好的模型，判断每条评论倾向于正面、负面还是中立。
- sentences to write yourself: 9
