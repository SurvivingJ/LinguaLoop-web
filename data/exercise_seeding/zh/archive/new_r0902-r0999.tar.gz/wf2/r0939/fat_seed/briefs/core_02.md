# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0939`

Read `data/exercise_seeding/zh/wf2/r0939/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0939/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104542: 空格

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指书写、打字或排版时，字符之间或行里留出的空白位置；也指表格、试卷上留出来供填写内容的空白处。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104669: 反语

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 反语就是说的话和心里想的意思正好相反。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，语言的复杂性给分析带来了不小的挑战：反语、网络流行语和语境差异，常常使机器误判作者的真实意图。
- sentences to write yourself: 9

## sense 104670: 反语

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指故意用与本意相反的话来表达真实意思的修辞方式，常用来讽刺、嘲讽或开玩笑。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104671: 复杂性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 复杂性就是事情很乱，有很多部分，不容易弄懂。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，语言的复杂性给分析带来了不小的挑战：反语、网络流行语和语境差异，常常使机器误判作者的真实意图。
- sentences to write yourself: 9

## sense 104672: 复杂性

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指事物结构、关系或情况由许多部分组成、相互关联，不容易理解或处理的性质。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99915: 轻点

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 轻轻地碰一下
- learner tier: T3
- surface forms seen in tests: ["轻点"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 如今微信支付让这道难题有了折中的办法：一人先行垫付，随后在群里发起群收款，系统自动算出每人应付的份额，参与者只需轻点确认，钱款便悄然到账。
- sentences to write yourself: 9
