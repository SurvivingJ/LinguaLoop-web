# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0925`

Read `data/exercise_seeding/zh/wf2/r0925/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0925/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102136: 寒暄

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人们见面时互相问候，说一些客套、轻松的话，如问候身体、谈谈天气等，用来表示友好、打开话题。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 93184: 断

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 长形的东西分成几段；中断。
- learner tier: T3
- surface forms seen in tests: ["断"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 93183: 断

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 断是一整条东西分成了两段。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89248: 过时

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 不再流行或不再适用。
- learner tier: T3
- surface forms seen in tests: ["过时"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多衣服只穿几次，就因为款式过时、面料单薄或质量不佳而被搁置。
- sentences to write yourself: 9

## sense 89247: 过时

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 过时是以前很新，现在已经旧了、不时兴了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100871: 核对

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 核对就是检查两样东西是不是一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9
