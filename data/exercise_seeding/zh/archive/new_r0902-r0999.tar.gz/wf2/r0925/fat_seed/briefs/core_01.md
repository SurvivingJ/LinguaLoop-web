# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0925`

Read `data/exercise_seeding/zh/wf2/r0925/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0925/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102033: 采买

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 采买就是去买东西，常常一次买很多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，社区团购迅速兴起，悄然重塑了城市家庭的日常采买方式。
- sentences to write yourself: 9

## sense 87229: 信誉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 信誉是大家觉得你说话算数，很可靠。
- learner tier: T3
- surface forms seen in tests: ["信誉"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当然，团长的权威高度依赖个人信誉，一旦品控失守，社群的黏性与复购率便会迅速瓦解，这或许正是该模式难以规模化扩张的隐忧。
- sentences to write yourself: 9

## sense 87230: 信誉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 在信用方面所获得的好名声和他人的信任。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102132: 取货

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指到约定的地点把已经订购或寄存的货物拿走，常用于网购、快递或商店提货的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更值得关注的是其社会效应：原本彼此疏离的现代邻里，因一次次取货时的寒暄而重新建立起最低限度的往来。
- sentences to write yourself: 9

## sense 102131: 取货

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 取货就是去把买好的东西拿回来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102135: 寒暄

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 见面时说几句客气的话，比如问你好不好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更值得关注的是其社会效应：原本彼此疏离的现代邻里，因一次次取货时的寒暄而重新建立起最低限度的往来。
- sentences to write yourself: 9
