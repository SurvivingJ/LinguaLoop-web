# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0936`

Read `data/exercise_seeding/zh/wf2/r0936/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0936/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102622: 演变成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指事物经过一段时间的发展变化，逐渐变成另一种状态、形式或性质，常用于描述由小到大、由简单到复杂或由好到坏的过程。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102623: 更晚

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 比现在或比别的时间再慢一点，再往后。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在这样的环境里，同事们不得不相互比较谁走得更晚，于是出现了“内卷”的现象：投入的时间越来越多，最终的回报却几乎没有增加。
- sentences to write yourself: 9

## sense 102624: 更晚

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指在时间上比某个时间点或某件事还要靠后，表示比已经较晚的时间还要晚。常作状语或定语，如“更晚的时候”“更晚到”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102733: 默认

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 没有人去改，就照原来的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，“996”逐渐从个别企业的内部规定，演变成一种被默认接受的行业惯例。
- sentences to write yourself: 9

## sense 102734: 默认

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在没有特别选择或设置的情况下，自动采用事先定好的方式或状态；也可指默默承认、不表示反对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100931: 借款人

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 借款人就是从银行借钱的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 过去，信贷员主要凭面谈和纸质材料判断借款人是否可靠，难免带有主观色彩。
  1. 如今，银行借助大数据构建信用评分体系：系统汇总借款人的收入、还款记录和负债比例，再通过统计模型换算成一个分数，分数越高，按期还款的可能性越大。
- sentences to write yourself: 8
