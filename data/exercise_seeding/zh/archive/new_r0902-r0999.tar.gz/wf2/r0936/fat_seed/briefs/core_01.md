# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0936`

Read `data/exercise_seeding/zh/wf2/r0936/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0936/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104209: 电子表格

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 电子表格是电脑里的表，可以用来写数字和算数。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 究其原因，首先在于pandas提供了数据框这一直观的结构，它如同一张可编程的电子表格，行与列清晰分明，分析师只需寥寥数行代码，便能完成筛选、分组、合并与缺失值处理等繁琐操作。
- sentences to write yourself: 9

## sense 104210: 电子表格

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一种在电脑上使用的软件或文件，由许多行和列组成的格子构成，可以输入、计算、整理和分析数据。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100895: 加班

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 在应该休息的时候还工作
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 每天早九点上班、晚九点下班、每周工作六天，长时间加班被包装成“奋斗”的美德，甚至成了衡量员工是否忠诚的隐性标准。
  1. 法律明确规定了每日和每月加班的上限，但在实际执行中，取证困难、担心失业等因素让许多人望而却步。
- sentences to write yourself: 8

## sense 102619: 劳动法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 劳动法是一种规矩，说老板和工人要怎么做，保护工人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对这种消耗，一部分年轻人选择“躺平”，用降低欲望、拒绝竞争的方式保护自己的生活；另一部分人则把《劳动法》当作武器，通过仲裁和诉讼要求企业支付加班费。
- sentences to write yourself: 9

## sense 102620: 劳动法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 规定劳动者和用人单位之间的权利与义务的法律，内容包括工作时间、工资、休息、安全和合同等，目的是保护劳动者的合法权益。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102621: 演变成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 慢慢变成别的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，“996”逐渐从个别企业的内部规定，演变成一种被默认接受的行业惯例。
- sentences to write yourself: 9
