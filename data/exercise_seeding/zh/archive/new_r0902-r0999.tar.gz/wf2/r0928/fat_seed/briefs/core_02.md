# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0928`

Read `data/exercise_seeding/zh/wf2/r0928/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0928/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 88941: 唯有

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 唯有是只有这一个。
- learner tier: T3
- surface forms seen in tests: ["唯有"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 唯有平台、监管部门与乘客三方共同发力，才能真正筑牢出行安全的防线。
- sentences to write yourself: 9

## sense 103281: 动向

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 动向就是人或事情正在怎么变化，要往哪里走。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 103282: 动向

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人或事物的活动、变化的方向和趋势，多指对情况发展变化的观察和了解。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103283: 屡见不鲜

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 这种事很多，大家看了很多次，一点也不觉得新奇。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，有关司机故意绕路、言语骚扰乃至侵害乘客的报道屡见不鲜，这类事件往往发生在深夜、偏僻路段或行驶轨迹明显异常的情况下，而乘客与司机彼此陌生，一旦遭遇危险，往往难以判断对方的真实意图，也难以及时求助。
- sentences to write yourself: 9

## sense 103284: 屡见不鲜

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容某种事物或现象经常出现，人们见得多了，已经不觉得新鲜、稀奇。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101205: 坦然

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 心里很平静，不害怕。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 过去，离婚常被视为难以启齿的事；如今，越来越多人承认，一段无法修复的关系，与其勉强维持，不如坦然结束。
- sentences to write yourself: 9
