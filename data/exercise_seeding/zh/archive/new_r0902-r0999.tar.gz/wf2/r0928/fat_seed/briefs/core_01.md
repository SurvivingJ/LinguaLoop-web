# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0928`

Read `data/exercise_seeding/zh/wf2/r0928/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0928/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103207: 筑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 筑就是盖房子、修路或修墙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103208: 筑

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，指修建、建造，多用于建筑物、道路、堤坝、墙等较大的工程，也可比喻建立某种基础。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103209: 切勿

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 切勿就是一定不要，是很重要的提醒。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 倘若遇到违规收费、故意绕路或其他不当行为，乘客切勿忍气吞声，而应保留录音、截图等证据，及时向平台投诉，情况严重时报警处理。
- sentences to write yourself: 9

## sense 103210: 切勿

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 副词，表示强烈劝阻或禁止，意思是“千万不要”“一定不要”，多用于书面语、告示或郑重的提醒，后面接动词或动词短语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103213: 安全隐患

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 安全隐患是藏起来的危险，以后可能会让人受伤。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 网约车为人们的出行带来了极大的便利，然而其背后潜藏的安全隐患却不容忽视。
- sentences to write yourself: 9

## sense 103214: 安全隐患

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指事物中暂时没有表现出来、但以后可能引起事故或伤害的危险因素，常用于检查场所、设备、食品等方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
