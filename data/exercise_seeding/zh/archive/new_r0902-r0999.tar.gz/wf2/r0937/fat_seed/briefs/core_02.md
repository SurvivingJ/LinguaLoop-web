# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0937`

Read `data/exercise_seeding/zh/wf2/r0937/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0937/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102743: 躺平

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 躺平就是不想再拼命，只过简单、轻松的日子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对这种消耗，一部分年轻人选择“躺平”，用降低欲望、拒绝竞争的方式保护自己的生活；另一部分人则把《劳动法》当作武器，通过仲裁和诉讼要求企业支付加班费。
- sentences to write yourself: 9

## sense 102744: 躺平

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 原指身体平躺；现多指年轻人面对高压力的竞争和生活，选择不再拼命努力，降低欲望，只求简单安稳的生活态度。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102837: 取证

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 取证就是去找东西，用来证明事情是真的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 法律明确规定了每日和每月加班的上限，但在实际执行中，取证困难、担心失业等因素让许多人望而却步。
- sentences to write yourself: 9

## sense 102838: 取证

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指调查人员或当事人搜集、提取能够证明事实的证据，常用于警方办案、法律诉讼或纠纷处理中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102839: 谈判桌上

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 谈判桌上是大家坐在桌子旁，用说话来商量事情的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 真正的改变，或许不在于个人的忍耐或逃避，而在于让规则重新回到谈判桌上。
- sentences to write yourself: 9

## sense 102840: 谈判桌上

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指双方或多方代表坐在桌边进行谈判的场合，常比喻通过协商、讨价还价来解决问题或争取利益的场面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
