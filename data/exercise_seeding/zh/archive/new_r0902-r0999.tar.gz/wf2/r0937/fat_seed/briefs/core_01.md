# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0937`

Read `data/exercise_seeding/zh/wf2/r0937/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0937/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102737: 忍耐

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 心里很难受，可是不哭不闹，一直等着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 真正的改变，或许不在于个人的忍耐或逃避，而在于让规则重新回到谈判桌上。
- sentences to write yourself: 9

## sense 102738: 忍耐

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把痛苦、不满或难受的感觉压在心里，不发作，不表现出来，坚持承受下去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102739: 美德

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 美德是好的品质，比如诚实、爱帮助别人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每天早九点上班、晚九点下班、每周工作六天，长时间加班被包装成“奋斗”的美德，甚至成了衡量员工是否忠诚的隐性标准。
- sentences to write yourself: 9

## sense 102740: 美德

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人身上值得称赞的好品质或好品行，如诚实、勤劳、善良、谦虚等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102741: 加班费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 下班后还做工作，公司多给的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对这种消耗，一部分年轻人选择“躺平”，用降低欲望、拒绝竞争的方式保护自己的生活；另一部分人则把《劳动法》当作武器，通过仲裁和诉讼要求企业支付加班费。
- sentences to write yourself: 9

## sense 102742: 加班费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指劳动者在规定的工作时间以外继续工作，用人单位按规定额外支付的报酬。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
