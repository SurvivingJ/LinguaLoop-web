# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0946`

Read `data/exercise_seeding/zh/wf2/r0946/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0946/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102951: 枯燥

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 没有意思，让人不想看，也不想做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种可视化的坚持，让枯燥的重复变得有意义——塑造身体的从来不是一时的决心，而是日复一日的自律。
- sentences to write yourself: 9

## sense 102952: 枯燥

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容事情或内容单调、没有趣味，让人觉得无聊，提不起兴趣。常用来形容工作、生活、课程、文章等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 94820: 激励

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 激发鼓励，使人振作起来去做事。
- learner tier: T3
- surface forms seen in tests: ["激励"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们在社交平台上打卡，记录体重与心情的变化，彼此激励，也彼此比较。
- sentences to write yourself: 9

## sense 94819: 激励

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 激励是说好话让人更想努力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103053: 汗水

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 汗水是人热了或用力时，从身上流出来的水。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 下班之后，越来越多的年轻人不再满足于宅在家里，而是走进健身房，用汗水对抗久坐带来的疲惫。
- sentences to write yourself: 9

## sense 103054: 汗水

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人在天热、运动或劳动时从皮肤上流出的液体，也常用来比喻付出的辛苦和努力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
