# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0946`

Read `data/exercise_seeding/zh/wf2/r0946/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0946/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103057: 私教

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 私教是只教你一个人的老师，常教你做运动。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了突破瓶颈，不少人选择聘请私教。
- sentences to write yourself: 9

## sense 103058: 私教

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 私人教练或私人教师的简称，指专门为个人提供一对一指导的人，多指健身教练，也可指一对一授课的老师。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 87514: 宅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 住所，住房，多指较大的住处。
- learner tier: T3
- surface forms seen in tests: ["宅"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 下班之后，越来越多的年轻人不再满足于宅在家里，而是走进健身房，用汗水对抗久坐带来的疲惫。
- sentences to write yourself: 9

## sense 87513: 宅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 宅是人住的房子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 89004: 常识

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一般人都应该知道的知识。
- learner tier: T3
- surface forms seen in tests: ["常识"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 缺乏统计常识的人，容易被片面的平均数或精心挑选的样本误导：一项只调查了五十名顾客的“全民调查”，结论显然不足为信。
- sentences to write yourself: 9

## sense 89003: 常识

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 常识是大家都应该知道的最简单的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
