# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0917`

Read `data/exercise_seeding/zh/wf2/r0917/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0917/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104385: 逐层

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 一层一层地，一层做完再做下一层。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，汇报应当先亮出结论，再用数据逐层佐证。
- sentences to write yourself: 9

## sense 104386: 逐层

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指按照层级或层次，一级一级地依次进行，不跳过中间环节。常用于审批、传达、落实、检查等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104515: 翻阅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 翻阅就是一页一页地翻开书来看。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
- sentences to write yourself: 9

## sense 104516: 翻阅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把书、杂志、文件等一页一页地翻开来看，多是随意地浏览，或为了查找某些内容。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104521: 全貌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 全貌就是一件事从头到尾整个的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
- sentences to write yourself: 9

## sense 104522: 全貌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指事物的整体面貌或全部情况，强调从各个方面看到的完整样子，常与“了解”“展现”“看到”等词搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
