# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0917`

Read `data/exercise_seeding/zh/wf2/r0917/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0917/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104517: 堆砌

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把很多东西一个一个放在一起，放得乱乱的、很多很多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一张清晰的折线图往往胜过十页表格，但图表务必简洁，突出重点，避免堆砌装饰。
- sentences to write yourself: 9

## sense 104518: 堆砌

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把许多东西胡乱地堆放在一起；多用来形容写文章时只是把很多好词句或材料凑在一起，没有真正的内容和条理，含贬义。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104233: 流失率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 流失率就是走掉的人或东西占全部的多少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与其说“某地区的客户流失率上升了八个百分点”，不如描述一位老客户如何因为配送延迟而转向竞争对手，再引出数据背后的成因。
- sentences to write yourself: 9

## sense 104234: 流失率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在一定时间内，客户、用户、人才、水土等离开或损失的数量占原来总数的比例，常用百分数表示。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104323: 亮出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西拿出来，让大家都看到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，汇报应当先亮出结论，再用数据逐层佐证。
- sentences to write yourself: 9

## sense 104324: 亮出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把东西突然拿出来或展示出来让别人看见，也可指明确表明自己的态度、立场或本领。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
