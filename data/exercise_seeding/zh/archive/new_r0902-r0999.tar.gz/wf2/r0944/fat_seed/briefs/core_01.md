# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0944`

Read `data/exercise_seeding/zh/wf2/r0944/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0944/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103755: 橱窗

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 商店靠街的大玻璃框，里面放着要卖的东西，路过的人能看见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 它不再是博物馆橱窗里僵硬的陈列品，也不是影视剧中虚构的想象，而是被年轻人主动穿进地铁、校园与咖啡馆的鲜活存在。
- sentences to write yourself: 9

## sense 103756: 橱窗

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 商店临街的一面用玻璃做成的展示空间，用来陈列商品或宣传品，供过路人观看，吸引顾客。也指学校、单位等设在墙上或街边、用来展示图片、通知的玻璃柜。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103757: 汉服

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 汉服是中国汉族人很久以前穿的衣服。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，汉服作为一种承载着深厚历史记忆的传统服饰，正以前所未有的姿态重返都市青年的日常生活。
  1. 而在更深层的意义上，年轻人对汉服的偏爱，实则是一种文化认同的自觉表达。
- sentences to write yourself: 8

## sense 103758: 汉服

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指中国汉族传统的服装，特点是交领、右衽、宽袖，用系带或腰带固定。近年来，很多人在节日或活动时穿汉服，以表达对传统文化的喜爱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103759: 而立

- reading: (none)
- dictionary POS hint: v. The enum below wins over this hint.
- existing definition: 而立是说人到了三十岁。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 103760: 而立

- reading: (none)
- dictionary POS hint: v. The enum below wins over this hint.
- existing definition: 指三十岁。出自《论语》中“三十而立”，意思是人到三十岁，能够在社会上站稳脚跟、有自己的事业和主见。常用来指三十岁左右的年纪。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
