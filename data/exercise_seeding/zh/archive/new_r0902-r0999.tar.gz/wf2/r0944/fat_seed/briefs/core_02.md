# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0944`

Read `data/exercise_seeding/zh/wf2/r0944/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0944/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103761: 形制

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 形制是东西的样子和大小。比如一个老杯子是什么形状，有多大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多设计者在保留传统形制与纹样的同时，融入现代剪裁与日常化的面料，使宽袍大袖也能适应快节奏的都市生活。
- sentences to write yourself: 9

## sense 103762: 形制

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指器物、建筑等的形状和结构样式，常用于介绍文物、建筑或器具的外形特点和规格。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103763: 陈列品

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 陈列品是摆出来给人看的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 它不再是博物馆橱窗里僵硬的陈列品，也不是影视剧中虚构的想象，而是被年轻人主动穿进地铁、校园与咖啡馆的鲜活存在。
- sentences to write yourself: 9

## sense 103764: 陈列品

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在博物馆、展览会或商店等地方摆放出来供人观看或挑选的物品。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103765: 发髻

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 发髻是把头发盘起来，在头上绕成的一个小团。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 103766: 发髻

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指把头发盘绕起来，在头顶或脑后挽成的结，多为旧时女子或传统装扮的发式。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
