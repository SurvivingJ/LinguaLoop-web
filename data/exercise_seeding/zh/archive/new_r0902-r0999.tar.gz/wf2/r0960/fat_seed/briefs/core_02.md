# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0960`

Read `data/exercise_seeding/zh/wf2/r0960/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0960/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104317: 简明

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 话不多，一听就懂，很容易看明白。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 临近傍晚，她着手撰写周报，把结论提炼成简明的文字，并配以直观的图表，使不懂技术的同事也能一目了然。
- sentences to write yourself: 9

## sense 104318: 简明

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容说话、写文章或做介绍时，内容简单清楚，不啰嗦，让人容易明白。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101289: 直观

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 容易看明白
- learner tier: T3
- surface forms seen in tests: ["直观"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 临近傍晚，她着手撰写周报，把结论提炼成简明的文字，并配以直观的图表，使不懂技术的同事也能一目了然。
- sentences to write yourself: 9

## sense 102887: 转入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从一个地方或一个队换到另一个地方或另一个队里去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 午后，她转入分析阶段，通过对比不同用户群体的行为差异，寻找隐藏在数字背后的规律。
- sentences to write yourself: 9

## sense 102888: 转入

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指从原来的地方、单位、账户或状态转到另一个中去，常用于转学、转账、转会、工作调动或进入新阶段。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 27344: 有

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 表示拥有，比如“我有一本书”。
- learner tier: T3
- surface forms seen in tests: ["有"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 小小的行动，也能对环境有积极的影响。
- sentences to write yourself: 9
