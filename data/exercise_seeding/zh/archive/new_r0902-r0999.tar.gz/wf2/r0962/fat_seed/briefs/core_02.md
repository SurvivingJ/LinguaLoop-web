# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0962`

Read `data/exercise_seeding/zh/wf2/r0962/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0962/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 96784: 凡是

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 副词，表示在某个范围内无例外。
- learner tier: T3
- surface forms seen in tests: ["凡是"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 事实上，凡是要求保密、催促转账、索取验证码的陌生来电，几乎无一例外都是圈套。
- sentences to write yourself: 9

## sense 96783: 凡是

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 所有的，只要是这一类都这样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103717: 远在他乡

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 人在很远的别的地方，不在家里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们冒充公安、银行职员或远在他乡的子女，谎称账户涉案、银行卡被盗刷，甚至编造车祸、住院等紧急情形，刻意制造令人窒息的紧张氛围，迫使受害者在慌乱中失去判断力。
- sentences to write yourself: 9

## sense 103718: 远在他乡

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 指人身处离家乡很远的陌生地方，不能和家人在一起，常带有思念家乡和亲人的感情。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103719: 步步为营

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 走一步，就先把这一步守好，再走下一步，这样不容易出错。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，针对老年人的电信诈骗愈发猖獗，骗子往往深谙老年人的心理弱点，以亲情为突破口，步步为营。
- sentences to write yourself: 9

## sense 103720: 步步为营

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容做事谨慎小心，每前进一步都先做好防备，稳稳地推进。也可指在对抗中一步一步地巩固阵地，逐渐向前推进。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
