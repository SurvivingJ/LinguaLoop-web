# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0962`

Read `data/exercise_seeding/zh/wf2/r0962/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0962/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103305: 定责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 出了事以后，弄清楚是谁的错，谁要负责。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 随后，当事人可拨打交警电话或通过交管平台申请在线处理，由交警根据现场证据和监控进行定责。
- sentences to write yourself: 9

## sense 103306: 定责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在出现事故或问题之后，通过调查和分析，确定由谁来承担责任。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103307: 可拨打

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 这个电话号码可以打，能打通。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 随后，当事人可拨打交警电话或通过交管平台申请在线处理，由交警根据现场证据和监控进行定责。
- sentences to write yourself: 9

## sense 103308: 可拨打

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指电话号码、热线等可以拨打，能够用来打电话联系，多用于通知或说明联系方式时。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103313: 警示牌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 警示牌是立在路边的牌子，告诉人们这里有危险，要小心。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 虽然碰撞较轻，但双方仍立即开启危险报警闪光灯，并在车后放置三角警示牌，防止二次事故。
- sentences to write yourself: 9

## sense 103314: 警示牌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 设置在有危险或需要特别注意的地方，用文字或图案提醒人们注意安全或遵守规定的牌子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
