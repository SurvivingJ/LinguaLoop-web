# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0945`

Read `data/exercise_seeding/zh/wf2/r0945/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0945/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103921: 剪影

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 剪影是只看得到黑色样子的图，像影子一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 103922: 剪影

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指只表现人或物的外形轮廓、内部没有细节的黑色图像，常用纸剪成或用光照出；也比喻对事物概况或大致样子的简要描写。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103923: 剪裁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 剪裁就是用剪刀把布剪成要用的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多设计者在保留传统形制与纹样的同时，融入现代剪裁与日常化的面料，使宽袍大袖也能适应快节奏的都市生活。
- sentences to write yourself: 9

## sense 103924: 剪裁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指按照需要把布料等裁剪成一定的形状；也比喻对材料或内容进行取舍和安排，使之更合适。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102389: 打理

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 打理就是把事情或东西弄好，让它整齐有序。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每逢传统佳节，城市公园与古镇街区便聚满了身着襦裙、马面裙的年轻人，他们精心打理发髻、执扇而立，只为在镜头前留下属于自己的东方剪影；这些照片经由社交平台不断传播，又迅速转化为一股不可忽视的国潮风潮。
- sentences to write yourself: 9

## sense 102390: 打理

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指照料、料理和管理某些事务或物品，使其保持整齐或正常运转，常用于生活、家务、店铺、生意、头发等方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
