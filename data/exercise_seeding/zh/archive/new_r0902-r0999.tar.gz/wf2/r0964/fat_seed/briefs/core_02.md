# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0964`

Read `data/exercise_seeding/zh/wf2/r0964/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0964/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104269: 沉睡

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 沉睡就是睡得很深很久，叫也叫不醒。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 完成客户分群之后，企业便可针对不同群体制定差异化的营销策略，例如向高频消费者推送会员权益，向沉睡客户发放唤醒优惠，从而在控制成本的同时提升转化率。
- sentences to write yourself: 9

## sense 104270: 沉睡

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 睡得很深很熟，不容易被叫醒；也比喻事物长时间处于不活跃、未被发现或未被唤醒的状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101325: 选取

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 从很多里面选出一些
- learner tier: T3
- surface forms seen in tests: ["选取"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其中，K均值算法应用最为广泛：分析人员先确定分组数量，算法随机选取若干中心点，再根据相似度把每位客户分配到最近的中心，并反复调整，直到分组趋于稳定。
- sentences to write yourself: 9

## sense 104438: 无须

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 表示没有必要、不需要，后面常接动词或小句，多用于书面语，相当于“不必”“不用”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 作为典型的无监督学习方法，聚类分析无须预先设定标签，算法会自行从数据中发现隐藏的规律。
- sentences to write yourself: 9

## sense 104437: 无须

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 无须的意思是不用，不必做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101367: 分组

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 把东西分成几个小组。
- learner tier: T3
- surface forms seen in tests: ["分组"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其中，K均值算法应用最为广泛：分析人员先确定分组数量，算法随机选取若干中心点，再根据相似度把每位客户分配到最近的中心，并反复调整，直到分组趋于稳定。
- sentences to write yourself: 9
