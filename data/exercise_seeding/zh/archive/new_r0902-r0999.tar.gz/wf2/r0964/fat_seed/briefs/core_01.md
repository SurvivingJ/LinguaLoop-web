# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0964`

Read `data/exercise_seeding/zh/wf2/r0964/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0964/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103969: 均值

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 均值就是把几个数加在一起，再平分，得到的那个数。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其中，K均值算法应用最为广泛：分析人员先确定分组数量，算法随机选取若干中心点，再根据相似度把每位客户分配到最近的中心，并反复调整，直到分组趋于稳定。
- sentences to write yourself: 9

## sense 103970: 均值

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一组数据的平均数，是把所有数相加后再除以数据个数得到的数，用来表示这组数据的一般水平。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104439: 趋于稳定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 以前会变来变去，现在慢慢不怎么变了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其中，K均值算法应用最为广泛：分析人员先确定分组数量，算法随机选取若干中心点，再根据相似度把每位客户分配到最近的中心，并反复调整，直到分组趋于稳定。
- sentences to write yourself: 9

## sense 104440: 趋于稳定

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指原来变化较大或不平静的事物，渐渐变得不再大起大落，慢慢稳定下来。常用于物价、情绪、局势、病情等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104441: 聚类分析

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 把很像的东西放在一堆，分成几堆，再看每一堆有什么样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 聚类分析为此提供了有效的思路，它能依据消费金额、购买频率和浏览偏好等数据，将特征相近的客户归入同一类别。
  1. 作为典型的无监督学习方法，聚类分析无须预先设定标签，算法会自行从数据中发现隐藏的规律。
- sentences to write yourself: 8

## sense 104442: 聚类分析

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一种数据分析方法，根据对象之间的相似程度，把它们分成若干类，使同一类的相似度高，不同类的差别大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
