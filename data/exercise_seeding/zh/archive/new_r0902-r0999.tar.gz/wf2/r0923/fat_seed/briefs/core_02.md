# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0923`

Read `data/exercise_seeding/zh/wf2/r0923/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0923/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101933: 全职

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 全职就是每天都要去上班，一整天都做这一份工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9

## sense 101934: 全职

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指在规定的全部工作时间内只做一份工作，不兼做其他事，也指这样的工作。常与“兼职”相对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101935: 货品

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 货品是商店里卖的东西，也是用来卖的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9

## sense 101937: 复购

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 买过的东西，又去买一次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101938: 复购

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指顾客在买过某种商品或服务之后，再次购买同一种商品或服务。常用于商业和网购方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99911: 群聊

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 群聊就是很多人一起说话的地方。
- learner tier: T3
- surface forms seen in tests: ["群聊"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其核心并非某项技术突破，而是一种以邻里关系为纽带的信任机制：团长多为小区内的全职妈妈或退休居民，她们凭借长期积累的熟人网络，在群聊中发布商品信息、统计订单，并将次日达的货品集中配送至自家楼下的自提点。
- sentences to write yourself: 9
