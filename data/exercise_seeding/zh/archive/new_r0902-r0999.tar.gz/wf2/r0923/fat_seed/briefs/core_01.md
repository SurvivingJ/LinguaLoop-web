# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0923`

Read `data/exercise_seeding/zh/wf2/r0923/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0923/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101871: 老主顾

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 老主顾是常常来同一家店买东西的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 摊主们大多心知肚明，遇上这样的老主顾，往往笑着抹去零头。
- sentences to write yourself: 9

## sense 101872: 老主顾

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指经常光顾同一家商店或同一个商家、长期购买其商品或服务的顾客。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101873: 精挑细选

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 选东西时，一个一个认真地看，只拿最好的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他们的采购堪称一门学问：先绕场一周，把各摊位的报价默默记在心里，再折回来精挑细选；有人甚至把三家摊子的单价换算成每斤多少钱，力求一目了然。
- sentences to write yourself: 9

## sense 101874: 精挑细选

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在许多事物中仔细地比较、反复地挑选，选出最好或最合适的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101875: 精打细算

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 花钱很小心，每一分钱都想好再用，不乱花。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 精打细算的背后并非吝啬，而是一代人对"节俭"二字近乎本能的敬畏。
- sentences to write yourself: 9

## sense 101876: 精打细算

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容在使用钱、物、时间或人力时仔细计算，尽量节省，不浪费。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
