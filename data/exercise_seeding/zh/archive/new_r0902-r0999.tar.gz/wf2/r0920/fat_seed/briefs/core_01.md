# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0920`

Read `data/exercise_seeding/zh/wf2/r0920/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0920/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102503: 酒席

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 酒席是很多人坐在一起吃饭喝酒的大饭桌，有好多菜。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 婚礼筹备中最令人费心的，往往不是酒席的档次，而是宾客名单的取舍。
- sentences to write yourself: 9

## sense 102504: 酒席

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指宴请客人的一桌或多桌酒菜，也指宴会，常用于婚礼、生日、庆祝等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102255: 司仪

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 司仪是在婚礼或大会上，告诉大家下一步做什么的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 司仪的作用则在于统筹全局，既要照顾长辈的体面，也要为年轻人留出轻松的氛围，让整场婚宴在热闹与庄重之间取得平衡。
- sentences to write yourself: 9

## sense 102256: 司仪

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 在婚礼、庆典、会议等仪式上负责主持、宣布程序并引导气氛的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102305: 亲疏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 亲疏是说人和人离得近还是远，关系好还是不好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 至于份子钱，明面上大家心照不宣，实则暗含一套约定俗成的尺度：亲疏远近、往来旧账，都在这只红包里悄然结算。
- sentences to write yourself: 9

## sense 102306: 亲疏

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人与人之间关系的亲近或疏远。常用于说明对待人时因关系远近而有所区别。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
