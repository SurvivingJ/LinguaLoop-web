# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0920`

Read `data/exercise_seeding/zh/wf2/r0920/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0920/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102307: 请帖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 请帖是一张小卡片，上面写着请你去玩或吃饭。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 请帖的寄送也讲究次序，父母一辈的至亲宜由家中长辈亲自登门相邀，同事与朋友则可托人转交，礼数上的分寸往往比形式本身更受重视。
- sentences to write yourself: 9

## sense 102308: 请帖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 邀请别人参加婚礼、宴会、生日会等活动时送出的帖子或卡片，上面写有时间、地点等信息。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102311: 暗含

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 话里或事里有一个意思，没有直接说出来，但是能让人想到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 至于份子钱，明面上大家心照不宣，实则暗含一套约定俗成的尺度：亲疏远近、往来旧账，都在这只红包里悄然结算。
- sentences to write yourself: 9

## sense 102312: 暗含

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指某种意思、情感、目的或信息没有明说出来，而是包含在话语、行为或事物之中，需要人去体会或推断。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102379: 礼数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 礼数是见人时要有的好规矩，比如问好、说谢谢。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 请帖的寄送也讲究次序，父母一辈的至亲宜由家中长辈亲自登门相邀，同事与朋友则可托人转交，礼数上的分寸往往比形式本身更受重视。
- sentences to write yourself: 9

## sense 102380: 礼数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指待人接物时应遵守的礼貌和规矩，也指表示尊敬的礼节和做法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
