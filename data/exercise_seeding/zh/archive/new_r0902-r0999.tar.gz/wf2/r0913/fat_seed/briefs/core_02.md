# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0913`

Read `data/exercise_seeding/zh/wf2/r0913/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0913/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102119: 表达方式

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 表达方式就是你用什么办法把想法说出来或写出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 毕竟，催婚的初衷是关心，而关心的表达方式本该更温和一些。
  1. 语言学者指出，方言承载着独特的词汇、语调与地方记忆，一旦年轻一代不再开口，许多表达方式便随之消失，而消失往往不可逆。
- sentences to write yourself: 8

## sense 102120: 表达方式

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人们说话、写作或通过动作、表情等传达思想感情时所采用的方法和形式，如直接表达、委婉表达、书面表达等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102283: 夹杂着

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 夹杂着就是一个东西里面混着别的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 原始数据往往来自多个渠道，格式不一，其中夹杂着大量缺失值——某些字段被遗漏，或记录者干脆留了空白。
  1. 于是喜庆的气氛里夹杂着沉默与争执，两代人之间的“代沟”在几句追问中显露无遗。
- sentences to write yourself: 8

## sense 102284: 夹杂着

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词短语，表示在一种主要的事物中混入另一种不同的事物，使二者同时存在，多指声音、情绪、语言、气味等混合在一起。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104171: 柱状图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 柱状图是用一根一根长短不同的柱子来比多少的图。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 问题的根源在于，柱状图依靠柱子的长度传达数量，长度本应与数值成正比；纵轴一旦被截断，视觉比例与真实比例便彻底脱节，读者的直觉也随之被误导。
  1. 倘若要比较不同类别之间的差异，例如各部门的季度销售额，柱状图最为直观，因为人眼对柱子高度的差别格外敏感。
- sentences to write yourself: 8

## sense 104172: 柱状图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一种用长方形柱子的高度或长度来表示数量大小，方便比较不同数据的统计图表。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
