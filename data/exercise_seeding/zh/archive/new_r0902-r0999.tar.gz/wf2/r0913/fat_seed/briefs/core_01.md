# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0913`

Read `data/exercise_seeding/zh/wf2/r0913/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0913/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104485: 脱敏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 脱敏是把名字、电话这些秘密的信息改掉或藏起来，别人就看不出是谁的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 数据脱敏是常见的第一道防线，即对姓名、身份证号、手机号等敏感信息进行遮蔽、替换或加密，使其无法直接指向具体个人。
  1. 经过脱敏处理后，这些记录能够勾勒出人群在不同时段、不同区域之间的流动轨迹，从而揭示通勤高峰期的主要出行走向。
- sentences to write yourself: 8

## sense 104486: 脱敏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指对敏感的个人信息进行技术处理，使其不能识别具体的个人，从而保护隐私；也指医学上让人对过敏原不再产生过敏反应。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 86972: 费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 做某事或使用某物所花的钱；费用。
- learner tier: T3
- surface forms seen in tests: ["费"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 经过反复权衡，她最终选择了一份月费适中、流量充足、合约期限较短的套餐。
  1. 于是我以此为切入点开始砍价，语气客气但态度明确：我可以当天上门自提，省下物流费和包装成本，希望对方让出两百元。
- sentences to write yourself: 8

## sense 86971: 费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 费是用掉的钱。做一件事，买一样东西，都要给出去一些钱，这些钱就是费。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 94264: 小镇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 规模较小的镇子。
- learner tier: T3
- surface forms seen in tests: ["小镇"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 比起在知名景点里人挤人，越来越多的人更愿意自驾前往车程两三小时的小镇，把脚步放慢。
  1. 中途还要在小镇转车，因为直达老家的车一天只有一班。
- sentences to write yourself: 8

## sense 94263: 小镇

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小镇是比城市小、人不多的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
