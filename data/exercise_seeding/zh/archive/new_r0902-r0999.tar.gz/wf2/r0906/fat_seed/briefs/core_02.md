# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0906`

Read `data/exercise_seeding/zh/wf2/r0906/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0906/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103712: 冗长

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容文章、讲话等篇幅过长，内容啰嗦，有很多不必要的部分，让人觉得厌烦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101981: 约定俗成

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 很多人长时间一起这样做，大家就都觉得这样对，成了大家的规矩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 至于份子钱，明面上大家心照不宣，实则暗含一套约定俗成的尺度：亲疏远近、往来旧账，都在这只红包里悄然结算。
  1. 劝酒并非单纯的饮酒行为，而是应酬中一套约定俗成的仪式：晚辈向长辈敬酒，下属向客户敬酒，杯沿要略低于对方的杯口，以显示尊重。
- sentences to write yourself: 8

## sense 101982: 约定俗成

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指某种做法或说法经过长期的社会实践，被大家普遍接受并遵守，成为公认的习惯或规矩，不是正式规定出来的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99954: 桌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一种家具，上面可以放置物品，通常有腿支撑。
- learner tier: T3
- surface forms seen in tests: ["桌"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 刷了半小时，我看中一张实木餐桌，卖家描述说九成新，成色几乎与新品无异，标价却只有原价的三分之一。
- sentences to write yourself: 9

## sense 99953: 桌

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 桌就是桌子，用来放东西的家具。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101083: 晚辈

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 晚辈是年纪小的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 至于"手气最佳"，本是系统随机分配的偶然结果，可在群聊的语境中，它常被赋予额外的意味：有人主动再发一个红包"接力"，有人以玩笑的口吻请运气好的人日后请客，一来一往之间，长辈与晚辈、同事与朋友的距离便被悄然拉近。
  1. 劝酒并非单纯的饮酒行为，而是应酬中一套约定俗成的仪式：晚辈向长辈敬酒，下属向客户敬酒，杯沿要略低于对方的杯口，以显示尊重。
- sentences to write yourself: 8
