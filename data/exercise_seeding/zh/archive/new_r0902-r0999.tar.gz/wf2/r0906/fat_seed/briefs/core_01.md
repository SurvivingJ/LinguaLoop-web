# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0906`

Read `data/exercise_seeding/zh/wf2/r0906/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0906/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104167: 折线图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 折线图是用点和线画成的图，线一会儿高一会儿低，让我们看出数字怎么变。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 一张清晰的折线图往往胜过十页表格，但图表务必简洁，突出重点，避免堆砌装饰。
  1. 倘若要呈现数据随时间变化的趋势，例如某城市一年来的气温起伏，折线图则更为合适，连续的线条能够清晰地展现上升与下降的走向。
- sentences to write yourself: 8

## sense 104168: 折线图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用线段把一个个数据点依次连接起来的统计图，常用来表示数量随时间变化的趋势，能直观看出上升、下降或波动。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101401: 转化率

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 转化率是买东西的人数除以来看的人数。
- learner tier: T3
- surface forms seen in tests: ["转化率"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 借助实时监控功能，订单量、转化率、库存周转等核心指标会随业务进展不断刷新，使团队得以及时捕捉细微的波动。
  1. 完成客户分群之后，企业便可针对不同群体制定差异化的营销策略，例如向高频消费者推送会员权益，向沉睡客户发放唤醒优惠，从而在控制成本的同时提升转化率。
- sentences to write yourself: 8

## sense 104519: 排查

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 一个一个地仔细看，找出有问题的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 更为关键的是预警机制：一旦某项指标超出预设的阈值，系统便会自动发出提示，提醒相关负责人排查原因、调整策略，从而把潜在的风险化解于萌芽状态。
  1. 管道可以按小时或按天定时执行，一旦某个环节出错，系统便会发出警报，提醒技术人员及时排查，从而保障数据的准确与可靠。
- sentences to write yourself: 8

## sense 104520: 排查

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 对某个范围内的人、物或地方逐一检查，以找出问题、隐患或可疑情况。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103711: 冗长

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 话太多，太长，听了让人觉得累。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 管理者无需逐份翻阅冗长的报表，只需浏览这块仪表盘，便能对业务全貌一目了然。
  1. 首要的一环是称呼：向长辈或上司发消息时不宜直呼其名，更不宜省略称谓，一句得体的"张老师""李经理"，往往比冗长的客套更能传递敬意。
- sentences to write yourself: 8
