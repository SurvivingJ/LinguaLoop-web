# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0958`

Read `data/exercise_seeding/zh/wf2/r0958/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0958/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104629: 提炼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把好东西从很多东西里挑出来，留下最好的部分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 临近傍晚，她着手撰写周报，把结论提炼成简明的文字，并配以直观的图表，使不懂技术的同事也能一目了然。
- sentences to write yourself: 9

## sense 104630: 提炼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从大量材料或事物中去掉没用的部分，取出精华或要点；也指通过加工使物质变得更纯。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104633: 弄清

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 弄清就是把不明白的事情查一查，问一问，最后弄明白。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这类需求往往表述含糊，她必须先与对方反复沟通，弄清他们究竟想验证什么假设、需要精确到哪个时间粒度，否则后续工作极易南辕北辙。
- sentences to write yourself: 9

## sense 104634: 弄清

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 通过调查、询问或思考，使原来不清楚的事情变得清楚明白；多接事情的原因、真相、情况等作宾语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104635: 粒度

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 粒度就是东西一粒一粒有多大。粒越小，粒度就越小。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这类需求往往表述含糊，她必须先与对方反复沟通，弄清他们究竟想验证什么假设、需要精确到哪个时间粒度，否则后续工作极易南辕北辙。
- sentences to write yourself: 9

## sense 104636: 粒度

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指颗粒的大小或粗细程度；也指在分析、处理问题时，内容被划分得细致或概括的程度。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
