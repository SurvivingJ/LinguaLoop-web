# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0958`

Read `data/exercise_seeding/zh/wf2/r0958/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0958/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104021: 语句

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 语句就是一句一句的话，由几个字词连在一起，能说清一个意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对分散在不同系统中的海量记录，她编写查询语句，逐一提取所需字段，并剔除重复和异常的数据。
- sentences to write yourself: 9

## sense 104022: 语句

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指由词语按照一定的语法规则组成的、能表达一定意思的话，可以是一个句子，也可以是几个连在一起的句子。多用于谈论文章或说话的内容和表达是否通顺、恰当。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104625: 业务部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 公司里做生意、卖东西或做事的小组。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 业务部门昨晚留言，希望了解新用户在促销期间的留存情况。
- sentences to write yourself: 9

## sense 104626: 业务部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指企业或机构中直接负责产品销售、客户服务、项目运作等具体经营工作的部门，区别于行政、财务、人事等后勤和管理部门。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104627: 待办

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 待办是还没有做，但是要做的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨九点，数据分析师林岚打开电脑，第一件事不是埋头敲代码，而是梳理当天的待办事项。
- sentences to write yourself: 9

## sense 104628: 待办

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指已经安排好、但还没有完成的事情，常用来修饰事项、任务、清单等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
