# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0934`

Read `data/exercise_seeding/zh/wf2/r0934/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0934/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103257: 由来已久

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 这件事很早以前就有了，到现在还在。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在许多城市的小区里，物业公司与居委会之间的摩擦由来已久。
- sentences to write yourself: 9

## sense 103258: 由来已久

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容某种事物、习惯或现象在很久以前就已经出现，并且一直延续到现在。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103259: 居中调停

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 两个人吵架时，有人站在中间帮他们和好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来的一个突出矛盾集中在维修资金与公共收益的支配上：部分业主质疑物业公司账目不清，遂联合成立业主委员会，希望通过集体谈判与依法维权来约束其行为；居委会则倾向于居中调停，避免因对立激化而影响社区稳定。
- sentences to write yourself: 9

## sense 103260: 居中调停

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指在双方发生争执或冲突时，站在中立的立场上从中劝解、协调，帮助双方化解矛盾、达成和解。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103261: 物业费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 住在小区里，每个月要给管理房子和院子的人交的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 前者受业主委托，负责安保、保洁与设施维护，并据此收取物业费；后者作为基层群众性自治组织，更多承担政策宣传、纠纷调解一类职能。
- sentences to write yourself: 9

## sense 103262: 物业费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 物业费是业主或住户定期交给物业公司的费用，用来支付小区的保洁、保安、绿化和公共设施维修等服务。一般按月、按季度或按年缴纳。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
