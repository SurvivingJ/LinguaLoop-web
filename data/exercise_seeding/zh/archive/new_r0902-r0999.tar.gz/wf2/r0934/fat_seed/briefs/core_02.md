# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0934`

Read `data/exercise_seeding/zh/wf2/r0934/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0934/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101753: 账目

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 账目就是把花了多少钱、收了多少钱写下来的记录。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来的一个突出矛盾集中在维修资金与公共收益的支配上：部分业主质疑物业公司账目不清，遂联合成立业主委员会，希望通过集体谈判与依法维权来约束其行为；居委会则倾向于居中调停，避免因对立激化而影响社区稳定。
- sentences to write yourself: 9

## sense 101265: 激化

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 让矛盾变得更厉害
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来的一个突出矛盾集中在维修资金与公共收益的支配上：部分业主质疑物业公司账目不清，遂联合成立业主委员会，希望通过集体谈判与依法维权来约束其行为；居委会则倾向于居中调停，避免因对立激化而影响社区稳定。
- sentences to write yourself: 9

## sense 103341: 全然

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 全然是一点儿也的意思，常和“不”一起用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种张力并非全然消极，它在一定程度上倒逼服务质量的提升，也促使各方逐步探索协商共治的路径。
- sentences to write yourself: 9

## sense 103342: 全然

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 副词，表示完全、一点儿不剩地，多用于否定句，常与“不、没、无”等搭配，强调程度彻底。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101295: 二者

- reading: (none)
- dictionary POS hint: 代词. The enum below wins over this hint.
- existing definition: 两个
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 二者的职责边界本就模糊，一旦小区出现停车混乱、公共空间被占用之类的问题，双方便容易相互推诿，指责对方越权或缺位。
- sentences to write yourself: 9

## sense 100821: 繁琐

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 事情很多，很麻烦。
- learner tier: T3
- surface forms seen in tests: ["繁琐"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 究其原因，首先在于pandas提供了数据框这一直观的结构，它如同一张可编程的电子表格，行与列清晰分明，分析师只需寥寥数行代码，便能完成筛选、分组、合并与缺失值处理等繁琐操作。
- sentences to write yourself: 9
