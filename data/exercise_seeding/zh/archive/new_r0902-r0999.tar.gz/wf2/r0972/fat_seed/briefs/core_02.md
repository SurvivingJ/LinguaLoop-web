# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0972`

Read `data/exercise_seeding/zh/wf2/r0972/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0972/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 89992: 购

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 买。
- learner tier: T3
- surface forms seen in tests: ["购"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 整个过程不到十分钟，我既省下了钱，也避免了网购家具难以预料的尺寸与色差问题。
- sentences to write yourself: 9

## sense 89991: 购

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 花钱把东西买回来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101779: 难以预料

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 很难先想到会怎样，不知道以后会发生什么。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 整个过程不到十分钟，我既省下了钱，也避免了网购家具难以预料的尺寸与色差问题。
- sentences to write yourself: 9

## sense 101780: 难以预料

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指事情的发展或结果很难事先估计或预测，充满不确定性。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101809: 划痕

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 东西被尖的东西划过，留下的一道细细的印子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我随即发消息询问，得知桌子是搬家前购置的，仅用过一年，桌角有一道浅浅的划痕。
- sentences to write yourself: 9

## sense 101810: 划痕

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 物体表面被尖锐或粗糙的东西划过后留下的细长痕迹。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
