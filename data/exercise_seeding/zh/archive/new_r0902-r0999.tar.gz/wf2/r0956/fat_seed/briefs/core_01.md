# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0956`

Read `data/exercise_seeding/zh/wf2/r0956/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0956/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104571: 临场

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 临场就是事情正在发生的时候，你人就在那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当然，数据并非万能，优秀的教练仍会把冷静的数字与临场判断结合起来。
- sentences to write yourself: 9

## sense 104572: 临场

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指亲身处在事情发生的现场，多指在考试、比赛、演出等场合的当时；常用来说明在当场的表现或应对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104574: 净胜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 体育比赛中指一方的得分或进球总数减去对方后多出的数目，常用来计算“净胜球”“净胜分”，在积分相同时用来排名次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与此同时，球员评估的标准变得更加多元：除了得分，球队还关注防守贡献、无球跑动以及球员在场时球队的净胜分。
- sentences to write yourself: 9

## sense 104573: 净胜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 净胜就是比赛里你得的分减去对方得的分，多出来的那几分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104575: 低效

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 做事很慢，做得很少，用了很多时间却没做成什么。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这一发现促使许多球队大幅增加三分球的尝试次数，减少低效的中投，进攻战术也因此围绕拉开空间和快速传球重新设计。
- sentences to write yourself: 9

## sense 104576: 低效

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指做事的效率低，花费的时间、人力或资源很多，但取得的成果很少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
