# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0956`

Read `data/exercise_seeding/zh/wf2/r0956/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0956/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104695: 投篮

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 投篮就是把球扔进高高的篮子里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 分析人员借助传感器和摄像系统，记录每次投篮的位置、防守距离和出手时机，再用统计模型加以比对。
- sentences to write yourself: 9

## sense 104696: 投篮

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 篮球运动中，运动员把球投向篮筐，想让球进入篮中得分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104697: 命中率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 命中率就是射中或做对的次数占全部次数的多少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 结果发现，三分线外的命中率虽然略低，但每次出手的期望得分却高于大多数中距离跳投。
- sentences to write yourself: 9

## sense 104698: 命中率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指射击、投篮、预测、搜索等行为中，成功命中的次数占总次数的比例，通常用百分数表示，用来衡量准确程度。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104757: 略低

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 比别的东西低一点点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 结果发现，三分线外的命中率虽然略低，但每次出手的期望得分却高于大多数中距离跳投。
- sentences to write yourself: 9

## sense 104758: 略低

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指程度、数量、水平等比另一个对象稍微低一些，差距不大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
