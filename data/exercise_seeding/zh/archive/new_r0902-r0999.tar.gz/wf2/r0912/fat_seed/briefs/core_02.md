# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0912`

Read `data/exercise_seeding/zh/wf2/r0912/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0912/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102111: 调配

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西或人分给不同的地方，让它们合适地用起来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 要想提前做好运力调配，就离不开科学的预测。
  1. 真正的智慧或许不在于站队，而在于灵活调配：工作日以食堂为主，疲惫时以便当调剂，让省钱与健康在同一张餐桌上达成和解。
- sentences to write yourself: 8

## sense 102112: 调配

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指根据需要对人员、物资、资金等进行安排和分配；也指把不同的颜料、药物、食材等按比例混合配制。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 86124: 收

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把外面的东西拿回来；接受；聚拢。
- learner tier: T3
- surface forms seen in tests: ["收"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我小心地洗它，也小心地收好它，希望它能穿很久。
- sentences to write yourself: 9

## sense 86123: 收

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 收是把东西拿回来放好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104091: 推断出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看到一些事情，想一想，就知道没人告诉你的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 因此，真正意义上的匿名化要求处理后的数据不能复原，也无法推断出特定个人。
  1. 若直接把这些空缺当作零来处理，结论便会失真，因此分析者必须判断：究竟是舍弃整条记录，还是依据上下文推断出合理数值。
- sentences to write yourself: 8

## sense 104092: 推断出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 根据已有的事实、线索或信息，经过思考和分析，得出某种结论或结果。常与具体的结论搭配使用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
