# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0912`

Read `data/exercise_seeding/zh/wf2/r0912/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0912/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102491: 辛劳

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 做事很累，很辛苦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 对许多上班族而言，年会既是犒劳自己一年的机会，也是一段辛劳的句点。
  1. 家庭内部若能保持坦诚沟通，让老人理解年轻一代的养育期待，同时让父母尊重祖辈的辛劳与经验，隔代抚养便能减少摩擦，转化为三代人共同成长的契机。
- sentences to write yourself: 8

## sense 102492: 辛劳

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指做事付出很多体力或精力，非常劳累辛苦。可作形容词，也可作名词，指辛苦的付出。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 95570: 校

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 学校的简称。
- learner tier: T3
- surface forms seen in tests: ["校"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (5, keep verbatim, put first):
  0. 这样的家校沟通本意是促进合作，却常常加重家长负担。
  1. 家校沟通需要更清晰的边界，让老师、家长和学生都能在合理范围内参与。
  2. 所谓学区房，指的是与优质对口学校划在同一片区的住宅。
  3. 家长相信，只要买下这里，孩子便能顺利入学，避开残酷的择校竞争。
  4. 多校划片、教师轮岗等举措陆续推行，对口学校不再意味着稳操胜券。
- sentences to write yourself: 5

## sense 95569: 校

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 学生上课的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104462: 提炼出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从大量材料、事物或内容中提取出精华、要点或有价值的部分。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 时间序列分析正是其中常用的方法：它把按时间顺序记录的历史客流数据作为研究对象，从中提炼出内在规律。
  1. 其核心是关联规则，即从大量交易中提炼出“买了甲的人往往也买乙”的规律。
- sentences to write yourself: 8

## sense 104461: 提炼出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从很多东西里把最有用的拿出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
