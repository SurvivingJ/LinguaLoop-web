# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0970`

Read `data/exercise_seeding/zh/wf2/r0970/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0970/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104389: 点赞

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 点赞就是在手机上按一下，告诉别人你喜欢他发的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种个性化推送的逻辑并不复杂：系统通过记录用户的浏览、停留和点赞行为，不断修正对其偏好的判断，并优先展示点击率较高的内容。
- sentences to write yourself: 9

## sense 104390: 点赞

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在社交网络上点击“赞”的标志，表示喜欢、认可或支持别人发布的内容；也可引申为公开夸奖、称赞某人或某事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104391: 契合

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 契合就是两样东西很合得来，放在一起正好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 推荐算法已经深深嵌入我们的日常生活：打开新闻客户端或短视频平台，首页呈现的内容往往恰好契合我们的兴趣。
- sentences to write yourself: 9

## sense 104392: 契合

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指两个事物之间相互符合、配合得很好，如想法、要求、性格、条件等彼此相合，没有矛盾。也可指事物之间紧密相合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104395: 点击率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一个东西被看的次数，和能看到它的人数比，数字越大，说明越多人去点它。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这种个性化推送的逻辑并不复杂：系统通过记录用户的浏览、停留和点赞行为，不断修正对其偏好的判断，并优先展示点击率较高的内容。
  1. 然而，平台以点击率作为核心指标，也埋下了隐患。
- sentences to write yourself: 8

## sense 104396: 点击率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指网页、广告、链接等内容被点击的次数与被展示的次数之比，通常用百分数表示，用来衡量内容对网民的吸引力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
