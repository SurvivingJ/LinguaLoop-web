# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0970`

Read `data/exercise_seeding/zh/wf2/r0970/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0970/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102531: 择校

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 选择自己想去的学校，不是按住家远近去上学。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 家长相信，只要买下这里，孩子便能顺利入学，避开残酷的择校竞争。
- sentences to write yourself: 9

## sense 102532: 择校

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指家长或学生不按照划片入学的规定，而是通过各种办法选择自己认为更好的学校就读。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102473: 轮岗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大家轮流换着做不同的工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 多校划片、教师轮岗等举措陆续推行，对口学校不再意味着稳操胜券。
- sentences to write yourself: 9

## sense 102474: 轮岗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在单位里让工作人员按一定时间轮流调换到不同的岗位上工作，以便锻炼能力或避免长期做同一件事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102475: 褪去

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 颜色、热度这些东西慢慢变少，直到没有了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有专家提醒，当学区房的光环褪去，房价或将回落，届时为它付出的代价，恐怕难以收回。
- sentences to write yourself: 9

## sense 102476: 褪去

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指颜色、热度、毛发、衣物等逐渐消失、退下或脱落；也可以比喻某种感觉或特征慢慢消失。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
