# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0915`

Read `data/exercise_seeding/zh/wf2/r0915/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0915/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 85755: 得

- reading: (none)
- dictionary POS hint: particle. The enum below wins over this hint.
- existing definition: “得”放在动作后面，用来说这件事做得怎么样。
- learner tier: T3
- surface forms seen in tests: ["得"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 打哈欠时，嘴巴张得很大，会吸进很多空气。
- sentences to write yourself: 9

## sense 85756: 得

- reading: (none)
- dictionary POS hint: particle. The enum below wins over this hint.
- existing definition: 结构助词，用在动词或形容词后面，连接表示结果、程度的补语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101711: 暗藏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西或想法藏起来，不让别人看见。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 看似只是指尖轻点，其中却暗藏着微妙的人情分寸。
  1. 这种状态看似自由，实则暗藏代价。
- sentences to write yourself: 8

## sense 101712: 暗藏

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把事物、感情、意图等隐蔽地藏在里面，不让人轻易发现；也指某处存在着不易察觉的东西或危险。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102581: 读研

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 读研就是大学读完后，再去学校学更多的知识。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 这背后，就业难是最直接的推力：当岗位竞争愈发激烈，许多毕业生选择用学历为自己增加筹码，希望通过读研延缓进入职场的压力。
  1. 为了筹措医药费，儿子不得不放弃外地的读研机会，回家找工作。
- sentences to write yourself: 8

## sense 102582: 读研

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指大学本科毕业后继续在学校学习，攻读硕士或博士学位，也就是读研究生。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
