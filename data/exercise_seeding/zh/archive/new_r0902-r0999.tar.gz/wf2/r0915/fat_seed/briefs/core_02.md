# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0915`

Read `data/exercise_seeding/zh/wf2/r0915/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0915/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104470: 勾勒

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用线条画出事物的轮廓；也指用简短的语言把事物的大致样子或情况描述出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 经过脱敏处理后，这些记录能够勾勒出人群在不同时段、不同区域之间的流动轨迹，从而揭示通勤高峰期的主要出行走向。
  1. 在大数据时代，我们的一举一动几乎都会被记录下来：购物偏好、出行轨迹、搜索记录，经过算法分析后，往往能勾勒出一个人的完整画像。
- sentences to write yourself: 8

## sense 104469: 勾勒

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 勾勒就是用几笔线把东西大概画出来，也可以是用几句话把事情大概说出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102869: 切换

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从这一个换到另一个。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 手机在通话、收发短信或切换基站时，会留下匿名的位置记录。
  1. 然而，当办公桌被搬进客厅，这种切换也随之消失。
- sentences to write yourself: 8

## sense 102870: 切换

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指从一种状态、方式、频道、画面或事物转换到另一种，常用于设备、程序、场景或角色的变化。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103499: 稍作

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 稍作就是只做一点点，时间很短。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 然而随着宣传深入和邻里相互提醒，多数人逐渐摸索出规律——在厨房并排放置两个容器，投放前稍作沥水，异味与蚊虫问题也随之缓解。
  1. 居民只需在摄像头前稍作停留，大门便会自动开启，既省去了随身携带卡片的麻烦，也在一定程度上降低了陌生人随意进入的风险。
- sentences to write yourself: 8

## sense 103500: 稍作

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 表示只做一点点、很短时间或很小程度的某个动作，后面常接动词，如“稍作休息”“稍作停留”“稍作准备”，多用于书面语或较正式的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
