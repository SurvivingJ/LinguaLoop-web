# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0954`

Read `data/exercise_seeding/zh/wf2/r0954/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0954/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103793: 稳稳

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 稳稳就是很稳，不会晃，也不会倒。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 偏态分布尤其容易制造错觉——在右偏的工资、房价数据中，平均数总被长尾拽向高处，而中位数依然稳稳停在多数人的位置上。
- sentences to write yourself: 9

## sense 103794: 稳稳

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 形容很稳当、不摇晃、不出差错的样子，也可表示做事把握十足，有时用作副词，表示牢牢地。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104357: 先验概率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 还没看到新消息以前，人们先猜一件事有多大可能发生。这个猜的可能就是先验概率。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 起初，我们依据已有经验形成的判断称为先验概率；吸收新证据后得出的修正结果，则称为后验概率。
- sentences to write yourself: 9

## sense 104358: 先验概率

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 概率论和统计学中的术语，指在没有获得新的证据或数据之前，根据已有的经验或知识，对某个事件发生可能性所作的估计。得到新信息后，人们可以用它来计算后验概率。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101775: 白纸黑字

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 白纸上写了黑字，就是写下来了，谁也不能说没有。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 她坦言，自己并不在意那几百元，真正令人失望的，是白纸黑字的规则被随意解释，消费者的信任也在一次次推诿中被消耗殆尽。
- sentences to write yourself: 9

## sense 101771: 相去甚远

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 两个东西差得很多，一点也不像。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 那位顾客在网上买了一件外套，收到后觉得颜色与图片相去甚远，于是在签收后的第五天提出七天无理由退货。
- sentences to write yourself: 9
