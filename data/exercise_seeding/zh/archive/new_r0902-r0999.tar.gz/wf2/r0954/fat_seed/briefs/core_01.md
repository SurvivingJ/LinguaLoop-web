# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0954`

Read `data/exercise_seeding/zh/wf2/r0954/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0954/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104109: 相当可观

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 很多，很大，让人觉得不错。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当少数极端值把整体拉高或拉低时，平均数会失去代表性：多数员工的月薪不过数千元，个别高管的巨额薪酬却使平均数看起来相当可观，此时中位数反而更接近真实处境。
- sentences to write yourself: 9

## sense 104110: 相当可观

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容数量、规模、程度等相当大或相当好，值得重视或称赞，常用于收入、成绩、规模、利润等方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104111: 长尾

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 长尾是说尾巴很长，也指很多不常见却一直有人要的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 偏态分布尤其容易制造错觉——在右偏的工资、房价数据中，平均数总被长尾拽向高处，而中位数依然稳稳停在多数人的位置上。
- sentences to write yourself: 9

## sense 104112: 长尾

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 本义指长长的尾巴；常用于“长尾理论”，指销量小、不热门但种类很多的商品或需求，加起来也能带来很大的市场份额。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103791: 中位数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 把一些数从小到大排好，站在最中间的那个数就是中位数。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (3, keep verbatim, put first):
  0. 在描述一组数据的集中趋势时，人们习惯把平均数、中位数与众数当作可靠的答案，然而它们各自的敏感性并不相同，一旦数据的分布形态发生扭曲，结论便可能失真。
  1. 当少数极端值把整体拉高或拉低时，平均数会失去代表性：多数员工的月薪不过数千元，个别高管的巨额薪酬却使平均数看起来相当可观，此时中位数反而更接近真实处境。
  2. 偏态分布尤其容易制造错觉——在右偏的工资、房价数据中，平均数总被长尾拽向高处，而中位数依然稳稳停在多数人的位置上。
- sentences to write yourself: 7

## sense 103792: 中位数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 统计学中指把一组数据按大小顺序排列后，位于正中间的那个数；如果数据个数是偶数，则取中间两个数的平均值。它常用来表示一组数据的一般水平。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
