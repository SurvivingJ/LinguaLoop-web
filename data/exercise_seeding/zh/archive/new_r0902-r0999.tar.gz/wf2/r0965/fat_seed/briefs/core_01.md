# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0965`

Read `data/exercise_seeding/zh/wf2/r0965/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0965/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102641: 不菲

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 很多很贵，说钱或东西的价值很大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 抽奖环节无疑是最牵动人心的部分，从实用的电子产品到价值不菲的旅游券，奖品依次揭晓，台下不时爆发出欢呼声。
- sentences to write yourself: 9

## sense 102642: 不菲

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容数量或价值相当可观，多用来形容收入、价格、财产、报酬等数额很大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102645: 灯火通明

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 到处都亮着很多灯，非常亮。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 会场被布置得灯火通明，长桌上摆满了水果与酒水。
- sentences to write yourself: 9

## sense 102646: 灯火通明

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容灯光又多又亮，到处一片明亮的景象，多用来描写夜晚的城市、房屋或场所。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102767: 年终奖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 年底时，公司多给工人的一笔钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 员工们谈论得最多的，莫过于年终奖的数额。
- sentences to write yourself: 9

## sense 102768: 年终奖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指公司或单位在一年结束时，根据员工一年的工作表现或公司的收入，额外发给员工的一笔奖金。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
