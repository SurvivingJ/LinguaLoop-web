# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0965`

Read `data/exercise_seeding/zh/wf2/r0965/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0965/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102769: 牵动人心

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 让很多人心里很关心，放不下。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 抽奖环节无疑是最牵动人心的部分，从实用的电子产品到价值不菲的旅游券，奖品依次揭晓，台下不时爆发出欢呼声。
- sentences to write yourself: 9

## sense 102770: 牵动人心

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容某件事或某个人让许多人非常关注、担心或感动，使大家的心情跟着变化。多用于重大事件、感人的故事或紧张的情况。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102771: 捧腹

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 捧腹是笑得很厉害，肚子都笑疼了，要用手抱着肚子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与抽奖的热闹形成鲜明对比的，是各部门精心排练的表演节目——有人唱歌，有人跳舞，还有人把办公室里的趣事改编成小品，引得众人捧腹。
- sentences to write yourself: 9

## sense 102772: 捧腹

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 双手捧着肚子，形容笑得非常厉害，常与“大笑”连用，如“捧腹大笑”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102873: 趣事

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 趣事是让人觉得好玩、好笑的事情。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与抽奖的热闹形成鲜明对比的，是各部门精心排练的表演节目——有人唱歌，有人跳舞，还有人把办公室里的趣事改编成小品，引得众人捧腹。
- sentences to write yourself: 9

## sense 102874: 趣事

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指有趣的、令人觉得愉快好玩的事情或经历，常用来讲述生活、旅行、学习中发生的让人发笑或印象深刻的小故事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
