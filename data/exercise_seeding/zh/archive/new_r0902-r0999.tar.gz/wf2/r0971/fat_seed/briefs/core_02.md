# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0971`

Read `data/exercise_seeding/zh/wf2/r0971/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0971/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104478: 在实践中

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 指在实际做事或应用的过程中，强调不只是想或说，而是真正去做、去用。常用来说明理论要经过实际行动来检验或学习。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104479: 随机编码

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 随机编码就是用没有规律的办法，把东西变成一些记号。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 例如，某医院向高校提供病历用于研究前，会先将患者姓名替换为随机编码，并把出生日期模糊为年龄段。
- sentences to write yourself: 9

## sense 104480: 随机编码

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在编码过程中按照随机的方式生成或分配代码，使代码之间没有固定的规律，不容易被人猜到或预测，常用于数据保密、实验设计和信息处理。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104481: 标识符

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 标识符是一个记号，用来给东西起名字，让人能认出它。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，仅仅删除标识符并不意味着万无一失。
- sentences to write yourself: 9

## sense 104482: 标识符

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 标识符指在计算机程序中用来给变量、函数等命名的符号或名称，也泛指用来标明和区分事物的符号。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 92841: 争

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 争是大家都想要同一样东西，抢着要。
- learner tier: T3
- surface forms seen in tests: ["争"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更深层的矛盾在于：若大规模推广生物基塑料，可能引发与粮争地、水资源消耗等新的生态伦理问题。
- sentences to write yourself: 9
