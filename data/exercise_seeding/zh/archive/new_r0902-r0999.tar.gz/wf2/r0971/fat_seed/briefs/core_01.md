# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0971`

Read `data/exercise_seeding/zh/wf2/r0971/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0971/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102477: 费尽周折

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 做一件事很难，试了很多办法，花了很多力气，才做成。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多家庭倾尽积蓄，甚至卖掉宽敞的新居，只为换一间几十平方米的老屋，还要费尽周折把户口迁入。
- sentences to write yourself: 9

## sense 102478: 费尽周折

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容为了完成某件事，经历了许多曲折和麻烦，花费了很大的力气和很多的时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102351: 稳操胜券

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 意思是一定会赢，很有把握。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 多校划片、教师轮岗等举措陆续推行，对口学校不再意味着稳操胜券。
- sentences to write yourself: 9

## sense 102352: 稳操胜券

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容对事情很有把握，一定能成功或取得胜利，就像胜利的凭证已经握在手里一样。多用于比赛、竞争或考试等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 90129: 查

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 查是去看,去找,弄清楚。
- learner tier: T3
- surface forms seen in tests: ["查"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104477: 在实践中

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 就是真的去做事的时候。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在实践中，机构还需遵循相关法规，建立严格的审批与审计制度，确保每一次共享都符合合规要求。
- sentences to write yourself: 9
