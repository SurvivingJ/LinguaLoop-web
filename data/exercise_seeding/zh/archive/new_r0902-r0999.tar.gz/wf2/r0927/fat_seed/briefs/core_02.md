# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0927`

Read `data/exercise_seeding/zh/wf2/r0927/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0927/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103146: 防线

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指为防御敌人进攻而构筑或布置的一整条防御阵地；也比喻为防止不好的事发生而设立的保护措施或最后的底线。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103147: 靠右

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 靠右就是走在右手那一边。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与此同时，应尽量选择后排靠右的座位，与司机保持适当距离，避免透露过多个人信息。
- sentences to write yourself: 9

## sense 103148: 靠右

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指沿着道路、通道或空间的右侧行走、站立或停放，也指位置偏向右边。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103153: 绕路

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 绕路就是不走近的路，走远一点的路。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，有关司机故意绕路、言语骚扰乃至侵害乘客的报道屡见不鲜，这类事件往往发生在深夜、偏僻路段或行驶轨迹明显异常的情况下，而乘客与司机彼此陌生，一旦遭遇危险，往往难以判断对方的真实意图，也难以及时求助。
  1. 倘若遇到违规收费、故意绕路或其他不当行为，乘客切勿忍气吞声，而应保留录音、截图等证据，及时向平台投诉，情况严重时报警处理。
- sentences to write yourself: 8

## sense 103154: 绕路

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 因为前面有障碍或不能通行，不走最直接的路，而改走较远的路。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101665: 理应

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 应该
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 面对这些风险，乘客理应主动采取防范措施。
- sentences to write yourself: 9
