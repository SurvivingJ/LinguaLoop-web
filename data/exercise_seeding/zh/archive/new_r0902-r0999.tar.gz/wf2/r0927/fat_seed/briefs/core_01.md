# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0927`

Read `data/exercise_seeding/zh/wf2/r0927/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0927/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 87234: 预计

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 事先计算或估计。
- learner tier: T3
- surface forms seen in tests: ["预计"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 87233: 预计

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 预计是事情还没有发生，先想一想大概会怎样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 91843: 借助

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 借助是靠别的东西帮忙做成事。
- learner tier: T3
- surface forms seen in tests: ["借助"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 103143: 行车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 行车就是开车，也指车在路上走。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 上车之前，务必核对车牌号与司机信息是否与软件显示的一致；行车途中，可借助平台的行程分享功能，把实时位置和预计到达时间发送给家人或朋友，让他人随时掌握自己的动向。
- sentences to write yourself: 9

## sense 103144: 行车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指驾驶车辆行驶，或车辆在道路上行驶；也指工厂里在高处移动、用来吊运重物的起重设备。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103145: 防线

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 防线是用来挡住坏人或敌人的一排地方，不让他们过来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 唯有平台、监管部门与乘客三方共同发力，才能真正筑牢出行安全的防线。
- sentences to write yourself: 9
