# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0932`

Read `data/exercise_seeding/zh/wf2/r0932/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0932/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102334: 期满

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 规定或约定的期限已经到了，比如合同、任期、假期、刑期等到了终点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102335: 离婚证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 离婚证是一张小本子，上面写着两个人不再是夫妻了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照规定，双方若协议离婚，须先提交申请，此后三十天内任何一方都可以撤回；期满还须共同到场，方能领取离婚证。
- sentences to write yourself: 9

## sense 102336: 离婚证

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 国家有关部门发给已经依法解除婚姻关系的双方的证件，用来证明两人不再是夫妻。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102337: 任何一方

- reading: (none)
- dictionary POS hint: pronoun. The enum below wins over this hint.
- existing definition: 两边里的哪一边都可以，只要是其中一边就行。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照规定，双方若协议离婚，须先提交申请，此后三十天内任何一方都可以撤回；期满还须共同到场，方能领取离婚证。
- sentences to write yourself: 9

## sense 102338: 任何一方

- reading: (none)
- dictionary POS hint: pronoun. The enum below wins over this hint.
- existing definition: 指涉及的双方或多方中的随便哪一方，强调不论是哪一个都可以，常用于条件、规定或否定句中，如“任何一方不同意就不能签约”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100295: 留出

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 留出就是空出来，不占用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 正是在这样的背景下，离婚冷静期应运而生——它并非要阻止人们结束婚姻，而是为冲动的决定留出一点缓冲的余地。
- sentences to write yourself: 9
