# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r0932`

Read `data/exercise_seeding/zh/wf2/r0932/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r0932/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102217: 余地

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 余地就是还能改变、还能选的空间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 正是在这样的背景下，离婚冷静期应运而生——它并非要阻止人们结束婚姻，而是为冲动的决定留出一点缓冲的余地。
- sentences to write yourself: 9

## sense 102218: 余地

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指言行或事情中留下的可以回旋、变通或调整的空间和机会，常用于“留有余地”“没有余地”等说法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 86963: 和解

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 和解是吵架的两个人不再生气，变成好朋友。
- learner tier: T3
- surface forms seen in tests: ["和解"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这段冷静的时间，常让夫妻重新审视彼此的分歧：有人因此和解，也有人更清楚地确认了自己的选择。
- sentences to write yourself: 9

## sense 102329: 撤回

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 撤回就是把已经送出去或放出去的东西拿回来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照规定，双方若协议离婚，须先提交申请，此后三十天内任何一方都可以撤回；期满还须共同到场，方能领取离婚证。
- sentences to write yourself: 9

## sense 102330: 撤回

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把已经发出、提出或派出的人、物、消息、申请等收回或调回，不再继续。也指取消已经做出的决定或说法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102333: 期满

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 约定的时间到了，事情就结束了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照规定，双方若协议离婚，须先提交申请，此后三十天内任何一方都可以撤回；期满还须共同到场，方能领取离婚证。
- sentences to write yourself: 9
