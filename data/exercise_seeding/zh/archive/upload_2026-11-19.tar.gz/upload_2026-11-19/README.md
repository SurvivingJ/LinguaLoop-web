# ZH word assets — upload package

Reviewed fat-seed output for **15624 Chinese senses** (all passed
`check --source reviewed`; rejected and skipped senses are excluded).
Delta package: the 7786 senses of the earlier package are excluded.

| | |
|---|---|
| `word_assets` rows | 109,368 (7 asset types) |
| UPDATE statements | 31,248 {'dim_vocabulary': 15624, 'dim_word_senses': 15624} |
| language_id | 1 (zh) |
| source | tool-free fat-seed pipeline (scratch_offline/nt_pipeline.py); see the run directories for models |

## Files

- `apply_all.sql` — everything in one transaction (186.0 MB). Use with `psql`.
- `chunks/part_01.sql … part_179.sql` — the same statements in ~0.9 MB files, each its
  own `BEGIN … COMMIT`, UPDATEs at the end. For the Supabase SQL editor, run them in order.
- `word_assets.csv` — the asset rows only (no UPDATEs), for Table Editor import.
- `verify.sql` — row counts to run afterwards.

Every INSERT is `ON CONFLICT (sense_id, asset_type) DO UPDATE`, so re-running a
chunk is harmless. Apply with:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f data/exercise_seeding/zh/upload_2026-11-19/apply_all.sql
```

## Staging notes (2026-11-19) — NOT applied

Built against a live read-only snapshot taken 2026-11-17; nothing was written to the database.

- **Contents:** 20,154 reviewed senses in total: 9,585 restored from the earlier run
  (`wf2/r0000–r0900`, reviewed but never uploaded, re-assembled against the current snapshot)
  plus 10,569 from 989 new runs written 2026-11-17 → 2026-11-19 (`wf2/r0902–r1890`, all 989 finished).
  After excluding senses already live, the package holds **15,624 senses / 109,368 `word_assets` rows**.
- **Excluded:** every sense that already had a `prompt1_core` row in `word_assets` on 2026-11-17 (7,786).
- **Dictionary overwrites to review first** — `overwrites_live_values.csv` (8,768 rows). These are
  mostly a *format* change, not new content:
  - `part_of_speech` (4,879): English labels → Chinese labels (`noun` → `名词`, `verb` → `动词`, …).
    The 7,786 senses already uploaded by the earlier package all use the Chinese labels, so this
    brings the rest into line. If the refactor standardises POS another way, drop these UPDATEs.
    ~50 are real reclassifications (e.g. `idiom` → `形容词`) — check those.
  - `pronunciation` (3,578): numbered-tone suffix dropped (`shì (shi4)` → `shì`), matching the
    format of already-uploaded senses.
  - `semantic_class` (311): genuine reclassifications (e.g. `abstract` → `concrete`).
  To keep live values, delete those UPDATE lines (at the end of each chunk) or apply only `word_assets.csv`.
- **The snapshot ages.** If the database changes before you apply this (refactor, POS migration),
  rebuild the package against a fresh snapshot rather than applying it as is.
- After applying: `verify.sql`, then stage 8 + render as in `.claude/skills/fat-seed-authoring/SKILL.md`.
- **QA spot-check (Opus judge, rubric v3, 36 senses from r1003/r1420/r1777):** mean score 6.80
  (ja package: 6.95). 9 fatal defects across 7 senses (19%). All 9 are distractor or "wrong
  sentence" items in `level_3`/`level_6`/`level_7` that are actually acceptable Chinese. This is
  the same pattern seen in the ja package. Judge files: `wf2/<run>/fat_seed/judge.reviewed.v3.opus-medium.json`.
