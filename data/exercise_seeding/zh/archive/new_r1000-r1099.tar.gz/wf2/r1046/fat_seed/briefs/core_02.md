# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1046`

Read `data/exercise_seeding/zh/wf2/r1046/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1046/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104065: 欢腾

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 欢腾就是大家特别高兴，又笑又跳。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 灯火终会熄灭，摊子也会散尽，但那种被人群裹挟着共同欢腾的经验，会成为此后许多年里人们对"过年"最具体的记忆。
- sentences to write yourself: 9

## sense 104066: 欢腾

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容人们非常高兴，热闹地欢笑、跳跃，场面气氛热烈。多用于集体庆祝或喜事发生的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104067: 叫卖声

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 卖东西的人大声喊，想让人来买，这就是叫卖声。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 庙会多在庙宇周边的街巷里铺开，摊贩挨着摊贩，糖画、剪纸、泥人、旧书旧唱片挤在一处，叫卖声与锣鼓声彼此叠压。
- sentences to write yourself: 9

## sense 104068: 叫卖声

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小贩在街头或市场上为了招揽顾客而大声喊出的吆喝声，通常是简短、有节奏的话语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104069: 入夜后

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 天黑了以后，就是入夜后。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 入夜后灯会接上班，成串灯笼沿着河堤与老街一路铺展，灯影在水面上碎成晃动的金色。
- sentences to write yourself: 9

## sense 104070: 入夜后

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指天色变黑、夜晚到来之后的一段时间，常用来说明夜里发生的事情或出现的变化。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
