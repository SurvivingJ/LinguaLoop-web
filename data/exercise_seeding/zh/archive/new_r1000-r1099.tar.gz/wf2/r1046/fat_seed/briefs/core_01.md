# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1046`

Read `data/exercise_seeding/zh/wf2/r1046/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1046/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102051: 暗藏玄机

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 看起来很普通，里面却藏着别人不知道的秘密。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 问卷设计看似简单，实则暗藏玄机，稍有不慎，便会在无形中左右受访者的判断。
- sentences to write yourself: 9

## sense 102052: 暗藏玄机

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指表面上看不出来，实际上隐藏着深奥的道理、巧妙的计谋或不易察觉的用意，常用来形容话语、事物或局面看似平常，其中却有特别的含义或危险。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104683: 违心

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 违心就是心里不想这样，可是嘴上说了或手上做了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. ”其次，量表的设置须兼顾平衡，正反两端的选项数量应当对等，并保留“一般”这样的中间项，以免迫使受访者作出违心的选择。
- sentences to write yourself: 9

## sense 104684: 违心

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指说话或做事与自己内心的真实想法相反，多用于“违心地说”“违心的话”等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104747: 稍有不慎

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 只要不小心一点，就会出错或有坏事发生。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 问卷设计看似简单，实则暗藏玄机，稍有不慎，便会在无形中左右受访者的判断。
- sentences to write yourself: 9

## sense 104748: 稍有不慎

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指稍微不小心、稍有疏忽，就可能出现错误或造成不好的后果。多用来提醒人们做事要格外谨慎。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
