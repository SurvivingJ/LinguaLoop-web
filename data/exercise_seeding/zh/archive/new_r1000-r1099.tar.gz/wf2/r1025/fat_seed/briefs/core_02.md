# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1025`

Read `data/exercise_seeding/zh/wf2/r1025/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1025/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104465: 查阅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 查阅就是翻书或看资料，找你要知道的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 同时，法律赋予个人查阅、更正乃至删除自己信息的权利。
- sentences to write yourself: 9

## sense 104466: 查阅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指为了了解某方面的信息，而翻看书籍、文件、资料或档案等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101399: 画像

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 画像就是描述一个人是什么样的。
- learner tier: T3
- surface forms seen in tests: ["画像"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在大数据时代，我们的一举一动几乎都会被记录下来：购物偏好、出行轨迹、搜索记录，经过算法分析后，往往能勾勒出一个人的完整画像。
- sentences to write yourself: 9

## sense 104471: 记录下来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把看到或听到的事写下来，不会忘。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在大数据时代，我们的一举一动几乎都会被记录下来：购物偏好、出行轨迹、搜索记录，经过算法分析后，往往能勾勒出一个人的完整画像。
- sentences to write yourself: 9

## sense 104472: 记录下来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用文字、图像或声音等方式把事情、话语或信息保存下来，以便日后查看或使用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100161: 不必要

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 不需要的
- learner tier: T3
- surface forms seen in tests: ["不必要"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我们既要谨慎授权，定期清理不必要的权限，企业也应切实履行责任，才能守住隐私的底线。
- sentences to write yourself: 9
