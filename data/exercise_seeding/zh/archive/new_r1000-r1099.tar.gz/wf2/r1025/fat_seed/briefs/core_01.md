# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1025`

Read `data/exercise_seeding/zh/wf2/r1025/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1025/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103821: 故土

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 故土是你出生和长大的地方，那里有你的家。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 保护方言并不意味着与普通话对立，两者完全可以共存：普通话拓宽孩子的视野，方言则维系他们与故土的情感联系。
- sentences to write yourself: 9

## sense 103822: 故土

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指自己出生、成长的地方，也就是家乡或祖国，多用于表达对那里的思念和感情，常带有书面、抒情的色彩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103823: 吟唱

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 吟唱就是用好听的声音慢慢地唱歌或读诗。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 值得欣慰的是，近年来一些地方已将方言童谣、地方戏曲引入校园，让孩子在游戏与吟唱中重新接触乡音。
- sentences to write yourself: 9

## sense 103824: 吟唱

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指用抑扬顿挫、带有感情的声调缓缓地唱或诵读诗词、歌谣等，多带有抒情、古雅的色彩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103825: 童谣

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 童谣是给小孩子唱的短歌，很好记，也很好玩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 值得欣慰的是，近年来一些地方已将方言童谣、地方戏曲引入校园，让孩子在游戏与吟唱中重新接触乡音。
- sentences to write yourself: 9

## sense 103826: 童谣

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专为儿童编写或在儿童中流传的短小歌谣，语言通俗，节奏明快，句子押韵，便于背诵和传唱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
