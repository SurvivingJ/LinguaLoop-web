# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1014`

Read `data/exercise_seeding/zh/wf2/r1014/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1014/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103409: 纸巾

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 纸巾是一种软软的纸，可以用来擦手和擦鼻子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照现行规定，家庭废弃物大致分为湿垃圾与干垃圾两类：前者指剩饭剩菜、果皮菜叶等易腐烂的有机物，后者包括纸巾、陶瓷碎片、一次性餐具等难以回收的物品。
- sentences to write yourself: 9

## sense 103410: 纸巾

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用来擦手、擦嘴或擦鼻涕的薄而柔软的纸，一般一张一张地用，用完就扔掉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103411: 沥水

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 沥水就是让水慢慢流掉，东西就不湿了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着宣传深入和邻里相互提醒，多数人逐渐摸索出规律——在厨房并排放置两个容器，投放前稍作沥水，异味与蚊虫问题也随之缓解。
- sentences to write yourself: 9

## sense 103412: 沥水

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指让物体上附着的水分慢慢滴落、流尽，使其沥干；也指能让水流走的设计，常用于厨房餐具、洗过的蔬菜等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101654: 基期

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 基期是统计中用作比较基准的时期，通常是一个特定的时间点或时间段。
- learner tier: T3
- surface forms seen in tests: ["基期"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 统计部门并不是把所有价格简单相加再求平均，而是先设定一个基期，再选取粮食、房租、交通、医疗等具有代表性的项目，持续记录它们的价格。
  1. 随后，统计人员采用加权平均的方法，把各类价格相对基期的涨跌幅汇总成一个指数。
- sentences to write yourself: 8

## sense 101653: 基期

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 基期是开始比较的时间点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
