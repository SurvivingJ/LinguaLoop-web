# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1014`

Read `data/exercise_seeding/zh/wf2/r1014/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1014/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104789: 价格上涨

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 东西变贵了，要花更多的钱才能买到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 假如食品价格上涨10%，而食品的权重高于教育，它对整体CPI的拉动就更明显。
- sentences to write yourself: 9

## sense 104790: 价格上涨

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指商品或服务的价钱比原来更高，也说物价上升。常用来说明买东西要花更多的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104801: 物价指数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 它是一个数，告诉我们东西的价钱是变贵了还是变便宜了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 消费者物价指数（CPI）用来衡量居民购买的商品和服务价格的总体变动。
- sentences to write yourself: 9

## sense 104802: 物价指数

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用来衡量一段时间内商品和服务价格总体变化情况的统计数字，通常与某个基期相比，数字上升说明物价上涨，下降说明物价下跌。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104803: 家庭理财

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 家庭理财就是一家人把钱管好，想好怎么花，怎么存。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，CPI能较客观地呈现物价走势，为政策制定和家庭理财提供参考。
- sentences to write yourself: 9

## sense 104804: 家庭理财

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指家庭或家庭成员对收入、支出、储蓄、投资、保险等钱财事务进行计划和管理，使家庭生活稳定，财富逐步增加。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
