# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1013`

Read `data/exercise_seeding/zh/wf2/r1013/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1013/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103559: 干湿

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 干湿就是东西干不干，湿不湿。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对习惯随手丢弃的居民而言，这种转变起初难免带来不适：有人抱怨时间受限，有人分不清干湿界限。
- sentences to write yourself: 9

## sense 103560: 干湿

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指干燥和潮湿的程度，常用来说明空气、土地、天气等的状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103561: 清运

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把脏东西和垃圾装上车，拉到别的地方去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为降低清运成本，许多小区推行"定时定点"投放制度，即在早晚两个固定时段开放垃圾房，其余时间上锁，由志愿者现场值守，指导居民正确投放。
- sentences to write yourself: 9

## sense 103562: 清运

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把垃圾、积雪、废料等东西收集起来，并运送到指定地点处理。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103563: 蚊虫

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 蚊虫是会飞的小虫子，会咬人，咬了会痒。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着宣传深入和邻里相互提醒，多数人逐渐摸索出规律——在厨房并排放置两个容器，投放前稍作沥水，异味与蚊虫问题也随之缓解。
- sentences to write yourself: 9

## sense 103564: 蚊虫

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指蚊子以及其他会叮咬人的小飞虫，常用来泛指夏天在户外或潮湿地方出现的、让人发痒的小昆虫。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
