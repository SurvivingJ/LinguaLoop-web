# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1013`

Read `data/exercise_seeding/zh/wf2/r1013/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1013/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103565: 易腐烂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 放得久了就会变坏，不能吃了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照现行规定，家庭废弃物大致分为湿垃圾与干垃圾两类：前者指剩饭剩菜、果皮菜叶等易腐烂的有机物，后者包括纸巾、陶瓷碎片、一次性餐具等难以回收的物品。
- sentences to write yourself: 9

## sense 103566: 易腐烂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指食物等东西容易变质、腐败，不能长时间存放。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103405: 受限

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 受限就是被管住了，不能想做什么就做什么。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对习惯随手丢弃的居民而言，这种转变起初难免带来不适：有人抱怨时间受限，有人分不清干湿界限。
- sentences to write yourself: 9

## sense 103406: 受限

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在范围、数量、条件或自由等方面受到限制，不能充分发挥或自由活动。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103407: 城市居民

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 住在城市里的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，垃圾分类已从一句倡导口号演变为城市居民的日常生活方式。
- sentences to write yourself: 9

## sense 103408: 城市居民

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指长期居住在城市里的人，通常和住在农村的人相对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
