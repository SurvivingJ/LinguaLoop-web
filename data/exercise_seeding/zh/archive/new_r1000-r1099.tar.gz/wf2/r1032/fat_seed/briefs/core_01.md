# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1032`

Read `data/exercise_seeding/zh/wf2/r1032/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1032/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104224: 市场份额

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一家公司的产品或服务的销售量或销售额，在整个市场的总销售量或总销售额中所占的比例，通常用百分数表示，用来说明这家公司在行业中的地位。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一套科学的指标体系，应当紧扣企业的核心目标：若目标是扩大市场份额，就应关注新客户增长率与客户留存率；若目标是提升运营效率，则需要考察单位成本与交付周期。
- sentences to write yourself: 9

## sense 104223: 市场份额

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一个店卖的东西，占所有店卖的东西的几分之几。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104227: 繁杂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 繁杂是东西很多很乱，事情很多很难弄。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多管理者容易陷入“数据越多越好”的误区，结果指标繁杂，员工疲于应付，反而偏离了重点。
- sentences to write yourself: 9

## sense 104228: 繁杂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容事物种类、数量很多，而且头绪混乱，不容易理清或处理。多用于事务、手续、工作、内容等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104230: 疲于

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: “疲于”后面常接动词，表示因为不停地做某事而感到疲惫、应付不过来，多含有被动、无奈的意思，如“疲于奔命”“疲于应付”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多管理者容易陷入“数据越多越好”的误区，结果指标繁杂，员工疲于应付，反而偏离了重点。
- sentences to write yourself: 9

## sense 104229: 疲于

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 疲于是说一直做一件事，做得很累，没有力气再做别的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
