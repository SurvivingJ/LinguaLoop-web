# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1032`

Read `data/exercise_seeding/zh/wf2/r1032/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1032/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102707: 创造力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 创造力就是能想出新办法、做出新东西的本领。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 毕竟，指标只是手段，而非目的；只有让数字真正服务于目标，考核才能激发团队的创造力，而不是沦为束缚。
- sentences to write yourself: 9

## sense 102708: 创造力

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人产生新想法、新方法或新事物的能力，常用来说明一个人善于想象、不照搬别人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104359: 越多越好

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 比别的数目大，就是多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多管理者容易陷入“数据越多越好”的误区，结果指标繁杂，员工疲于应付，反而偏离了重点。
- sentences to write yourself: 9

## sense 104360: 越多越好

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: “越多越好”表示数量或程度越大，结果就越理想。它是一种固定说法，用来表示对数量的要求或希望。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103723: 商业用途

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 拿东西去卖钱，或者用它来做生意。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 倘若相关数据保管不当，或被挪用于门禁之外的商业用途，居民的隐私便可能悄然流失。
- sentences to write yourself: 9

## sense 103724: 商业用途

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指把某种东西、技术、作品或场地用在做生意、赚钱的活动中，与个人使用或公益使用相对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
