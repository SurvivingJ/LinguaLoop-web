# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1050`

Read `data/exercise_seeding/zh/wf2/r1050/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1050/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103449: 限流

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 人太多或东西太多时，只让一部分先过去，让大家不会挤坏。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 旅游攻略也随之更新,不再一味罗列"必去打卡地",而是提醒读者留意限流公告与天气变化。
- sentences to write yourself: 9

## sense 103450: 限流

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指对水流、车流、人流或网络访问量等加以限制，只允许一定数量通过，以避免拥堵或系统崩溃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103451: 唯恐

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 唯恐就是特别怕某件不好的事发生，所以很小心。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 天还没亮,山门外的队伍已蜿蜒数里,游客攥着手机反复刷新页面,唯恐门票预约名额在几分钟内被抢空。
- sentences to write yourself: 9

## sense 103452: 唯恐

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，意思是只怕、生怕，表示非常担心某种不好的情况发生，因此特意去防止。后面常接不希望出现的事情，多用于书面语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103453: 拆成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把一个东西分开，变成几个小块。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人把假期拆成两段,错峰前往;有人放弃网红景点,转向名气不大却风景清幽的小城与村落。
- sentences to write yourself: 9

## sense 103454: 拆成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把整体的东西分开，使其变成几个部分；也指把组合在一起的东西一件件分开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
