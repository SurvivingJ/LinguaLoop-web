# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1050`

Read `data/exercise_seeding/zh/wf2/r1050/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1050/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102419: 隔代

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 隔代是中间隔了一辈人，比如爷爷和孙子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 随着城市化进程加快，许多双职工家庭因工作原因分隔两地，父母在外地打拼，子女往往交由爷爷奶奶照看，由此形成颇为普遍的隔代抚养现象。
  1. 家庭内部若能保持坦诚沟通，让老人理解年轻一代的养育期待，同时让父母尊重祖辈的辛劳与经验，隔代抚养便能减少摩擦，转化为三代人共同成长的契机。
- sentences to write yourself: 8

## sense 102420: 隔代

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 指中间隔着一代人，多用来说祖辈与孙辈之间的关系，如隔代亲、隔代教育、隔代遗传。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102425: 三代人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 三代人是爷爷奶奶、爸爸妈妈和孩子，三辈人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 家庭内部若能保持坦诚沟通，让老人理解年轻一代的养育期待，同时让父母尊重祖辈的辛劳与经验，隔代抚养便能减少摩擦，转化为三代人共同成长的契机。
- sentences to write yourself: 9

## sense 102426: 三代人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指同一家族中相继的三个辈分，通常是祖辈、父辈和子女辈；也可指年龄相差较大、经历和观念各不相同的三个世代的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102371: 爷爷奶奶

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 爷爷奶奶是爸爸的爸爸和妈妈，也常指老爷爷和老奶奶。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 随着城市化进程加快，许多双职工家庭因工作原因分隔两地，父母在外地打拼，子女往往交由爷爷奶奶照看，由此形成颇为普遍的隔代抚养现象。
- sentences to write yourself: 9

## sense 102372: 爷爷奶奶

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指父亲的父母，也可以泛指年纪大的男女长辈。口语中常把爷爷和奶奶合在一起说，表示家里的老人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
