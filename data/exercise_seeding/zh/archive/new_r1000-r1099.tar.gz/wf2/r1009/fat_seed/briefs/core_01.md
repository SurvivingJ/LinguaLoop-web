# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1009`

Read `data/exercise_seeding/zh/wf2/r1009/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1009/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103377: 年长者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 年长者是年纪比你大很多的人，像爷爷奶奶。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对年长者而言，离开并非单纯的空间迁移，而是归属感的剥离：他们熟悉每一道门槛的凹陷，也记得谁家的孩子在树下长大。
- sentences to write yourself: 9

## sense 103378: 年长者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指年纪比较大的人，常用来表示对老人或长辈的尊重，多用于较正式的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103379: 煤炉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 煤炉是烧煤的炉子，可以做饭，也可以让屋子变暖。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103380: 煤炉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 以煤为燃料的炉子，用来烧水、做饭或取暖，常见于过去的家庭和比较寒冷的地区。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103381: 晾衣杆

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 晾衣杆是一根长杆，人们把湿衣服挂在上面，让太阳晒干。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103382: 晾衣杆

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用来挂衣服、让衣服晾干的杆子，通常是竹子或金属做的，多放在阳台或院子里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
