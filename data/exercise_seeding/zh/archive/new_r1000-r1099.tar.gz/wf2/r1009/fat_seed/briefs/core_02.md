# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1009`

Read `data/exercise_seeding/zh/wf2/r1009/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1009/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103991: 读懂

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看了以后，知道它是什么意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 可见，读懂民意调查，不能只看数字本身，更要追问：样本从何而来，又是如何选出的？
- sentences to write yourself: 9

## sense 103992: 读懂

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指通过阅读或观察，真正理解文字、作品或他人的意思、想法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103993: 样本偏差

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 只看到一小部分人，就以为所有人都一样，这样想就错了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，若样本不能反映总体的构成，结果便会出现系统性偏离，这就是样本偏差。
- sentences to write yourself: 9

## sense 103994: 样本偏差

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指调查或研究时，选出来的对象不能代表整体，使得得出的结论与真实情况有差距。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104141: 民意调查

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 问很多人想法，看大家喜欢什么或怎么想。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 民意调查看似只是向一部分人提问，却常常左右舆论与决策，因此其结论是否可靠至关重要。
  1. 可见，读懂民意调查，不能只看数字本身，更要追问：样本从何而来，又是如何选出的？
- sentences to write yourself: 8

## sense 104142: 民意调查

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 通过提问、问卷等方式，向一部分人了解他们对某件事或某个问题的看法和态度，以便知道大多数人的想法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
