# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1008`

Read `data/exercise_seeding/zh/wf2/r1008/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1008/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103372: 砖墙

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用砖块和水泥或泥浆一层一层砌成的墙，常用来盖房子或围院子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着城市更新的推进，拆迁的告示贴上斑驳的砖墙，那些看似破败的老房子终究要退场。
- sentences to write yourself: 9

## sense 103371: 砖墙

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 砖墙是用很多块砖堆起来的墙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103373: 青砖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 青砖是青灰色的砖，用来盖房子和铺路。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103374: 青砖

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用黏土烧制而成的青灰色砖块，质地坚硬，常用于建造房屋、院墙和铺地，是中国传统建筑中常见的材料。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103376: 砖瓦

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 砖和瓦的合称，是用黏土烧制成的建筑材料，常用来砌墙、盖屋顶，也泛指盖房子用的材料。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 于是，记忆成了一种无处安放之物——它既不能被写进产权证书，也无法随砖瓦一同搬走。
- sentences to write yourself: 9

## sense 103375: 砖瓦

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 砖瓦是用来盖房子的东西，有砖，也有瓦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
