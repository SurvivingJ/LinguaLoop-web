# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1008`

Read `data/exercise_seeding/zh/wf2/r1008/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1008/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103366: 凹陷

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指物体表面的某一部分向里下沉，比周围低。也可指身体部位（如脸颊、眼眶）因消瘦等原因向里陷下去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对年长者而言，离开并非单纯的空间迁移，而是归属感的剥离：他们熟悉每一道门槛的凹陷，也记得谁家的孩子在树下长大。
- sentences to write yourself: 9

## sense 103365: 凹陷

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 凹陷是中间向里低下去，比旁边低。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103367: 横过

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 从路的一边走到另一边。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103368: 横过

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，指从一边到另一边穿过某处，如道路、河流、铁轨等；也指物体横着放置或横着越过。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103369: 灰瓦

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 灰瓦是灰色的瓦，盖在房子上面，可以挡雨。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103370: 灰瓦

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指颜色发灰的瓦片，多用黏土烧制而成，常用来铺盖屋顶，是传统民居常见的建筑材料。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
