# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1017`

Read `data/exercise_seeding/zh/wf2/r1017/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1017/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103649: 茶几

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 茶几是放在沙发前面的小桌子，可以放杯子和书。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 父亲照例占据沙发正中，母亲则忙着往茶几上摆瓜子与橘子。
- sentences to write yourself: 9

## sense 103650: 茶几

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 放在客厅沙发前或沙发旁的矮小桌子，用来放茶杯、水果、杂志等东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103651: 道贺

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 别人有喜事时，你去对他说高兴的话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当零点的钟声响起，屏幕内外的议论渐渐平息，只剩下彼此道贺的声音。
- sentences to write yourself: 9

## sense 103652: 道贺

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 向有喜事的人表示祝贺，常用于节日、结婚、升职、生子等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103653: 弹幕

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 弹幕是在视频上飘过去的一行行小字，是看视频的人写的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 网络上的评价更为直接，视频页面里密密麻麻的弹幕飞速掠过，有人感慨"年味淡了"，也有人反驳说，热闹本就不必苛求完美。
- sentences to write yourself: 9

## sense 103654: 弹幕

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指观看视频时，观众发送的评论文字，这些文字会在视频画面上从一侧飘到另一侧，可以让大家实时互动；也指军事上密集发射的炮火。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
