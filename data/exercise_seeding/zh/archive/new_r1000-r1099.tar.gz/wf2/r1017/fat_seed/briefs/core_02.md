# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1017`

Read `data/exercise_seeding/zh/wf2/r1017/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1017/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103655: 家长里短

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 家长里短是说家里和邻居间的小事，比如谁家做了什么。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 歌舞与相声轮番登场，最令人期待的仍是那几个小品——它们常以家长里短为素材，把生活中的窘迫与温情夸张地铺展开来，笑过之后仍留一点回味。
- sentences to write yourself: 9

## sense 103656: 家长里短

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指家庭或邻里之间琐碎的日常小事，多用于描述人们闲聊的内容，带有平常、琐碎的意味。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103657: 除夕之夜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 除夕之夜是一年最后一天的晚上，一家人会在一起吃饭。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 除夕之夜，一家人围坐在电视机前，等着春晚开场。
- sentences to write yourself: 9

## sense 103658: 除夕之夜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指农历一年中最后一天的夜晚，是春节前夕。人们通常在这个晚上全家团聚，吃年夜饭，守岁，迎接新年。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103659: 铺展开来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把卷起来或叠着的东西打开，放平，让它变大变宽。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 歌舞与相声轮番登场，最令人期待的仍是那几个小品——它们常以家长里短为素材，把生活中的窘迫与温情夸张地铺展开来，笑过之后仍留一点回味。
- sentences to write yourself: 9

## sense 103660: 铺展开来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把原来卷着、折着或聚在一起的东西向四周展开、摊开；也可以比喻景色、故事、活动等逐渐向外延伸，呈现出完整的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
