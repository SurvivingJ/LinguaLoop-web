# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1029`

Read `data/exercise_seeding/zh/wf2/r1029/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1029/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102897: 扰民

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大声吵闹，让旁边的人不能好好休息。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这场关于广场舞扰民的争议看似琐碎，实则折射出老龄化社会中公共空间与私人生活的边界之争。
- sentences to write yourself: 9

## sense 102898: 扰民

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指噪音、灯光或其他行为打扰了周围居民的正常生活和休息。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102899: 体面地

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 做事让人看了觉得好，有礼貌，不丢脸。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 毕竟，让每个人都能体面地老去、安静地生活，才是社区治理应有的温度。
- sentences to write yourself: 9

## sense 102900: 体面地

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 形容做事、表现或对待他人的方式得体、有尊严、不失面子，符合礼仪或社会期待，多修饰“离开、生活、告别、结束”等动作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102901: 会费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 会费是加入一个小组时，要给小组的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一群退休大妈随着音乐翩翩起舞，她们把广场舞当作最惬意的健身方式：不必支付会费，还能在交谈与舞动中排解孤独。
- sentences to write yourself: 9

## sense 102902: 会费

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指加入某个组织、协会或俱乐部的成员按规定定期缴纳的费用，用于维持组织的活动和开支。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
