# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1029`

Read `data/exercise_seeding/zh/wf2/r1029/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1029/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102561: 因人而异

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 每个人不一样，做法和结果也会不一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 答案因人而异，但唯有清醒地权衡过利弊，日后的选择才不至于沦为懊悔。
- sentences to write yourself: 9

## sense 102562: 因人而异

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指同样的事情，因为人的情况、性格、条件不同，结果、做法或感受也会不同，不能一概而论。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102563: 铁饭碗

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 铁饭碗是说一份很稳的工作，不会丢掉，一直有饭吃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在他们眼中，体制内的公务员岗位象征着一种难以撼动的安全感——所谓"铁饭碗"，意味着不必担心裁员与失业，收入虽然不算丰厚，却足够稳定。
- sentences to write yourself: 9

## sense 102564: 铁饭碗

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 比喻稳定、不会失去的职业或收入来源，多指国家机关、事业单位等的工作，不用担心被辞退。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102567: 押注

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 押注就是拿钱或东西去赌，希望自己猜对了能赢更多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 于是，无数人涌入考场，把青春押注在一场漫长的备考之上。
- sentences to write yourself: 9

## sense 102568: 押注

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在赌博或比赛中把钱或财物押在某一方，希望赢得更多；也比喻把希望或资源集中投在某个人或某件事上，期待有好结果。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
