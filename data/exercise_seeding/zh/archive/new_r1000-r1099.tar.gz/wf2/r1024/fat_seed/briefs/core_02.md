# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1024`

Read `data/exercise_seeding/zh/wf2/r1024/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1024/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104307: 拍板

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 拍板就是在大家商量以后，由一个人说“就这样做”，把事情定下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一种是“拍脑袋”式决策，管理者凭借个人直觉或零散印象迅速拍板，看似果断高效，实则风险潜伏其中。
- sentences to write yourself: 9

## sense 104308: 拍板

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在讨论之后，由主要负责人做出最后的决定。原指拍打木板打节拍，现多用于商量事情、做生意或开会时，表示最终拍定、作出决断。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103707: 可逆

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 可逆是说事情能变回原来的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 语言学者指出，方言承载着独特的词汇、语调与地方记忆，一旦年轻一代不再开口，许多表达方式便随之消失，而消失往往不可逆。
- sentences to write yourself: 9

## sense 103708: 可逆

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指事物的变化或过程可以反方向进行，能够回到原来的状态。多用于科学、医学等语境，反义词是“不可逆”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103817: 乡音

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 乡音是你家乡的人说话的声音和味道。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 在城市的幼儿园里，孩子们说着一口标准的普通话，流畅而清晰；可回到家中，祖辈口中的乡音却常常让他们感到陌生。
  1. 值得欣慰的是，近年来一些地方已将方言童谣、地方戏曲引入校园，让孩子在游戏与吟唱中重新接触乡音。
- sentences to write yourself: 8

## sense 103818: 乡音

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个人家乡的口音或方言，常带有对故乡的思念和亲切感。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
