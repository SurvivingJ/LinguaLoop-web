# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1041`

Read `data/exercise_seeding/zh/wf2/r1041/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1041/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101895: 略有

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 略有就是有一点点，不太多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 由于各家银行对材料清单的解释略有差异，建议先到住处附近的网点咨询，避免因资料不全而白跑一趟。
- sentences to write yourself: 9

## sense 101896: 略有

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 表示有一些，但程度不深、数量不多，常用来委婉地说明情况，多用于书面语。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101897: 期限内

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 在说好的那段时间里，还没有到最后一天。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 值得注意的是，多数银行要求账户在一定期限内保持活跃，长期不使用的账户可能被限制交易，届时需本人到柜台重新验证身份。
- sentences to write yourself: 9

## sense 101898: 期限内

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 指在规定或约定的时间范围之内，没有超过截止的时间。常用来说明做事、交费、还款等必须在这段时间里完成。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101901: 开立

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 开立是银行或公司新做一个户头，或者写出一张单子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对于刚到中国的外国人来说，开立银行账户往往是安顿生活的第一步。
- sentences to write yourself: 9

## sense 101902: 开立

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指正式设立或办理建立某种账户、证件、单据等，常用于银行、财务、贸易等场合，如开立账户、开立发票、开立信用证。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
