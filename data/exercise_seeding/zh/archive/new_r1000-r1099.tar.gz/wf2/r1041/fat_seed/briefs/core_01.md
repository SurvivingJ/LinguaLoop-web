# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1041`

Read `data/exercise_seeding/zh/wf2/r1041/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1041/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101889: 如实

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 有什么就说什么，不说假话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
- sentences to write yourself: 9

## sense 101890: 如实

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 按照事情真实的情况去做或去说，不隐瞒，不夸大，不虚假。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101891: 完全一致

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 两个或几个东西一点都不不同，就是完全一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照相关规定，银行必须落实实名认证制度，即确认开户人与证件信息完全一致，因此身份证、护照、居留许可等材料缺一不可。
- sentences to write yourself: 9

## sense 101892: 完全一致

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指两个或多个人、事物在想法、做法、内容等方面没有任何差别，彼此相同或相符。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101893: 开户

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 去银行办一个新的钱袋子，以后可以存钱和取钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 按照相关规定，银行必须落实实名认证制度，即确认开户人与证件信息完全一致，因此身份证、护照、居留许可等材料缺一不可。
  1. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
- sentences to write yourself: 8

## sense 101894: 开户

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在银行、证券公司等机构登记并办理一个新的账户，以便存钱、取钱或进行交易。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
