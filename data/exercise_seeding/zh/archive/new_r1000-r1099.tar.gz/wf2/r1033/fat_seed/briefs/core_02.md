# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1033`

Read `data/exercise_seeding/zh/wf2/r1033/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1033/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100560: 夜市

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 在晚上营业的市场，通常有摊位出售各种商品或小吃
- learner tier: T3
- surface forms seen in tests: ["夜市"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 白天他在公司做设计，晚上却悄悄开始了另一项副业：在夜市摆摊。
- sentences to write yourself: 9

## sense 100559: 夜市

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 晚上买东西的地方
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100570: 肠

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 肠指用肉等原料制成的长条状食品，常烤或煮着吃。
- learner tier: T3
- surface forms seen in tests: ["肠"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他卖烤肠、凉皮和柠檬水，价格不高，生意却越来越稳定。
- sentences to write yourself: 9

## sense 100569: 肠

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 肠是一种食物，可以烤着吃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100578: 办好

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 完成办理，使事情达到可用的状态
- learner tier: T3
- surface forms seen in tests: ["办好"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 刚开始，他担心城管会突然来检查，所以总选在允许摆摊的街角，并提前办好健康证明。
- sentences to write yourself: 9

## sense 100577: 办好

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 做好
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
