# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1033`

Read `data/exercise_seeding/zh/wf2/r1033/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1033/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103727: 门禁

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 门禁是门上的小锁。有卡的人才能进去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，人脸识别门禁在越来越多的住宅小区普及开来。
  1. 倘若相关数据保管不当，或被挪用于门禁之外的商业用途，居民的隐私便可能悄然流失。
- sentences to write yourself: 8

## sense 103728: 门禁

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在大楼、小区、学校等出入口设置的管理系统，通过刷卡、密码、指纹等方式控制人员进出，也指这种出入限制的规定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103865: 人脸识别

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 机器看人的脸，就能知道他是谁。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，人脸识别门禁在越来越多的住宅小区普及开来。
- sentences to write yourself: 9

## sense 103866: 人脸识别

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指用计算机技术分析人脸的特征，并与已有的信息对比，从而确定一个人的身份的技术。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103867: 住宅小区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 很多人住的一片房子，有围墙，里面有路和花园。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 近年来，人脸识别门禁在越来越多的住宅小区普及开来。
- sentences to write yourself: 9

## sense 103868: 住宅小区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指由多栋住宅楼组成、有统一管理和公共设施（如绿地、道路、停车场）的居民居住区域，通常有围墙或大门。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
