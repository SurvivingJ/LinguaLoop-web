# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1027`

Read `data/exercise_seeding/zh/wf2/r1027/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1027/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100201: 守住

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 不让它失去或改变
- learner tier: T3
- surface forms seen in tests: ["守住"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 我们既要谨慎授权，定期清理不必要的权限，企业也应切实履行责任，才能守住隐私的底线。
- sentences to write yourself: 9

## sense 102655: 高薪

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 高薪就是很多很多的工资，工作一个月能拿到很多钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 所谓“中年危机”，并非单纯指个人能力下降，而更多是组织在裁员、重组与绩效评估中，对高薪、资深员工采取的谨慎态度。
- sentences to write yourself: 9

## sense 102656: 高薪

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指很高的工资或报酬，常用来说明工作待遇很好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102659: 成本上升

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 做东西或做事要花的钱变多了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 企业担心成本上升，也担心员工难以接受高强度变化，于是把年龄视为风险信号。
- sentences to write yourself: 9

## sense 102660: 成本上升

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指生产商品、提供服务或做某件事所需要的费用比以前增加了，常与原材料涨价、工资提高等原因有关。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102773: 面孔

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 面孔就是脸，是你脸上眼睛、鼻子和嘴巴的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若招聘只偏好年轻面孔，社会将失去大量可迁移的技能与经验。
- sentences to write yourself: 9
