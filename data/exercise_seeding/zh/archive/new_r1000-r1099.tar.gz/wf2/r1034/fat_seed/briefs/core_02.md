# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1034`

Read `data/exercise_seeding/zh/wf2/r1034/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1034/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104647: 各取所长

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 每个人或东西都有好处，我们把大家好的地方拿来用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，许多企业索性将二者结合使用，各取所长。
- sentences to write yourself: 9

## sense 104648: 各取所长

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指吸收各方面或各人的优点，用来弥补自己的不足，使自己或整体更完善。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103139: 入库

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西放进仓库里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这些数据在入库之前，必须先经过ETL流程，即抽取、转换、加载，按照预先设定的模式整理妥当，因此查询速度快，结果可靠，非常适合管理层进行固定的统计分析。
- sentences to write yourself: 9

## sense 103140: 入库

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把货物、产品、文件或资料等放进仓库或数据库保存起来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104329: 原样

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 原样就是和以前一样，一点都没有变。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 相比之下，数据湖奉行“先存储、后处理”的原则，能够原样保留各种格式的数据，既包括结构化数据，也包括日志、图片、音频等非结构化内容。
- sentences to write yourself: 9

## sense 104330: 原样

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指原来的样子，没有发生变化或改动。常用于“保持原样”“照原样”“恢复原样”等说法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
