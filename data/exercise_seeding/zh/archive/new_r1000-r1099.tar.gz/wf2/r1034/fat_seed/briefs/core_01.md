# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1034`

Read `data/exercise_seeding/zh/wf2/r1034/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1034/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100584: 小生意

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指规模小、通常由个人经营的小型商业活动，如摊位、小店等。
- learner tier: T3
- surface forms seen in tests: ["小生意"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 慢慢地，他发现地摊经济并不只是“小生意”，而是许多人创业的起点。
- sentences to write yourself: 9

## sense 100583: 小生意

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 小生意就是很小的买卖。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100592: 升级成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 将某事物提升到更高的等级或更优的状态，使其转变为另一种形式。
- learner tier: T3
- surface forms seen in tests: ["升级成"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 如今，他准备把小吃摊升级成一家小店，把最初的副业变成真正的创业。
- sentences to write yourself: 9

## sense 100591: 升级成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 让东西变得更好，变成新的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104643: 杂乱无章

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 东西放得到处都是，很乱，没有顺序。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，缺乏有效治理的数据湖，容易沦为杂乱无章的“数据沼泽”。
- sentences to write yourself: 9

## sense 104644: 杂乱无章

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容事物或思想非常混乱，没有条理，没有次序。多用来说房间、文章、思路、物品等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
