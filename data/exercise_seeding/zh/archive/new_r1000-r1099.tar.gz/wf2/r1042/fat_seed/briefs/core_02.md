# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1042`

Read `data/exercise_seeding/zh/wf2/r1042/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1042/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101927: 安顿

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 安顿就是把人或东西放好，让他们住得稳，过得好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对于刚到中国的外国人来说，开立银行账户往往是安顿生活的第一步。
- sentences to write yourself: 9

## sense 101928: 安顿

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把人、家庭或事物安排妥当，使其有稳定、合适的居所或状态；也可指心情平静、安稳。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101929: 畅

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 畅是没有挡住，很顺，很快乐。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若语言沟通不畅，可请工作人员提供翻译协助。
- sentences to write yourself: 9

## sense 101930: 畅

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容词，指没有阻碍、顺利通达，也指痛快、尽情。常用于“通畅”“流畅”“畅谈”“畅快”等词语中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102005: 白跑一趟

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 你去了一个地方，可是没有做成事，白白走了一次。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 由于各家银行对材料清单的解释略有差异，建议先到住处附近的网点咨询，避免因资料不全而白跑一趟。
- sentences to write yourself: 9

## sense 100605: 网点

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 可以办理事情的地方
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 由于各家银行对材料清单的解释略有差异，建议先到住处附近的网点咨询，避免因资料不全而白跑一趟。
- sentences to write yourself: 9
