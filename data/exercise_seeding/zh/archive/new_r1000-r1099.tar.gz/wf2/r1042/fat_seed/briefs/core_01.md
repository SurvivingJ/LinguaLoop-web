# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1042`

Read `data/exercise_seeding/zh/wf2/r1042/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1042/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101903: 反洗钱

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 反洗钱就是不让坏人把偷来或骗来的钱变成好钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
- sentences to write yourself: 9

## sense 101904: 反洗钱

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指预防和打击把犯罪得来的非法资金通过各种方式变成看似合法的钱的行为，也指相关的法律、制度和措施。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101907: 缺一不可

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 每一个都要有，少了一个都不行。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照相关规定，银行必须落实实名认证制度，即确认开户人与证件信息完全一致，因此身份证、护照、居留许可等材料缺一不可。
- sentences to write yourself: 9

## sense 101908: 缺一不可

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指每一个部分或每一个人、每一样东西都必须具备，少了任何一个都不可以，强调每个部分都很重要。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101925: 居留

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 居留是住在一个地方，不是自己的国家，住一段时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照相关规定，银行必须落实实名认证制度，即确认开户人与证件信息完全一致，因此身份证、护照、居留许可等材料缺一不可。
- sentences to write yourself: 9

## sense 101926: 居留

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在外国或外地暂时或长期住下来，通常需要得到当地的许可。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
