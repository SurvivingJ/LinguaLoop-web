# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1044`

Read `data/exercise_seeding/zh/wf2/r1044/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1044/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102663: 工龄

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 工龄是一个人在工作单位做事一共做了多少年。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若暂时待业，可以灵活就业人员的身份自行缴纳，以免工龄与账户余额出现断层。
- sentences to write yourself: 9

## sense 102664: 工龄

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指职工参加工作以来累计的工作年限，常用来计算工资、休假、退休待遇等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102779: 办结

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 办结就是事情办完了，办好了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 公积金则可通过全国住房公积金异地转移接续平台或线下网点办理，多数城市已实现线上办结。
- sentences to write yourself: 9

## sense 102780: 办结

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指事情、手续或案件等办理完毕，多用于公务、行政和司法工作中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102781: 待业

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 想上班，可是现在还没有工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若暂时待业，可以灵活就业人员的身份自行缴纳，以免工龄与账户余额出现断层。
- sentences to write yourself: 9

## sense 102782: 待业

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指有劳动能力、想工作的人暂时没有找到工作，处在没有职业的状态，常指等待安排或寻找工作的时期。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
