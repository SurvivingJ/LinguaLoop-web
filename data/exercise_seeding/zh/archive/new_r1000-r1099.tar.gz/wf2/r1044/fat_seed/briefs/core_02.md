# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1044`

Read `data/exercise_seeding/zh/wf2/r1044/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1044/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102885: 接续

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 接续就是接着前面的，再往下做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 公积金则可通过全国住房公积金异地转移接续平台或线下网点办理，多数城市已实现线上办结。
- sentences to write yourself: 9

## sense 102886: 接续

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在已有的事情、动作或状态停下之后，紧接着继续下去，使前后连在一起。常用于工作、话题、关系等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102889: 参保

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 参保就是交钱加入保险，生病或老了可以得到帮助。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其实，这两项权益并不会因为离职而自动中断，但若不主动办理转移手续，账户便可能长期滞留在原参保地，进而影响日后的购房贷款与退休待遇。
- sentences to write yourself: 9

## sense 102890: 参保

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 参加社会保险或其他保险，成为被保险的人，如参加医疗保险、养老保险等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102891: 这两项

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 说的是前面讲过的两件事或两样东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其实，这两项权益并不会因为离职而自动中断，但若不主动办理转移手续，账户便可能长期滞留在原参保地，进而影响日后的购房贷款与退休待遇。
- sentences to write yourself: 9

## sense 102892: 这两项

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指上文已经提到的两件事、两个项目或两个方面，用来回指并强调这两者，常用于说明、比较或分别处理。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
