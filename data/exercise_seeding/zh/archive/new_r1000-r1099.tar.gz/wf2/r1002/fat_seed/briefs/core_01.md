# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1002`

Read `data/exercise_seeding/zh/wf2/r1002/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1002/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102577: 退去

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 水或人慢慢走开，往后离开，不在那里了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 若社会评价仍以学历为唯一尺度，这股热潮恐怕难以真正退去。
- sentences to write yourself: 9

## sense 102578: 退去

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指水、潮水、烟雾等向后散去、消失；也可指人或军队向后撤离。有时还指红肿、热度等慢慢减轻消失。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102579: 考研热

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 很多人都想考研究生，去读更高的书。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 近年来，考研热持续升温，报考人数屡创新高。
  1. 值得注意的是，考研热并非单纯的个人选择，它更像是一面镜子，折射出经济结构转型期岗位供给与人才预期之间的错位。
- sentences to write yourself: 8

## sense 102580: 考研热

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指社会上报考研究生的人数大量增加、许多人热衷于考研的现象。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102583: 一面镜子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 镜子可以照出你的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 值得注意的是，考研热并非单纯的个人选择，它更像是一面镜子，折射出经济结构转型期岗位供给与人才预期之间的错位。
- sentences to write yourself: 9

## sense 102584: 一面镜子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: “一面镜子”指一块能照出人影的镜子，“面”是量词。也常用来比喻能让人看清自己或事物真实情况的人或事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
