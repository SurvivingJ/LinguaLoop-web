# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1002`

Read `data/exercise_seeding/zh/wf2/r1002/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1002/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101395: 针对性

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 针对性就是专门针对一个事情或问题。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
- sentences to write yourself: 9

## sense 104587: 间隔

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 间隔是两个东西中间空着的地方，或者两次中间隔着的时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
- sentences to write yourself: 9

## sense 104588: 间隔

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指事物在空间或时间上相隔的距离或一段时间；也可作动词，表示隔开、使不相连。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104589: 发车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 车子开始走，离开车站。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
- sentences to write yourself: 9

## sense 104590: 发车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指火车、公共汽车等交通工具按时间从起点站开出去，开始行驶。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 91741: 绿

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 绿是草和树叶的颜色。
- learner tier: T3
- surface forms seen in tests: ["绿"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
