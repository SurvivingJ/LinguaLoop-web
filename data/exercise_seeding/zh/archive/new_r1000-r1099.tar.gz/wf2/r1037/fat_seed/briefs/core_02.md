# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1037`

Read `data/exercise_seeding/zh/wf2/r1037/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1037/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104401: 束手无策

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 遇到难事，不知道怎么办，一点办法也没有。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这好比学生死记硬背往年试题，遇到新题就束手无策。
- sentences to write yourself: 9

## sense 104402: 束手无策

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容遇到问题或困难时，想不出任何办法来解决，完全无法应对。多用于面对突发情况或难题的时候。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104403: 拟合

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 拟合就是让画出来的线，尽量靠近很多点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 倘若模型过于“聪明”，便容易陷入过拟合：它不仅学会了训练集中的普遍规律，还把偶然的噪声和个别细节当作真理，结果在训练集上成绩近乎完美，一到测试集便漏洞百出。
  1. 相反，欠拟合则源于模型“不够聪明”，它结构过于简单，或训练不充分，连数据中的基本规律都没有把握，因此无论在训练集还是测试集上，表现都不尽如人意。
- sentences to write yourself: 8

## sense 104404: 拟合

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指根据已有的数据，选出或建立一个数学模型或曲线，使它尽可能符合这些数据的分布。常用于统计、数学和机器学习。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104407: 泛化

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 泛化就是把一个小地方的事，变成很多地方都有的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在机器学习中，模型的优劣不取决于它对已知数据记得多牢，而在于面对陌生数据时能否做出可靠判断，这种本领被称为泛化能力。
- sentences to write yourself: 9

## sense 104408: 泛化

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指从个别、具体的事物扩展到一般、更广泛的范围，使某种特点、规律或做法不再局限于原来的对象；也指原本明确的概念变得模糊、范围扩大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
