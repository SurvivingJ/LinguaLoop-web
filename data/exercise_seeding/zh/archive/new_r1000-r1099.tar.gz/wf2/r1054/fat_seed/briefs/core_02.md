# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1054`

Read `data/exercise_seeding/zh/wf2/r1054/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1054/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102191: 老规矩

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 老规矩就是大家以前一直这样做的办法，这次还照那样做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按老规矩，母亲会在其中一只饺子里悄悄裹进一枚洗净的硬币。
- sentences to write yourself: 9

## sense 102192: 老规矩

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指过去已经形成、大家都熟悉的做法或规定，多用于说话时表示这次仍按以前的方式办理，不用重新商量。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102193: 顺遂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 顺遂就是事情做起来很顺利，没有什么麻烦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 人们真正在意的，或许并非财运，而是全家人能再一次围坐在一起，把平安与顺遂的愿望，一并包进那层薄薄的面皮里。
- sentences to write yourself: 9

## sense 102194: 顺遂

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容事情进行得顺利，没有阻碍，符合心愿。常用于祝福语或形容生活、工作、仕途等方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102195: 裹进

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西包起来，让它在里面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按老规矩，母亲会在其中一只饺子里悄悄裹进一枚洗净的硬币。
- sentences to write yourself: 9

## sense 102196: 裹进

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，指用布、毯子、衣物等把人或物紧紧包住；也可比喻使人被卷入某种事件或情形之中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
