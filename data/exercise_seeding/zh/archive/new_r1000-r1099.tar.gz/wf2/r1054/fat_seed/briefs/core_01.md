# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1054`

Read `data/exercise_seeding/zh/wf2/r1054/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1054/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102085: 揉面

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用手压和推面团，让面团变软。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 奶奶揉面，母亲调馅，父亲擀皮，孩子们负责把那些形状略显笨拙的成品摆进竹筛——分工并不固定，却自有一种默契。
- sentences to write yourself: 9

## sense 102086: 揉面

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指做面食时，用手反复按压、推拉、翻折面团，使面粉和水混合均匀，面团变得光滑有劲道。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102087: 年夜饭

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 过年前一天晚上，全家人坐在一起吃的饭。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在北方，年夜饭若少了饺子，便算不得完整；而对许多人来说，包饺子本身就是团圆最具体的模样：几双手在同一张案板上忙碌，话题从旧年的得失延伸到新岁的打算。
- sentences to write yourself: 9

## sense 102088: 年夜饭

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指农历除夕晚上全家人团聚在一起吃的丰盛晚饭，是春节期间最重要的家庭聚餐，象征团圆和吉祥。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102089: 擀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用一根长木棍把面团压平压薄。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102090: 擀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用擀面杖等圆柱形工具在面团等东西上来回滚动，把它压平、压薄，常用来做面条、饺子皮、饼等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
