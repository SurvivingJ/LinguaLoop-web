# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1005`

Read `data/exercise_seeding/zh/wf2/r1005/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1005/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102987: 专科门诊

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 医院里只看一种病的地方，比如只看眼睛或牙齿。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 事实上，看病难不仅体现在挂号排队、专家难约，更体现在优质医疗资源过度集中于大城市，偏远地区的患者往往要辗转数小时才能看上专科门诊。
- sentences to write yourself: 9

## sense 102988: 专科门诊

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 医院里专门诊治某一类疾病或某一个身体部位的门诊，由这方面的专科医生接诊，如眼科门诊、皮肤科门诊。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102989: 特护

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 特护是医院里一个人专门照看病人，病人很重，要有人一直看着。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 虽然医保为他们报销了大部分住院费用，但进口药、特护病房以及院外购买的药品并不在目录之内，只能全部自费，这部分开销最终仍压得全家喘不过气。
- sentences to write yourself: 9

## sense 102990: 特护

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指医院对病情严重的病人给予的特别护理，由专人日夜看护；也指担任这种护理的护士或护理工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102699: 老伴

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 老伴是年纪大的夫妻中，对另一个人的叫法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 李阿姨的老伴去年被确诊为重症，住院、手术加上长期用药，前后花费近四十万元。
- sentences to write yourself: 9

## sense 102700: 老伴

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指年老夫妻中的一方，即老年人称呼自己的丈夫或妻子，也可用来指别人的老年配偶，多用于口语，带有亲切的感情。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
