# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1005`

Read `data/exercise_seeding/zh/wf2/r1005/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1005/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 98997: 脉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 脉是手腕上能摸到一跳一跳的地方，是血在流。
- learner tier: T3
- surface forms seen in tests: ["脉"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这场以“绿脉计划”为名的植树造林行动，起初只是几位退休教师在村口荒坡上栽下的一百棵杨树苗，如今已演变为涵盖三十多个行政村、年均种植超过五万株本土树种的区域性环境保护实践。
- sentences to write yourself: 9

## sense 98998: 脉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 血管；也指脉搏。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102921: 住院费用

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人生病住在医院里，要给医院的钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 虽然医保为他们报销了大部分住院费用，但进口药、特护病房以及院外购买的药品并不在目录之内，只能全部自费，这部分开销最终仍压得全家喘不过气。
- sentences to write yourself: 9

## sense 102922: 住院费用

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指病人住进医院治疗期间产生的各种花费，包括床位费、药费、检查费和手术费等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102925: 看病难

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 人生病了，很不容易见到医生，也很不容易治好病。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 事实上，看病难不仅体现在挂号排队、专家难约，更体现在优质医疗资源过度集中于大城市，偏远地区的患者往往要辗转数小时才能看上专科门诊。
- sentences to write yourself: 9

## sense 102926: 看病难

- reading: (none)
- dictionary POS hint: n. The enum below wins over this hint.
- existing definition: 指人们生病后难以及时得到医生诊治的社会问题，原因包括医院人多、要排很长的队、挂号困难、好医生少或看病花钱多等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
