# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1007`

Read `data/exercise_seeding/zh/wf2/r1007/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1007/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103351: 回迁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 房子拆了以后，人又搬回新盖的房子里住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 补偿与回迁方案固然提供了物质安置，却难以承接那些依附于具体地点的情感。
  1. 新的回迁楼明亮、整洁，电梯取代了爬不完的楼梯，可楼道里再也听不见隔着窗子的招呼声。
- sentences to write yourself: 8

## sense 103352: 回迁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指因城市改造等原因，原来的房屋被拆除后，居民在原地或附近新建的住房建成后搬回去居住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103353: 听不见

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 听不见，就是耳朵没有听到声音。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 新的回迁楼明亮、整洁，电梯取代了爬不完的楼梯，可楼道里再也听不见隔着窗子的招呼声。
- sentences to write yourself: 9

## sense 103354: 听不见

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指因为距离太远、声音太小、有干扰或听力不好等原因，无法听到某种声音。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103355: 窗子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 窗子是墙上的洞，上面有玻璃，可以看到外面，也能让风进来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 新的回迁楼明亮、整洁，电梯取代了爬不完的楼梯，可楼道里再也听不见隔着窗子的招呼声。
- sentences to write yourself: 9

## sense 103356: 窗子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 房屋、车辆等墙壁上用来通风、透光和观看外面的开口，通常装有玻璃或可以开关的窗扇。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
