# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1007`

Read `data/exercise_seeding/zh/wf2/r1007/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1007/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103357: 退场

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 退场就是从场地里走出去，不再留在那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着城市更新的推进，拆迁的告示贴上斑驳的砖墙，那些看似破败的老房子终究要退场。
- sentences to write yourself: 9

## sense 103358: 退场

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指演员、运动员、观众等离开表演、比赛或会议的场地；也可比喻从某个活动或领域中退出。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103359: 邻家

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 邻家是住在你家旁边的人家。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 青砖灰瓦之间，晾衣杆横过狭窄的天空，煤炉的烟气混着邻家饭菜的香味，构成了一代人难以复制的记忆。
- sentences to write yourself: 9

## sense 103360: 邻家

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指住在自己家附近、紧挨着自己家的那一户人家，也可泛指邻居。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103361: 破败

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 东西旧了坏了，看起来很乱很差，不能好好用了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着城市更新的推进，拆迁的告示贴上斑驳的砖墙，那些看似破败的老房子终究要退场。
- sentences to write yourself: 9

## sense 103362: 破败

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容房屋、庭院、城镇等因年久失修或遭到破坏而残缺、衰败、不整齐的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
