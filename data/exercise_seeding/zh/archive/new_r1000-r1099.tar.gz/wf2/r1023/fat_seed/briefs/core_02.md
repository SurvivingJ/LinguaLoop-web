# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1023`

Read `data/exercise_seeding/zh/wf2/r1023/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1023/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104297: 区域经理

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 区域经理是公司里管一个地方工作的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9

## sense 104298: 区域经理

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 公司里负责管理某一个地区的业务和员工的管理人员，通常要完成该地区的销售或经营目标。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104295: 资历

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 资历是一个人做过的事和做了多久的事。时间长，经验多，资历就深。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种做法与医学领域的循证理念一脉相承：结论必须经得起证据检验，而非取决于资历深浅。
- sentences to write yourself: 9

## sense 104296: 资历

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个人在工作或某个领域中积累的经历、经验和工作年限，常用来衡量其地位、能力或是否适合担任某职务。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104299: 门店

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 门店是人们去买东西的小店，开在街上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9

## sense 104300: 门店

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指商家开设的、供顾客直接上门购物或接受服务的店铺，常指连锁品牌在各地设立的分店。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
