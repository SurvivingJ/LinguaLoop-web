# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1043`

Read `data/exercise_seeding/zh/wf2/r1043/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1043/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101883: 指纹

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指纹是手指头上的细细花纹，每个人的都不一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
- sentences to write yourself: 9

## sense 101884: 指纹

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 手指末端皮肤上凸起的纹路，每个人都不相同，也指这些纹路留下的印子，常用来识别身份或破案。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101887: 柜台

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 柜台是商店里放东西的长桌子，人们在这里买东西和付钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 办理时通常需要在柜台填写开户申请，并完成签字、拍照、留存指纹等步骤；工作人员还会询问开户用途，这是反洗钱审查的必要环节，如实说明即可。
  1. 值得注意的是，多数银行要求账户在一定期限内保持活跃，长期不使用的账户可能被限制交易，届时需本人到柜台重新验证身份。
- sentences to write yourself: 8

## sense 101888: 柜台

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 商店、银行等场所里用来摆放商品或办理业务的长条形台子，店员或工作人员在后面接待顾客。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100947: 索取

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 向别人要东西
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 离职时，应向原单位的人事部门索取解除劳动关系的证明，并确认社保已缴至当月；入职新单位后，把材料交给新公司的人事专员，由其向当地经办机构提出转入申请。
- sentences to write yourself: 9

## sense 100505: 入职

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 开始做新工作
- learner tier: T3
- surface forms seen in tests: ["入职"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 离职时，应向原单位的人事部门索取解除劳动关系的证明，并确认社保已缴至当月；入职新单位后，把材料交给新公司的人事专员，由其向当地经办机构提出转入申请。
- sentences to write yourself: 9
