# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1043`

Read `data/exercise_seeding/zh/wf2/r1043/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1043/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 101109: 缴费

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 付钱
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 需要提醒的是，医保待遇存在等待期，最好不要让缴费出现空档。
- sentences to write yourself: 9

## sense 102657: 购房

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 拿钱去买房子给自己或家人住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其实，这两项权益并不会因为离职而自动中断，但若不主动办理转移手续，账户便可能长期滞留在原参保地，进而影响日后的购房贷款与退休待遇。
- sentences to write yourself: 9

## sense 102658: 购房

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指购买住房，通常指个人或家庭出钱买下房子，用来居住或投资。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102661: 人事部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 公司里管人来上班、找工作的人和工资的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 离职时，应向原单位的人事部门索取解除劳动关系的证明，并确认社保已缴至当月；入职新单位后，把材料交给新公司的人事专员，由其向当地经办机构提出转入申请。
- sentences to write yourself: 9

## sense 102662: 人事部门

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 机关、企业等单位里专门负责招聘、录用、考核、调动、工资和福利等员工事务的部门。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100903: 车位

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 停车的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老城区车位紧张，私人桩安装困难，车主只能依赖公共充电设施；而节假日期间，热门服务区的充电桩前常排起长队，等待时间甚至超过充电本身。
- sentences to write yourself: 9
