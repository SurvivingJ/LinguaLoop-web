# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1035`

Read `data/exercise_seeding/zh/wf2/r1035/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1035/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104331: 非常适合

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 很合适，用起来正好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这些数据在入库之前，必须先经过ETL流程，即抽取、转换、加载，按照预先设定的模式整理妥当，因此查询速度快，结果可靠，非常适合管理层进行固定的统计分析。
- sentences to write yourself: 9

## sense 104332: 非常适合

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 表示某人或某物对于某种用途、对象或情况来说十分合适、条件很好，常与“做”“用”“当”等搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103813: 掘开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把地面或土堆挖开，让里面的东西露出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 技术在提升效率的同时，也悄然掘开了一道数字鸿沟：一端是熟练滑动屏幕的年轻人，另一端是不知从何下手的老人。
- sentences to write yourself: 9

## sense 103814: 掘开

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词，指把土地、堤坝、土堆等挖开，使里面的东西露出来或使通道打开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103815: 从何下手

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 事情太多太乱，不知道先做什么，从哪里开始。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 技术在提升效率的同时，也悄然掘开了一道数字鸿沟：一端是熟练滑动屏幕的年轻人，另一端是不知从何下手的老人。
- sentences to write yourself: 9

## sense 103816: 从何下手

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 指面对一件事情或一个问题，不知道应该从哪里开始做起，常用来表示感到困难、没有头绪。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
