# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1035`

Read `data/exercise_seeding/zh/wf2/r1035/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1035/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103697: 一晃而过

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 很快地过去了，一下子就看不见了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 他看着年轻人举着手机一晃而过，觉得自己被隔在一层看不见的玻璃之外。
- sentences to write yourself: 9

## sense 103698: 一晃而过

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人或事物很快地从眼前经过，或时间、景象极快地消失，让人来不及看清或留住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102272: 吃火锅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指围着一口装有热汤的锅，把肉片、蔬菜、豆腐等食材放进去煮熟，边煮边吃。这种吃法常常是很多人一起，气氛热闹，在冬天特别受欢迎。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 周末与几位好友相约吃火锅，本是一件令人期待的事，可当各自的辣度承受力摆上桌面，气氛便微妙起来。
- sentences to write yourself: 9

## sense 102271: 吃火锅

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 一家人坐在一起，把菜和肉放进热汤里煮，煮好就吃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102405: 沉静

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 沉静就是很安静，不吵，也不着急。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 所幸店家端上一口鸳鸯锅，一半红汤翻涌，一半清汤沉静，两种截然不同的期待就此各得其所。
- sentences to write yourself: 9

## sense 102406: 沉静

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容人的心情、神态或环境安静平稳，不急躁，不喧闹。也可指性格稳重、不爱多说话。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
