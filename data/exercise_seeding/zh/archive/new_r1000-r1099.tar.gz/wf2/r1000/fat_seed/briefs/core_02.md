# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1000`

Read `data/exercise_seeding/zh/wf2/r1000/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1000/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102863: 大街小巷

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 大街小巷就是城里所有的路，大路小路都有。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 数以百万计的劳动者告别了固定的工位，转而以零工的形式谋生——他们驾驶网约车穿行于大街小巷，在写字楼间递送餐食，或守在屏幕前等待派工。
- sentences to write yourself: 9

## sense 102864: 大街小巷

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指城市或村镇里大大小小的街道和巷子，泛指到处、各个地方。常用来形容范围很广，如消息传得很广，或到处都是人和事物。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100870: 写明

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在文字中明确地表达出来
- learner tier: T3
- surface forms seen in tests: ["写明"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 合同写明，正常使用造成的损耗应由房东负责维修，只有人为损坏才可以从押金中扣除。
- sentences to write yourself: 9

## sense 100869: 写明

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 写清楚
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100858: 押

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 押金，指为担保而预先支付的一笔钱。
- learner tier: T3
- surface forms seen in tests: ["押"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 中介告诉他，房东要求押一付三，也就是先交一个月押金和三个月房租。
- sentences to write yourself: 9

## sense 100857: 押

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 押是钱，先给房东，以后会还给你。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
