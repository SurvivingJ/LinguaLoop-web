# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1000`

Read `data/exercise_seeding/zh/wf2/r1000/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1000/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102853: 工位

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 工位是上班时你坐着做事的那个小地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 数以百万计的劳动者告别了固定的工位，转而以零工的形式谋生——他们驾驶网约车穿行于大街小巷，在写字楼间递送餐食，或守在屏幕前等待派工。
- sentences to write yourself: 9

## sense 102854: 工位

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指工作场所中分配给个人或小组的固定位置，常指办公室里的座位和办公桌，也指工厂里工人操作机器的岗位。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102855: 零工

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 零工是做一天或几天就结束的短时间工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 数以百万计的劳动者告别了固定的工位，转而以零工的形式谋生——他们驾驶网约车穿行于大街小巷，在写字楼间递送餐食，或守在屏幕前等待派工。
  1. 按照现行规定，社保多依托稳定的劳动关系缴纳，而零工与平台之间往往只存在松散的合作协议，既无雇主为其分担费用，个人又常因收入起伏而中断缴费。
- sentences to write yourself: 8

## sense 102856: 零工

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指临时性的、不固定的短期工作，也指做这种工作的人。通常按天或按件计酬，没有长期合同。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102859: 递送

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西从一个地方拿到另一个地方，交给别人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 数以百万计的劳动者告别了固定的工位，转而以零工的形式谋生——他们驾驶网约车穿行于大街小巷，在写字楼间递送餐食，或守在屏幕前等待派工。
- sentences to write yourself: 9

## sense 102860: 递送

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把信件、包裹、文件、消息等送到指定的地点或交到某人手里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
