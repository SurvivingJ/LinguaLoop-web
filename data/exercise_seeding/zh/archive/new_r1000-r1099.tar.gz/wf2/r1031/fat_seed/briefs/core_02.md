# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1031`

Read `data/exercise_seeding/zh/wf2/r1031/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1031/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104213: 造假

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 造假就是把假的东西做成真的，骗别人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此外，考核方式若过分强调短期数字，还可能诱使团队为了达标而牺牲长期价值，甚至出现数据造假。
- sentences to write yourself: 9

## sense 104214: 造假

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 制造假的东西或虚假的情况，使人误以为是真的，常指伪造商品、数据、证件、账目等欺骗他人的行为。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104218: 误区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指因为认识不正确而长期存在的错误看法或做法，常指在某方面容易出错的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多管理者容易陷入“数据越多越好”的误区，结果指标繁杂，员工疲于应付，反而偏离了重点。
- sentences to write yourself: 9

## sense 104217: 误区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 误区就是大家常常想错、做错的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104221: 指标体系

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指标体系是一组用来量一量、比一比好不好的标准。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一套科学的指标体系，应当紧扣企业的核心目标：若目标是扩大市场份额，就应关注新客户增长率与客户留存率；若目标是提升运营效率，则需要考察单位成本与交付周期。
- sentences to write yourself: 9

## sense 104222: 指标体系

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指为了衡量、评价某件事或某个对象，按照一定的逻辑把多个相关的指标组合起来而形成的整体，常用于管理、经济、教育等领域。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
