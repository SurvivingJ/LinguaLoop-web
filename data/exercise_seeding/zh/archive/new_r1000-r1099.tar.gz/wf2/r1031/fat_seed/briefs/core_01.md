# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1031`

Read `data/exercise_seeding/zh/wf2/r1031/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1031/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104025: 达标

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 达标就是做到了要求，够好了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此外，考核方式若过分强调短期数字，还可能诱使团队为了达标而牺牲长期价值，甚至出现数据造假。
- sentences to write yourself: 9

## sense 104026: 达标

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 达到规定的标准或要求，多指成绩、质量、指标等符合规定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104029: 紧扣

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 紧紧连在一起，中间没有空隙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一套科学的指标体系，应当紧扣企业的核心目标：若目标是扩大市场份额，就应关注新客户增长率与客户留存率；若目标是提升运营效率，则需要考察单位成本与交付周期。
- sentences to write yourself: 9

## sense 104030: 紧扣

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指一个接一个、紧密相连，没有空隙或松懈；也指紧紧围绕某个主题或中心，不偏离。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104031: 诱使

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用好处或好话让别人去做事，那件事常常是不好的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此外，考核方式若过分强调短期数字，还可能诱使团队为了达标而牺牲长期价值，甚至出现数据造假。
- sentences to write yourself: 9

## sense 104032: 诱使

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用利益、谎言或其他办法引导、劝说别人去做原本不想做或不该做的事，多含贬义。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
