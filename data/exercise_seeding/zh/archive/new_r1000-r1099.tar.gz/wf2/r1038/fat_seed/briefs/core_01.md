# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1038`

Read `data/exercise_seeding/zh/wf2/r1038/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1038/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104409: 尽如人意

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 尽如人意是事情做得很好，和你想的一样，让你高兴。常说“不尽如人意”，就是没有那么好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 相反，欠拟合则源于模型“不够聪明”，它结构过于简单，或训练不充分，连数据中的基本规律都没有把握，因此无论在训练集还是测试集上，表现都不尽如人意。
- sentences to write yourself: 9

## sense 104410: 尽如人意

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 完全符合人的心意或愿望，让人满意。多用于否定形式“不尽如人意”，表示结果不太理想。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104412: 漏洞百出

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容说话、文章、计划或做事的毛病和错误非常多，到处都是漏洞，很不严密。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 倘若模型过于“聪明”，便容易陷入过拟合：它不仅学会了训练集中的普遍规律，还把偶然的噪声和个别细节当作真理，结果在训练集上成绩近乎完美，一到测试集便漏洞百出。
- sentences to write yourself: 9

## sense 104411: 漏洞百出

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 说的话或做的事有很多错，一点也不好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104413: 死记硬背

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 不懂意思，只是一遍一遍地背下来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这好比学生死记硬背往年试题，遇到新题就束手无策。
- sentences to write yourself: 9

## sense 104414: 死记硬背

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指不理解内容，只是机械地反复背诵、记住。多用来说明学习方法不好，没有真正弄懂。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
