# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1053`

Read `data/exercise_seeding/zh/wf2/r1053/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1053/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104350: 读出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指看着文字或符号，用声音把内容说出来；也指从声音、数据或文字中理解、辨认出某种意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一条“包装精美，但物流太慢”的评论，人一眼就能读出褒贬，机器却难以直接处理。
- sentences to write yourself: 9

## sense 104349: 读出

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看着字，用嘴把它说出声来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102009: 筛

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 筛是一种有很多小洞的工具，可以把大的东西和小的东西分开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 奶奶揉面，母亲调馅，父亲擀皮，孩子们负责把那些形状略显笨拙的成品摆进竹筛——分工并不固定，却自有一种默契。
- sentences to write yourself: 9

## sense 102010: 筛

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 筛：名词指用竹子或金属做成、有许多小孔的器具，用来把细东西漏下去、粗东西留下来；动词指用这种器具过滤东西，也可比喻挑选。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102011: 财运

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 财运就是得到钱的好运气。运气好，就会有很多钱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 人们真正在意的，或许并非财运，而是全家人能再一次围坐在一起，把平安与顺遂的愿望，一并包进那层薄薄的面皮里。
- sentences to write yourself: 9

## sense 102012: 财运

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个人在赚钱、得到财物方面的运气，常说财运好或财运不好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
