# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1053`

Read `data/exercise_seeding/zh/wf2/r1053/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1053/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104535: 专人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专人就是专门做一件事的那个人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了解决这一难题，研究人员往往先请专人对大量评论进行标注，例如把句子归为“好评”或“差评”，再让算法从中学习规律。
- sentences to write yourself: 9

## sense 104536: 专人

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指专门负责某项工作或任务的人，不由别人代替，也不同时做别的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104666: 太慢

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 表示速度或进度远低于需要或期望的程度，让人觉得不满意或来不及。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一条“包装精美，但物流太慢”的评论，人一眼就能读出褒贬，机器却难以直接处理。
- sentences to write yourself: 9

## sense 104665: 太慢

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 太慢就是动得不快，比我们想要的还慢。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104667: 褒贬

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 褒贬是说人好或不好。夸人是褒，批评人是贬。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一条“包装精美，但物流太慢”的评论，人一眼就能读出褒贬，机器却难以直接处理。
- sentences to write yourself: 9

## sense 104668: 褒贬

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指对人或事物的好坏作出评价，既包括称赞，也包括批评；也可指批评、指责，带有挑剔的意思。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
