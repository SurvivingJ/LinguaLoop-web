# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1039`

Read `data/exercise_seeding/zh/wf2/r1039/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1039/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103589: 野花

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 野花是在山上或路边自己长出来的花，不是人种的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 草地上遗留的垃圾、被踩秃的野花、深夜里过响的音乐，都在提醒我们：亲近自然并不意味着可以随意索取。
- sentences to write yourself: 9

## sense 103590: 野花

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在田野、山坡、路边等地方自然生长、不是人专门种植的花。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103591: 退一步

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 退一步就是往后走一小步，或者先不争了，让一让。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 露营之所以风靡，恰恰因为它提供了一种"退一步"的自由：一顶帐篷、一盏灯、一炉炭火，就足以把城市里的焦虑暂时留在身后。
- sentences to write yourself: 9

## sense 103592: 退一步

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 本义是向后退一步；常用来比喻在争执或做事时作出让步，或者换个角度、放宽要求来考虑问题。常见说法有“退一步说”“退一步海阔天空”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104257: 截距

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 截距是一条直线和一条数轴相交的那个点的数。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 算法通过不断调整直线的斜率与截距，使所有点到直线的整体误差降到最小，这一过程称为拟合。
- sentences to write yourself: 9

## sense 104258: 截距

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 数学名词，指直线或曲线与坐标轴相交的点到原点的距离或坐标值，常见的有在纵轴上的截距和在横轴上的截距。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
