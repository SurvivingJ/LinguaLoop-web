# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1012`

Read `data/exercise_seeding/zh/wf2/r1012/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1012/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103491: 值守

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 值守就是留在一个地方看着，不能走开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为降低清运成本，许多小区推行"定时定点"投放制度，即在早晚两个固定时段开放垃圾房，其余时间上锁，由志愿者现场值守，指导居民正确投放。
- sentences to write yourself: 9

## sense 103492: 值守

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在规定的岗位上守候、看管，负责保障安全或处理突发情况，常用于值班、守卫等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103493: 并排

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 并排就是几个人或东西一个挨着一个，站成一行。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着宣传深入和邻里相互提醒，多数人逐渐摸索出规律——在厨房并排放置两个容器，投放前稍作沥水，异味与蚊虫问题也随之缓解。
- sentences to write yourself: 9

## sense 103494: 并排

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指几个人或几样东西在同一水平线上紧挨着排列，不分前后。也可指并列、同时放在一起。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103495: 分不清

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看不出哪个是哪个，不知道它们有什么不一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对习惯随手丢弃的居民而言，这种转变起初难免带来不适：有人抱怨时间受限，有人分不清干湿界限。
- sentences to write yourself: 9

## sense 103496: 分不清

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指无法辨别或区分两个或多个事物、人或情况，不能弄清它们之间的差别。常用结构为“分不清A和B”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
