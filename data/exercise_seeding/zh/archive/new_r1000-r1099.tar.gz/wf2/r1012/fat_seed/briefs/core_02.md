# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1012`

Read `data/exercise_seeding/zh/wf2/r1012/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1012/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103497: 上锁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用锁把门或箱子关紧，别人就打不开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为降低清运成本，许多小区推行"定时定点"投放制度，即在早晚两个固定时段开放垃圾房，其余时间上锁，由志愿者现场值守，指导居民正确投放。
- sentences to write yourself: 9

## sense 103498: 上锁

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用锁把门、箱子、抽屉等关好，使别人不能随便打开或进入。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103503: 剩饭剩菜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 吃饭后没有吃完留下来的饭和菜。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 按照现行规定，家庭废弃物大致分为湿垃圾与干垃圾两类：前者指剩饭剩菜、果皮菜叶等易腐烂的有机物，后者包括纸巾、陶瓷碎片、一次性餐具等难以回收的物品。
- sentences to write yourself: 9

## sense 103504: 剩饭剩菜

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指吃完一顿饭后剩下没有吃完的饭和菜肴，通常可以保存起来下次再吃，也常用来说明浪费食物的问题。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103557: 摸索

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在不知道怎么做的时候，一点一点地试着找路或方法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而随着宣传深入和邻里相互提醒，多数人逐渐摸索出规律——在厨房并排放置两个容器，投放前稍作沥水，异味与蚊虫问题也随之缓解。
- sentences to write yourself: 9

## sense 103558: 摸索

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在不熟悉或看不清的情况下，一边试探一边寻找方向、门路或办法；也指在黑暗中用手探着找东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
