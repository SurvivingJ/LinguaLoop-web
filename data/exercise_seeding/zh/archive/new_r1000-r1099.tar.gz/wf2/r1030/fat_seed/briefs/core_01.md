# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1030`

Read `data/exercise_seeding/zh/wf2/r1030/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1030/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100211: 高下

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 谁好谁坏
- learner tier: T3
- surface forms seen in tests: ["高下"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 事实上，稳定与冒险之间并无高下之分。
- sentences to write yourself: 9

## sense 103077: 交织成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 很多东西缠在一起，变成一个整体。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对多数人而言，换乘是这段旅程中最考验耐心的环节：人们拖着背包，顺着指示牌在通道里快步穿行，脚步与广播声交织成一种独特的城市节奏。
- sentences to write yourself: 9

## sense 103078: 交织成

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指不同的事物、情感或线条等互相穿插、缠绕，结合在一起，形成一个整体或某种状态。常用于“A与B交织成……”的结构。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103079: 交叠

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 交叠就是几样东西一部分压在一起，或者几件事同时出现。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 地铁站台被通勤者填满，队伍沿着黄色安全线缓缓向前挪动；列车进站时，车门一开，人群便如潮水般涌向车厢，谁也无暇再讲究体面与距离——所谓早高峰的"挤"，并非某个人的过错，而是无数条生活轨迹在同一时刻被迫交叠的结果。
- sentences to write yourself: 9

## sense 103080: 交叠

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指几个物体、部分或事情在空间或时间上彼此重叠、交错在一起，有一部分相互覆盖或同时发生。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103081: 挪动

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 挪动就是让东西从这里移到那里，只动一点点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 地铁站台被通勤者填满，队伍沿着黄色安全线缓缓向前挪动；列车进站时，车门一开，人群便如潮水般涌向车厢，谁也无暇再讲究体面与距离——所谓早高峰的"挤"，并非某个人的过错，而是无数条生活轨迹在同一时刻被迫交叠的结果。
- sentences to write yourself: 9
