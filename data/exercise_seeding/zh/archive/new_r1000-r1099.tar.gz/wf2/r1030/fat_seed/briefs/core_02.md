# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1030`

Read `data/exercise_seeding/zh/wf2/r1030/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1030/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103082: 挪动

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把人或物体从原来的位置稍微移到另一个位置，移动的距离一般不大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103083: 潮水般

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 像水一样，很多很多，一下子涌过来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 地铁站台被通勤者填满，队伍沿着黄色安全线缓缓向前挪动；列车进站时，车门一开，人群便如潮水般涌向车厢，谁也无暇再讲究体面与距离——所谓早高峰的"挤"，并非某个人的过错，而是无数条生活轨迹在同一时刻被迫交叠的结果。
- sentences to write yourself: 9

## sense 103084: 潮水般

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 像潮水一样，形容数量很多、来势很猛，常用来说人群、声音、情绪等一下子大量涌来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100738: 安全线

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 安全线是在地铁站台等地方画的一条线，提醒人们不要越过，以保证安全。
- learner tier: T3
- surface forms seen in tests: ["安全线"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 地铁站台被通勤者填满，队伍沿着黄色安全线缓缓向前挪动；列车进站时，车门一开，人群便如潮水般涌向车厢，谁也无暇再讲究体面与距离——所谓早高峰的"挤"，并非某个人的过错，而是无数条生活轨迹在同一时刻被迫交叠的结果。
- sentences to write yourself: 9

## sense 100737: 安全线

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 安全线是地上画的线，告诉人们要站在它后面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101303: 涌向

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 很多人一起向一个地方去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 地铁站台被通勤者填满，队伍沿着黄色安全线缓缓向前挪动；列车进站时，车门一开，人群便如潮水般涌向车厢，谁也无暇再讲究体面与距离——所谓早高峰的"挤"，并非某个人的过错，而是无数条生活轨迹在同一时刻被迫交叠的结果。
- sentences to write yourself: 9
