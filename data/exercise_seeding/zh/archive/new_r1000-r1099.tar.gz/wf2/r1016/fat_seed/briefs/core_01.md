# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1016`

Read `data/exercise_seeding/zh/wf2/r1016/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1016/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103783: 牵引绳

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 牵引绳是一根绳子，一头在人手里，一头拴着小狗，带小狗走路用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 9

## sense 103784: 牵引绳

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用来牵着狗等动物行走、控制动物活动范围的绳子或带子，一端由人握住，另一端系在动物的脖子或胸背带上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103785: 拴绳

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 拴绳是用来绑住东西的绳子，比如拴住小狗。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 拴绳、清理、主动避让，这些微小的举动构成了文明养宠的底线。
- sentences to write yourself: 9

## sense 103786: 拴绳

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用来拴系人、动物或物品的绳子，使其不能随意走开或掉落；也可指用绳子拴住的动作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 88060: 责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 责备；要求做到。
- learner tier: T3
- surface forms seen in tests: ["责"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此类邻里纠纷看似琐碎，实则折射出居住伦理的缺失——养宠物者既享有陪伴之乐，亦须承担管束之责。
- sentences to write yourself: 9

## sense 88059: 责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 责是说别人做得不对，批评他。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
