# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1016`

Read `data/exercise_seeding/zh/wf2/r1016/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1016/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 97990: 槽

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 长条形、中间凹陷用来盛放东西或引导物体的器具或凹处。
- learner tier: T3
- surface forms seen in tests: ["槽"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有趣的是，全家人对同一个节目的反应常常大相径庭：祖母笑得直抹眼泪，我却觉得台词略显陈旧，忍不住在手机上低声吐槽。
- sentences to write yourself: 9

## sense 97989: 槽

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 槽是一个长长的、中间凹下去的东西，可以用来装水或装吃的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103645: 照例

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 照例是照以前的样子做，和往常一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 父亲照例占据沙发正中，母亲则忙着往茶几上摆瓜子与橘子。
- sentences to write yourself: 9

## sense 103646: 照例

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 按照惯例或以往的做法，和平常一样，不作改变。多用于描述某种已形成习惯的做法或安排。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103647: 窘迫

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 很没有钱，或者很难为情，不知道怎么办。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 歌舞与相声轮番登场，最令人期待的仍是那几个小品——它们常以家长里短为素材，把生活中的窘迫与温情夸张地铺展开来，笑过之后仍留一点回味。
- sentences to write yourself: 9

## sense 103648: 窘迫

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容处境困难，特别是缺钱，或者因为尴尬而不知所措，心里不安。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
