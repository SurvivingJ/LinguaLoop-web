# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1026`

Read `data/exercise_seeding/zh/wf2/r1026/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1026/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104473: 保护法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 保护法是一种规定，告诉大家要保护人和东西，不能伤害它们。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为此，我国出台了《个人信息保护法》，明确规定处理个人信息必须取得本人授权，并遵循最小必要原则，不得过度收集。
- sentences to write yourself: 9

## sense 104474: 保护法

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指国家为保护某类人、事物或环境而制定的法律，规定了保护的对象、方法和违反规定的后果，如未成年人保护法、野生动物保护法。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104475: 不法分子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 不法分子是做坏事、犯法的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦发生数据泄露，不法分子便可能利用这些信息实施诈骗，给当事人造成难以挽回的损失。
- sentences to write yourself: 9

## sense 104476: 不法分子

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指违反法律、从事犯罪或其他非法活动的人，多用于新闻、公文等较正式的场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103631: 借此

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 借着这件事，再做另一件事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 企业借此提供精准服务，却也让隐私面临前所未有的风险。
- sentences to write yourself: 9

## sense 103632: 借此

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 利用前面提到的机会或事情，来做另一件想做的事。多用于书面语，常放在句首或动词前。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
