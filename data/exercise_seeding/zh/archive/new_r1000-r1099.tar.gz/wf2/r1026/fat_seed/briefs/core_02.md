# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1026`

Read `data/exercise_seeding/zh/wf2/r1026/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1026/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104281: 挽回

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把快要失去的东西再找回来，让事情变好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一旦发生数据泄露，不法分子便可能利用这些信息实施诈骗，给当事人造成难以挽回的损失。
- sentences to write yourself: 9

## sense 104282: 挽回

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 使已经出现或将要出现的不好的情况恢复原状，或把失去的东西、关系、局面重新争取回来。常与损失、局面、感情、面子等搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104283: 更正

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把说错或写错的话改成对的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 同时，法律赋予个人查阅、更正乃至删除自己信息的权利。
- sentences to write yourself: 9

## sense 104284: 更正

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指改正已发表或已说出的文字、言论中的错误，使之正确，多用于公开声明、报道或文件中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104285: 一举一动

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 一举一动是说一个人做的每一个动作，大人和小孩的都可以。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在大数据时代，我们的一举一动几乎都会被记录下来：购物偏好、出行轨迹、搜索记录，经过算法分析后，往往能勾勒出一个人的完整画像。
- sentences to write yourself: 9

## sense 104286: 一举一动

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指一个人的每一个动作和行为，常用来说明某人被人注意、观察或监视。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
