# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1010`

Read `data/exercise_seeding/zh/wf2/r1010/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1010/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104143: 即便如此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: 就算前面说的那样，后面的事也不会变。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 即便如此，拒绝回答的人群、措辞带有倾向的问题，仍可能扭曲结果。
- sentences to write yourself: 9

## sense 104144: 即便如此

- reading: (none)
- dictionary POS hint: conjunction. The enum below wins over this hint.
- existing definition: 连词，用在后一句开头，表示承认前面说的情况是真的，但结果或看法不会因此改变，意思是“即使这样”“尽管这样”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104146: 均等

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 指数量、机会或权利等各方面相同，没有多少、高低的差别；也指平均、相等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了提升样本的代表性，研究者通常采用随机抽样，让总体中每个人都有均等的机会被选中，从而尽可能避免人为的挑选。
- sentences to write yourself: 9

## sense 104145: 均等

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 均等就是每个人分到的一样多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104147: 随机抽样

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 不挑不选，让每一个都有同样的机会被拿到，再从中取一些来看。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 为了提升样本的代表性，研究者通常采用随机抽样，让总体中每个人都有均等的机会被选中，从而尽可能避免人为的挑选。
- sentences to write yourself: 9

## sense 104148: 随机抽样

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指从全体对象中不加人为选择，使每个个体被选中的机会相同，抽出一部分作为样本，用来调查或研究。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
