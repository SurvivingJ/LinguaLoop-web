# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1047`

Read `data/exercise_seeding/zh/wf2/r1047/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1047/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104071: 锣鼓声

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 锣和鼓一起敲时发出的响声，很热闹。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 庙会多在庙宇周边的街巷里铺开，摊贩挨着摊贩，糖画、剪纸、泥人、旧书旧唱片挤在一处，叫卖声与锣鼓声彼此叠压。
- sentences to write yourself: 9

## sense 104072: 锣鼓声

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 敲锣打鼓时发出的声音，常出现在节日、庆典、舞龙舞狮或戏曲表演中，给人热闹喜庆的感觉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104073: 七嘴八舌

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 很多人一起说话，你说一句，他说一句，声音很乱。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 人们最惦记的往往是猜灯谜：谜条垂在灯下，猜中者可取下换取一份小小的彩头，围观者七嘴八舌，猜错时哄然一笑，那份热闹便从一个人身上传到整条街。
- sentences to write yourself: 9

## sense 104074: 七嘴八舌

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人多嘴杂，大家纷纷发言，你一言我一语，场面热闹或有些吵乱。常用来描写许多人同时讨论或议论的情景。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103769: 河堤

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 河堤是河边用土和石头堆成的高墙，可以挡住河水。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 入夜后灯会接上班，成串灯笼沿着河堤与老街一路铺展，灯影在水面上碎成晃动的金色。
- sentences to write yourself: 9

## sense 103770: 河堤

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 沿河岸修筑的高出地面的堤坝，用来挡住河水，防止洪水泛滥。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
