# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1047`

Read `data/exercise_seeding/zh/wf2/r1047/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1047/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103775: 裹挟

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大风或水把东西一起卷走，人也被带着走，自己不能决定。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 灯火终会熄灭，摊子也会散尽，但那种被人群裹挟着共同欢腾的经验，会成为此后许多年里人们对"过年"最具体的记忆。
- sentences to write yourself: 9

## sense 103776: 裹挟

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指被强大的力量（如水流、风、潮流、势力）带着一起走，使人身不由己；也指把人或事卷入某种局面或行动之中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103925: 围观者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 围观者是站在旁边看热闹的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 人们最惦记的往往是猜灯谜：谜条垂在灯下，猜中者可取下换取一份小小的彩头，围观者七嘴八舌，猜错时哄然一笑，那份热闹便从一个人身上传到整条街。
- sentences to write yourself: 9

## sense 103926: 围观者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指聚集在某处，对发生的事情（如争吵、事故、表演等）站在一旁观看，但通常不参与其中的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104063: 叠压

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 东西一层放在另一层上面，把下面的盖住了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 庙会多在庙宇周边的街巷里铺开，摊贩挨着摊贩，糖画、剪纸、泥人、旧书旧唱片挤在一处，叫卖声与锣鼓声彼此叠压。
- sentences to write yourself: 9

## sense 104064: 叠压

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指一个物体压在另一个物体上，或几层东西上下重叠地压在一起；也指地层、遗迹、线条等在空间上前后重叠，下面的被上面的盖住。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
