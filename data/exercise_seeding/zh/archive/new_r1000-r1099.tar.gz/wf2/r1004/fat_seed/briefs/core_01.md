# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1004`

Read `data/exercise_seeding/zh/wf2/r1004/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1004/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103229: 直达

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 直达就是中间不停，一下子就到那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
- sentences to write yourself: 9

## sense 103230: 直达

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 中途不停留、不换乘，直接到达目的地。常用于交通工具，如直达车、直达航班。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104767: 明显改善

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 以前不太好，现在好了很多，大家一看就知道。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某些原本绕行过远的公交线路，经过优化后缩短了行程时间，乘客的候车体验也明显改善。
- sentences to write yourself: 9

## sense 104768: 明显改善

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指情况、状态或条件比以前好了很多，而且变化很清楚，很容易被人看出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104769: 高峰期

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人最多、最忙的那一段时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 经过脱敏处理后，这些记录能够勾勒出人群在不同时段、不同区域之间的流动轨迹，从而揭示通勤高峰期的主要出行走向。
- sentences to write yourself: 9

## sense 104770: 高峰期

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指某种活动、需求或流量达到最多、最强的时期，如交通、用电、客流等最集中的一段时间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
