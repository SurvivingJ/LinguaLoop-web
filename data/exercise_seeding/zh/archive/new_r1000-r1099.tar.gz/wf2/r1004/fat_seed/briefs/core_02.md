# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1004`

Read `data/exercise_seeding/zh/wf2/r1004/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1004/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104771: 收发

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 收发就是收下东西，再把东西送出去，像收信和寄信。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 手机在通话、收发短信或切换基站时，会留下匿名的位置记录。
- sentences to write yourself: 9

## sense 104772: 收发

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指接收和发出（信件、文件、邮件、信号等）；也指负责接收和发送文件、信件的工作。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104773: 不断扩大

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 越来越大，一直变大。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 随着城市规模不断扩大，居民的出行需求日益多样，传统的公交线路规划往往依赖人工调查，样本有限、周期漫长，难以及时反映真实的客流变化。
- sentences to write yourself: 9

## sense 104774: 不断扩大

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指范围、规模、数量等持续地变大，没有停下来，常用来说明事物的发展变化。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104775: 尤为重要

- reading: (none)
- dictionary POS hint: nr. The enum below wins over this hint.
- existing definition: 尤为重要就是特别特别重要，比别的都重要。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其中，手机信令数据尤为重要。
- sentences to write yourself: 9

## sense 104776: 尤为重要

- reading: (none)
- dictionary POS hint: nr. The enum below wins over this hint.
- existing definition: 表示在许多重要的事物中，某一件事物格外重要、特别突出，常用来强调某个方面的重要程度。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
