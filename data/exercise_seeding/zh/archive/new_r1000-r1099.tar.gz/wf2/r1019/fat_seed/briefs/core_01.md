# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1019`

Read `data/exercise_seeding/zh/wf2/r1019/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1019/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103833: 放在心上

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 心里一直想着这件事，觉得它很重要。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 归根结底，得体的沟通不在于辞藻华丽，而在于把对方的处境放在心上。
- sentences to write yourself: 9

## sense 103834: 放在心上

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把某件事或某个人记在心里，认真对待，十分在意。多用于否定句或劝说的话里，如“别放在心上”表示不要计较、不要在意。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103835: 卑微

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 卑微是说一个人觉得自己很小，很不重要，别人也不看重他。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其次是措辞，语气应当谦和而不卑微，请求指导时多用商量的口吻，避免生硬的命令式句子。
- sentences to write yourself: 9

## sense 103836: 卑微

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容人的地位低下、身份低微，或指人在态度上显得低声下气、没有自信。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103837: 客套

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 客套是见面时说的好听又有礼貌的话，有时不是真心的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 首要的一环是称呼：向长辈或上司发消息时不宜直呼其名，更不宜省略称谓，一句得体的"张老师""李经理"，往往比冗长的客套更能传递敬意。
- sentences to write yourself: 9

## sense 103838: 客套

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指待人接物时说一些表示礼貌、谦让的话或做出相应的举动，往往带有形式化的成分；也指这类礼貌的话。可作动词或名词，常用于劝人不必过分讲礼。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
