# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1048`

Read `data/exercise_seeding/zh/wf2/r1048/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1048/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103901: 代劳

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 代劳就是你帮别人做事，让他不用自己做。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当越来越多的决定被交付给算法，人们渐渐失去对家中环境的直觉判断：室温究竟该是多少，或许早已由程序代劳。
- sentences to write yourself: 9

## sense 103902: 代劳

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 代替别人做事或承担工作，多用于请求或感谢别人帮忙，常带有客气的语气。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103903: 智能家居

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 智能家居是家里的灯、门和电视，可以用手机或说话来开关。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 过去十几年间，智能家居系统悄然走进普通人的日常生活。
  1. 因此，如何在享受便利与保持自主之间寻得平衡，已成为智能家居时代一道耐人寻味的课题。
- sentences to write yourself: 8

## sense 103904: 智能家居

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指利用网络和智能技术，把家里的灯光、空调、门锁、电器等设备连接起来，让人可以用手机或语音远程控制，使生活更方便、舒适和安全的家庭系统。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103905: 手足无措

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 遇到急事，不知道怎么做，手和脚都不知放哪里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更值得警惕的是，一旦网络中断或设备失灵，习惯了发号施令的人往往手足无措。
- sentences to write yourself: 9

## sense 103907: 手足无措

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人遇到突然或困难的情况时慌乱紧张，不知道该怎么办。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
