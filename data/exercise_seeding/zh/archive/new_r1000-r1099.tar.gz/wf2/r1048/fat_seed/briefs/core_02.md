# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1048`

Read `data/exercise_seeding/zh/wf2/r1048/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1048/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104117: 凝练

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 凝练是话很少，可是意思很清楚，一点不多余。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 方差正是为弥补这一缺憾而生：它把每个数据与均值的离差平方后求平均，从而将整体的离散程度凝练为一个数值。
- sentences to write yourself: 9

## sense 104118: 凝练

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容文字、语言或表达简洁精练，没有多余的内容，却能把意思表达得清楚到位。也可作动词，表示使内容变得简洁精练。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102467: 比拼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 比拼就是大家一起比，看谁做得更好。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种“地下化”带来的后果耐人寻味——课外辅导从明码标价的市场行为，变成了比拼人脉与信息的不平等竞争，无力支付高价家教的普通家庭反而更加被动。
- sentences to write yourself: 9

## sense 102468: 比拼

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 双方或多方在能力、技术、水平等方面互相较量，争个高低。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102469: 课外辅导

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 放学以后，有老师教小朋友学功课。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种“地下化”带来的后果耐人寻味——课外辅导从明码标价的市场行为，变成了比拼人脉与信息的不平等竞争，无力支付高价家教的普通家庭反而更加被动。
- sentences to write yourself: 9

## sense 102470: 课外辅导

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指学生在学校正常上课之外，参加的额外学习辅导，如补习班或请家教，目的是巩固知识或提高成绩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
