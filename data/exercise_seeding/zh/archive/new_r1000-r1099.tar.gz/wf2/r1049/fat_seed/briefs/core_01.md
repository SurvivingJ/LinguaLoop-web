# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1049`

Read `data/exercise_seeding/zh/wf2/r1049/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1049/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102521: 减轻负担

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 让别人不那么累，不那么难。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，减轻负担若要真正落地，恐怕不能只盯着补习班这一端，还需从考试评价与优质资源的分配上寻找答案。
- sentences to write yourself: 9

## sense 102522: 减轻负担

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指让人身上的压力、责任或工作变少，使人感到轻松一些。这里的负担可以是学习、工作、生活或金钱方面的压力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102525: 转入地下

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 不让别人看见，偷偷地做事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，需求并未随之消失，只是转入地下：一对一家教的价格翻了数倍，家长托熟人在居民楼里租下房间，冒着被查的风险继续给孩子补数学。
- sentences to write yourself: 9

## sense 102526: 转入地下

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指组织或活动被禁止或受到压制后，不再公开进行，改为秘密进行。也可指事物从公开状态转为隐蔽状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102527: 明码标价

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 东西上写好价钱，大家都能看见，不会骗人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种“地下化”带来的后果耐人寻味——课外辅导从明码标价的市场行为，变成了比拼人脉与信息的不平等竞争，无力支付高价家教的普通家庭反而更加被动。
- sentences to write yourself: 9

## sense 102528: 明码标价

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指商品在出售时清楚地标出价格，价格公开透明，不隐瞒，也不随意变动。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
