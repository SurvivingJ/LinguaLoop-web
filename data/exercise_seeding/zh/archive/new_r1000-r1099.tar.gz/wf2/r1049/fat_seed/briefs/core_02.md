# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1049`

Read `data/exercise_seeding/zh/wf2/r1049/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1049/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102529: 独木桥

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 独木桥是用一根木头搭成的小桥，很窄，走起来要小心。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 只要升学的独木桥依旧狭窄，教育焦虑就会寻找新的出口：有人转向体育与艺术培训，有人干脆亲自辅导。
- sentences to write yourself: 9

## sense 102530: 独木桥

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用一根圆木搭成的窄桥，多架在小河或山沟上，走时容易掉下去。也常比喻只有一条路可走，或者很艰难、很危险的处境，如“千军万马过独木桥”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102345: 补习班

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 补习班是学校以外的地方，小朋友在那里再学功课。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. “双减”政策出台后，学科类补习班大面积收缩，不少机构一夜之间关门歇业。
  1. 因此，减轻负担若要真正落地，恐怕不能只盯着补习班这一端，还需从考试评价与优质资源的分配上寻找答案。
- sentences to write yourself: 8

## sense 102346: 补习班

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指在学校正常课程之外，专门为学生补充知识、提高成绩或准备考试而开设的班级或培训机构。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102347: 关门歇业

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 店不开了，不再做生意。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. “双减”政策出台后，学科类补习班大面积收缩，不少机构一夜之间关门歇业。
- sentences to write yourself: 9

## sense 102348: 关门歇业

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指商店、公司等停止营业，可能是暂时休息，也可能是不再经营。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
