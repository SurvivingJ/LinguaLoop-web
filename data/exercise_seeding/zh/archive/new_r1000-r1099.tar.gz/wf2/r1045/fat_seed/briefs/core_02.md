# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1045`

Read `data/exercise_seeding/zh/wf2/r1045/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1045/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103131: 服务区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 服务区是在高速路边的地方，开车的人可以在这里上厕所、吃饭和休息。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 老城区车位紧张，私人桩安装困难，车主只能依赖公共充电设施；而节假日期间，热门服务区的充电桩前常排起长队，等待时间甚至超过充电本身。
- sentences to write yourself: 9

## sense 103132: 服务区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 设在高速公路等道路旁边，为司机和乘客提供休息、停车、加油、用餐、上厕所等服务的区域。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103199: 高速行驶

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 车开得很快，走得很快。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 厂商宣传的续航里程多是在理想工况下测得的，而实际驾驶中，冬季低温、空调能耗与高速行驶都会大幅折损这一数字，标称五百公里的车型，可能只跑三百余公里便需寻找电源。
- sentences to write yourself: 9

## sense 103200: 高速行驶

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指汽车、火车等交通工具以很快的速度向前行进，速度远高于一般行驶速度，常用于公路、铁路等场合。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103263: 购车者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 想买车的人，或者刚买了车的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，理性购车者会先摸清住所与通勤路线沿线的充电条件，再权衡补贴力度与车型性能，而非仅仅被低价或新颖的外观所吸引。
- sentences to write yourself: 9

## sense 103264: 购车者

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指购买汽车的人，多用于介绍汽车市场、销售或消费情况的语境中。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
