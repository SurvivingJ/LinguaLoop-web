# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1022`

Read `data/exercise_seeding/zh/wf2/r1022/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1022/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104615: 出发点

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 出发点是你开始走的地方，也是做事情开始想的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 相比之下，数据驱动的决策强调以可验证的事实为出发点。
- sentences to write yourself: 9

## sense 104616: 出发点

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指行程开始的地点；也比喻考虑问题或做事情时的起点、基本立场或最初的目的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104619: 激增

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 很快变得特别多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9

## sense 104620: 激增

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指数量在短时间内迅速大幅增加，多用于人数、数量、价格、需求等方面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104621: 一脉相承

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 一脉相承是说一代一代传下来，前后很像，是一条线上来的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种做法与医学领域的循证理念一脉相承：结论必须经得起证据检验，而非取决于资历深浅。
- sentences to write yourself: 9

## sense 104622: 一脉相承

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容思想、学说、风格、文化等从一个源头传承下来，前后连贯，有紧密的继承关系，没有中断。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
