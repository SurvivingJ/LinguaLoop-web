# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1022`

Read `data/exercise_seeding/zh/wf2/r1022/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1022/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104497: 餐饮企业

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 餐饮企业是卖饭菜给人吃的地方，像饭馆和快餐店。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9

## sense 104498: 餐饮企业

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指从事饭菜、饮料的制作和销售，为顾客提供用餐服务的企业或商家，如饭店、餐馆、快餐店、咖啡馆等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104499: 二者之间

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 说的是两个东西的中间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 真正成熟的管理者，往往能在二者之间取得平衡，让直觉接受数据的检验。
- sentences to write yourself: 9

## sense 104500: 二者之间

- reading: (none)
- dictionary POS hint: l. The enum below wins over this hint.
- existing definition: 指在前面提到的两个人、事物或情况的中间，常用来说明两者的关系、差别或选择。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104501: 怨声载道

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 很多人都在大声说不好，因为大家都很不高兴。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9

## sense 104502: 怨声载道

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容人民群众普遍心怀不满，到处都是怨恨、不满的声音。多用来说明某种政策、做法或情况让很多人感到不满。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
