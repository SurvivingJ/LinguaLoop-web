# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1051`

Read `data/exercise_seeding/zh/wf2/r1051/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1051/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103545: 人山人海

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 人山人海是说地方里的人特别特别多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 进了景区,所谓游览更像被人流推着前行:观景台上摩肩接踵,拍一张照要排半天队,人山人海,举步维艰。
- sentences to write yourself: 9

## sense 103546: 人山人海

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容聚集的人非常多，像山和海一样，多用来描写车站、景区、广场、节日等热闹拥挤的场面。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101000: 该补

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 表示应该补充或补上某事物，常用于指出缺失的部分需要弥补。
- learner tier: T3
- surface forms seen in tests: ["该补"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 学会与人群保持距离,或许才是当代旅行者最该补上的一课。
- sentences to write yourself: 9

## sense 100999: 该补

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 应该补上
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103599: 黄金周

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 黄金周是一年里放假很多天的一个星期，大家可以出去玩。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 每年黄金周,国内热门景区几乎都在上演同一场"人潮大戏"。
- sentences to write yourself: 9

## sense 103600: 黄金周

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指连着放假的一段时间，通常有七天左右，多在春节和国庆节前后。这段时间里很多人外出旅游或回家，旅游业和商业特别热闹。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
