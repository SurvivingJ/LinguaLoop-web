# Fat-seed review 02 (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1051`

Read `data/exercise_seeding/zh/wf2/r1051/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/zh/wf2/r1051/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/zh/wf2/r1051/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/zh/wf2/r1051/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/zh/wf2/r1051/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 103545: 人山人海
- sense 103546: 人山人海
- sense 101000: 该补
- sense 100999: 该补
- sense 103599: 黄金周
- sense 103600: 黄金周
