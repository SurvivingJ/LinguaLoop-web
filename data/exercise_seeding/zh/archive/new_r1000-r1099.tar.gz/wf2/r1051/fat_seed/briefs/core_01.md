# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1051`

Read `data/exercise_seeding/zh/wf2/r1051/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1051/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103457: 观景台

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 观景台是一个高高的地方，人们站在上面看风景。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 进了景区,所谓游览更像被人流推着前行:观景台上摩肩接踵,拍一张照要排半天队,人山人海,举步维艰。
- sentences to write yourself: 9

## sense 103458: 观景台

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专门修建在高处或风景优美的地方，供人站在上面观赏周围景色的平台或建筑。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103539: 没亮

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 天还黑着，外面没有光。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 天还没亮,山门外的队伍已蜿蜒数里,游客攥着手机反复刷新页面,唯恐门票预约名额在几分钟内被抢空。
- sentences to write yourself: 9

## sense 103540: 没亮

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指天色还没有变亮，或者灯、屏幕等没有发出光，处于暗的状态。也可以说发光的东西没有亮起来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103541: 错峰

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大家不在同一个时间去做同一件事，这样人就不会太多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人把假期拆成两段,错峰前往;有人放弃网红景点,转向名气不大却风景清幽的小城与村落。
- sentences to write yourself: 9

## sense 103542: 错峰

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把上班、上学、出行、用电、旅游等活动的时间错开，避开人多拥挤的高峰时段，以减少拥堵或压力。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
