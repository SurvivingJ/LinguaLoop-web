# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1003`

Read `data/exercise_seeding/zh/wf2/r1003/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1003/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104701: 新思路

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 新思路就是解决事情的新办法，和以前不一样。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 交通大数据的兴起，为破解这一难题提供了新思路。
- sentences to write yourself: 9

## sense 104702: 新思路

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指解决问题或做事情时想出的新的思考方向和办法，与以往的做法不同。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104703: 居住区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 居住区是很多人住的地方，有很多房子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 规划部门借助这些分析结果，可以发现哪些居住区与就业中心之间缺乏直达班次，哪些路段长期拥堵，进而有针对性地增设线路、调整站点或加密发车间隔。
- sentences to write yourself: 9

## sense 104704: 居住区

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 城市或地区中专门供人们居住生活的区域，通常有住宅楼、道路、绿地和学校、商店等生活设施，与工业区、商业区等相区别。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104708: 候车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指在车站或站台等待公共汽车、火车等交通工具到来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某些原本绕行过远的公交线路，经过优化后缩短了行程时间，乘客的候车体验也明显改善。
- sentences to write yourself: 9

## sense 104707: 候车

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 候车就是站在车站，等车来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
