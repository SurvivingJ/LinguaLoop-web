# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1036`

Read `data/exercise_seeding/zh/wf2/r1036/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1036/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100238: 冒汗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指人身上流出汗水，常因为热或害怕。
- learner tier: T3
- surface forms seen in tests: ["冒汗"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人无辣不欢，声称唯有那股直冲鼻腔的麻辣才算得上真正的滋味；有人则一闻花椒便额头冒汗，只敢点微辣。
- sentences to write yourself: 9

## sense 100237: 冒汗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 出汗
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102409: 葱花

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 葱花是切得很碎的小块葱，放在饭菜里，让饭菜更香。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 蘸料台前的取舍同样耐人寻味：嗜辣者层层叠叠地舀上辣椒与蒜末，仿佛生怕味道不足；清淡者只添少许香油与葱花，力求守住食材本味。
- sentences to write yourself: 9

## sense 102410: 葱花

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 把葱切成的细小碎末，常撒在汤、面条或炒菜里，用来增加香味和美观。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102411: 鸳鸯锅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 鸳鸯锅是一个锅，中间分成两边，一边辣，一边不辣，可以同时煮东西吃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 所幸店家端上一口鸳鸯锅，一半红汤翻涌，一半清汤沉静，两种截然不同的期待就此各得其所。
- sentences to write yourself: 9

## sense 102412: 鸳鸯锅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一种中间有隔板、把锅分成两个部分的火锅，通常一边是辣汤，一边是清汤或不辣的汤，方便口味不同的人一起吃。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
