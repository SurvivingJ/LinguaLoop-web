# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1036`

Read `data/exercise_seeding/zh/wf2/r1036/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1036/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102215: 舀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用勺子把汤或水从东西里拿出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 蘸料台前的取舍同样耐人寻味：嗜辣者层层叠叠地舀上辣椒与蒜末，仿佛生怕味道不足；清淡者只添少许香油与葱花，力求守住食材本味。
- sentences to write yourself: 9

## sense 102216: 舀

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用勺子、瓢等工具把液体或颗粒状的东西取出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102099: 翻涌

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 水或云一团一团地往上冒，动得很厉害。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 所幸店家端上一口鸳鸯锅，一半红汤翻涌，一半清汤沉静，两种截然不同的期待就此各得其所。
- sentences to write yourself: 9

## sense 102100: 翻涌

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指水流、云雾等大幅度地起伏滚动；也比喻情绪、思绪等强烈地涌上心头，难以平静。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102357: 蒜末

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 蒜末是把大蒜切得很碎很碎的小粒，做菜时放进去。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 蘸料台前的取舍同样耐人寻味：嗜辣者层层叠叠地舀上辣椒与蒜末，仿佛生怕味道不足；清淡者只添少许香油与葱花，力求守住食材本味。
- sentences to write yourself: 9

## sense 102358: 蒜末

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指把大蒜切成或剁成的极细小的碎粒，常用来给菜肴、调料增添香味。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
