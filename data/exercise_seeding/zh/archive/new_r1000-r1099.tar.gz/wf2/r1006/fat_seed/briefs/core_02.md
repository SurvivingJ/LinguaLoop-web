# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1006`

Read `data/exercise_seeding/zh/wf2/r1006/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1006/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 100038: 差评

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指对商品、服务等表示不满或批评的评价
- learner tier: T3
- surface forms seen in tests: ["差评"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 一旦遇到电梯拥堵、暴雨或交通管制，超时便可能随之而来；而消费者在等待中产生的焦虑，又容易转化为差评。
  1. 对骑手而言，差评不仅意味着收入受损，也可能影响后续接单机会。
- sentences to write yourself: 8

## sense 100037: 差评

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 不好的评价
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100905: 搬走

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 离开原来的地方
- learner tier: T3
- surface forms seen in tests: ["搬走"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 于是，记忆成了一种无处安放之物——它既不能被写进产权证书，也无法随砖瓦一同搬走。
- sentences to write yourself: 9

## sense 85818: 待

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 停留；逗留；也指对人对事采取某种态度。
- learner tier: T3
- surface forms seen in tests: ["待"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 城市更新与人文留存之间的张力，仍待慢慢调和。
- sentences to write yourself: 9

## sense 85817: 待

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 待是留在一个地方，不走开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99921: 饭菜

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 饭菜就是吃的食物。
- learner tier: T3
- surface forms seen in tests: ["饭菜"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对于确实吃不完的饭菜，主动打包既方便又务实，可以减少不必要的损失。
- sentences to write yourself: 9
