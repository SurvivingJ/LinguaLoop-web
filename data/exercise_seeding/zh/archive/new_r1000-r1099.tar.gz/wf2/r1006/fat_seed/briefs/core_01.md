# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1006`

Read `data/exercise_seeding/zh/wf2/r1006/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1006/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102701: 化为乌有

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 本来有的东西，一下子全都没有了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在许多普通家庭里，一场突如其来的大病足以让多年的积蓄化为乌有。
- sentences to write yourself: 9

## sense 102702: 化为乌有

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指原本存在的事物完全消失，什么都没有留下，多用于形容希望、财产、努力、计划等落空或被毁掉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102703: 落到实处

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 想好的事，真的去做，做出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 对普通家庭而言，医保是必需的安全网；只有把大病保障、异地结算与基层医疗真正落到实处，这张网才不会在最需要的时候出现漏洞。
- sentences to write yourself: 9

## sense 102704: 落到实处

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把计划、政策、要求、想法等真正付诸行动，取得实际的结果，而不只是停留在口头或纸面上。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 91502: 院

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 房屋周围用墙围起来的空地；某些机构的名称。
- learner tier: T3
- surface forms seen in tests: ["院"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 李阿姨的老伴去年被确诊为重症，住院、手术加上长期用药，前后花费近四十万元。
  1. 虽然医保为他们报销了大部分住院费用，但进口药、特护病房以及院外购买的药品并不在目录之内，只能全部自费，这部分开销最终仍压得全家喘不过气。
- sentences to write yourself: 8

## sense 91501: 院

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 院是房子前面或四周围起来的一块空地。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
