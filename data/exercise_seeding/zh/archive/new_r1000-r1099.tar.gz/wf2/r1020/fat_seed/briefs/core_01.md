# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1020`

Read `data/exercise_seeding/zh/wf2/r1020/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1020/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 91324: 怒

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 生气；愤怒。
- learner tier: T3
- surface forms seen in tests: ["怒"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 有些司机在红灯变绿后急于前行，遇到行人慢慢走过便按喇叭、皱眉，甚至出言抱怨，这种情绪就是路怒。
  1. 路怒看似只是一时的急躁，却可能让路口变得危险，也会破坏城市的秩序。
- sentences to write yourself: 8

## sense 91323: 怒

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 怒是很生气的样子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 93730: 响

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 发出声音；声音大。
- learner tier: T3
- surface forms seen in tests: ["响"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这项制度看似寻常，实则体现了一种朴素的关怀：与其等到病痛袭来才四处求医，不如在身体尚未拉响警报之时，主动去了解它真实的状况。
- sentences to write yourself: 9

## sense 93729: 响

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 响是发出声音。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102957: 发到

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西送给别人，一直送到那个地方或那个人手里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 两周之后，报告陆续发到每个人手中。
- sentences to write yourself: 9

## sense 102958: 发到

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把东西分发、寄送或传送，使其到达某个地点或某人手中；也可指发送到某个范围或某个时间点。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
