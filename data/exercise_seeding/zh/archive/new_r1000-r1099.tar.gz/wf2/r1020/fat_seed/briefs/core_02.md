# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1020`

Read `data/exercise_seeding/zh/wf2/r1020/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1020/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102959: 抽血

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 医生用针从你的手臂里拿出一点血。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 抽血、拍片、测心电图，各项检查依次进行，前后不过两个小时。
- sentences to write yourself: 9

## sense 102960: 抽血

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 用针管从人的血管里取出少量血液，通常是为了检查身体或者献血。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102961: 袭来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 很快地向这里来，让人感到突然。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这项制度看似寻常，实则体现了一种朴素的关怀：与其等到病痛袭来才四处求医，不如在身体尚未拉响警报之时，主动去了解它真实的状况。
- sentences to write yourself: 9

## sense 102962: 袭来

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指某种力量、情绪、天气或自然现象等突然而猛烈地朝人或地方扑来、到来。常用于寒冷、风雨、疲倦、灾害、敌人进攻等。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103017: 低声

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 低声就是说话的声音很小，别人不容易听到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 体检当天，走廊里排起长队，同事们低声交谈，气氛轻松得近乎一场集体出游。
- sentences to write yourself: 9

## sense 103018: 低声

- reading: (none)
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: 指说话时压低声音，音量很小，常用于怕打扰别人、说悄悄话或表达情绪低落的时候。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
