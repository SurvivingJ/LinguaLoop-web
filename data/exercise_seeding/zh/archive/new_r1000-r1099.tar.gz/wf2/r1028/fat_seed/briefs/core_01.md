# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1028`

Read `data/exercise_seeding/zh/wf2/r1028/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1028/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102679: 难以忍受

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 事情太难受了，让你一点也不想再碰到它。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而对住在附近的上班族来说，持续数小时的音响却成了难以忍受的噪音。
- sentences to write yourself: 9

## sense 102680: 难以忍受

- reading: (none)
- dictionary POS hint: adjective. The enum below wins over this hint.
- existing definition: 形容某种痛苦、不适或讨厌的情况程度很重，让人无法承受或不能再忍耐。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102799: 老龄化

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 老人在人里越来越多，年轻人越来越少。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这场关于广场舞扰民的争议看似琐碎，实则折射出老龄化社会中公共空间与私人生活的边界之争。
- sentences to write yourself: 9

## sense 102800: 老龄化

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指一个国家或地区的人口中，老年人所占的比例越来越高的现象或过程。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102801: 夜班

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 夜班是晚上上的班，大家在天黑以后做事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人抱怨孩子无法安心写作业，有人因夜班后补不了眠而心生怨气，物业调解多次仍收效甚微。
- sentences to write yourself: 9

## sense 102802: 夜班

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指工人、医生、警察等在夜间进行的工作班次，通常从晚上到第二天early早晨，与白班相对。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
