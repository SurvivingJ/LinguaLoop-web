# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1028`

Read `data/exercise_seeding/zh/wf2/r1028/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1028/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102805: 私人生活

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 私人生活是一个人自己的事，是在家里做的、不想让别人都知道的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这场关于广场舞扰民的争议看似琐碎，实则折射出老龄化社会中公共空间与私人生活的边界之争。
- sentences to write yourself: 9

## sense 102806: 私人生活

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指个人在工作和公共场合之外的生活，包括家庭、感情、兴趣和日常安排等，通常不愿被别人随便打听或公开。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102893: 相互指责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 两个人或两方都说对方不好，都说是对方的错。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 与其相互指责，不如寻求折中：调整活动时段、改用耳机、或划定专用场地。
- sentences to write yourself: 9

## sense 102894: 相互指责

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指双方或多方互相把错误或责任推给对方，批评对方不对。常用于发生矛盾、事故或争吵之后。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102895: 怨气

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 怨气是你心里很生气、很不高兴，却没有说出来的感觉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 有人抱怨孩子无法安心写作业，有人因夜班后补不了眠而心生怨气，物业调解多次仍收效甚微。
- sentences to write yourself: 9

## sense 102896: 怨气

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指因受到委屈、不公平对待或不满而积在心里的怨恨和不满情绪。常与“满肚子”“发泄”“消除”等词搭配。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
