# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1040`

Read `data/exercise_seeding/zh/wf2/r1040/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1040/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 102762: 待命状态

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指人员、部队、设备等做好准备，随时等候命令或指示，一接到通知就能马上行动的状态。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100229: 不知不觉

- reading: (none)
- dictionary POS hint: 副词. The enum below wins over this hint.
- existing definition: 不知不觉就是没有感觉到，事情就慢慢发生了。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 更值得警惕的是，边界的消失常被包装成"灵活"与"高效"，让人在不知不觉中延长了劳动时间。
- sentences to write yourself: 9

## sense 102867: 缝隙

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 缝隙就是东西中间很窄很细的空地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多人虽然不必再到公司打卡，却发现自己几乎随时在线——清晨查看邮件，深夜回复钉钉上的消息，工作仿佛渗透进了生活的每一个缝隙。
- sentences to write yourself: 9

## sense 102868: 缝隙

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 物体裂开或两个物体之间留下的狭长而窄小的空隙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 102871: 搬进

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把东西拿到新的地方，然后住在那里。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，当办公桌被搬进客厅，这种切换也随之消失。
- sentences to write yourself: 9

## sense 102872: 搬进

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指把人或物从原来的地方转移到新的地方，多用于迁入新居或新的场所。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
