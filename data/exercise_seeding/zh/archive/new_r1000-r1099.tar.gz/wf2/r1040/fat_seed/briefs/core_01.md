# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1040`

Read `data/exercise_seeding/zh/wf2/r1040/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1040/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104397: 房龄

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 房子盖好以后过了多少年。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，价格并非仅由面积决定，地段、楼层、房龄同样举足轻重，单一直线难免失之简略。
- sentences to write yourself: 9

## sense 104398: 房龄

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指房屋从建成到现在所经过的年数，常用来说明房子新旧，买卖或租赁房屋时经常提到。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99070: 钉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一端尖锐、用来固定物体的金属小棍。
- learner tier: T3
- surface forms seen in tests: ["钉"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 许多人虽然不必再到公司打卡，却发现自己几乎随时在线——清晨查看邮件，深夜回复钉钉上的消息，工作仿佛渗透进了生活的每一个缝隙。
- sentences to write yourself: 9

## sense 99069: 钉

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 钉是一头尖尖的小铁条，用锤子敲进木头里，可以固定东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100675: 办公桌

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 办公桌是办公用的桌子。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 然而，当办公桌被搬进客厅，这种切换也随之消失。
- sentences to write yourself: 9

## sense 102761: 待命状态

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 待命状态就是先准备好，不乱动，等人叫你再去做事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 当上级的消息可以在任何时刻抵达，员工便难以真正放松；大脑始终处于待命状态，休息的质量自然下降。
- sentences to write yourself: 9
