# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1052`

Read `data/exercise_seeding/zh/wf2/r1052/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1052/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103603: 开阔眼界

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看到很多新东西，知道得更多。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 毕竟旅行的意义在于放松身心、开阔眼界,而非在拥挤中耗尽体力与耐心。
- sentences to write yourself: 9

## sense 103604: 开阔眼界

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指通过见识、经历或学习新的事物，增长见闻，让自己的视野和想法变得更宽广。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103605: 摩肩接踵

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 人很多很挤，肩膀碰着肩膀，脚跟碰着脚跟。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 进了景区,所谓游览更像被人流推着前行:观景台上摩肩接踵,拍一张照要排半天队,人山人海,举步维艰。
- sentences to write yourself: 9

## sense 103606: 摩肩接踵

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 肩膀挨着肩膀，脚尖碰着脚跟，形容人多拥挤，来来往往非常热闹。多用来描写节日、集市、景区等场所人流密集的情景。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100655: 攥

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 用手紧紧握住
- learner tier: T3
- surface forms seen in tests: ["攥"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 天还没亮,山门外的队伍已蜿蜒数里,游客攥着手机反复刷新页面,唯恐门票预约名额在几分钟内被抢空。
- sentences to write yourself: 9

## sense 104817: 程序库

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 程序库是电脑里放好多现成小程序的地方，写程序的人可以拿来用。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其次，Python凭借丰富的程序库，在数据清洗、统计建模和可视化方面发挥着重要作用。
- sentences to write yourself: 9
