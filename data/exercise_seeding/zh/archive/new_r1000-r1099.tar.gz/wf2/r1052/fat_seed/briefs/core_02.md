# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1052`

Read `data/exercise_seeding/zh/wf2/r1052/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1052/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104818: 程序库

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指把许多可重复使用的代码、函数或类集中存放的集合，程序员在开发软件时可以直接调用，以节省时间、减少重复劳动。也称“库”或“函数库”。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101345: 管理层

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 管理层是公司里做决定的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 因此，优秀的分析师既要精通技术，又要善于沟通，能把复杂的结论转化为管理层看得懂、用得上的建议。
- sentences to write yourself: 9

## sense 88109: 归

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 返回；回到原处。
- learner tier: T3
- surface forms seen in tests: ["归"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 88107: 归

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 归是回到原来的地方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 101427: 杂乱

- reading: (none)
- dictionary POS hint: 形容词. The enum below wins over this hint.
- existing definition: 东西没有顺序，乱乱的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 经过这样的转换，杂乱的信息才逐渐变得可以分析，企业也能据此改进服务。
- sentences to write yourself: 9

## sense 100635: 标注

- reading: (none)
- dictionary POS hint: 动词. The enum below wins over this hint.
- existing definition: 写上记号
- learner tier: T3
- surface forms seen in tests: ["标注"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (2, keep verbatim, put first):
  0. 为了解决这一难题，研究人员往往先请专人对大量评论进行标注，例如把句子归为“好评”或“差评”，再让算法从中学习规律。
  1. 图片同样需要标注，比如圈出画面中的商品并写上名称。
- sentences to write yourself: 8
