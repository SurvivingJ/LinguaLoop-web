# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1018`

Read `data/exercise_seeding/zh/wf2/r1018/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1018/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103714: 直呼其名

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 不用敬称、职务或亲属称呼，直接说出某人的名字来称呼他。多用于不拘礼节的场合，有时也显得不够礼貌或很随便。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103715: 繁文缛节

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 意思是做事的规矩和步骤太多，让人觉得很麻烦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 所谓微信礼仪，并非繁文缛节，而是一套让长辈与上级感到被尊重的表达习惯。
- sentences to write yourself: 9

## sense 103716: 繁文缛节

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 指繁琐多余的礼节或过于复杂的规矩、手续、程序，含贬义，常用来批评办事不必要的麻烦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103831: 省略

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 省略是把一些话或东西去掉不说，不写。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 首要的一环是称呼：向长辈或上司发消息时不宜直呼其名，更不宜省略称谓，一句得体的"张老师""李经理"，往往比冗长的客套更能传递敬意。
- sentences to write yourself: 9

## sense 103832: 省略

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 把不重要或可以不要的部分去掉，不说出来或不写出来；也指用符号表示中间有内容没有写出来。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100231: 工作日

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 工作日是要上班的日子。
- learner tier: T3
- surface forms seen in tests: ["工作日"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 某连锁餐饮企业的区域经理曾坚信“周末必定客流最旺”，于是将大部分人手集中在周末，结果工作日的外卖订单激增时，门店却人手不足，顾客怨声载道。
- sentences to write yourself: 9
