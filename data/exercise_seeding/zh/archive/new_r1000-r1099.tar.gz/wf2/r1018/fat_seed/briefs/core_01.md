# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1018`

Read `data/exercise_seeding/zh/wf2/r1018/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1018/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 87920: 素材

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 创作文学、艺术等作品时所用的原始材料。
- learner tier: T3
- surface forms seen in tests: ["素材"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 87919: 素材

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 素材是写文章或画画时，用来做材料的东西。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99903: 口吻

- reading: (none)
- dictionary POS hint: 名词. The enum below wins over this hint.
- existing definition: 口吻就是说话时的语气。
- learner tier: T3
- surface forms seen in tests: ["口吻"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 其次是措辞，语气应当谦和而不卑微，请求指导时多用商量的口吻，避免生硬的命令式句子。
- sentences to write yourself: 9

## sense 103709: 方寸

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 方寸是心的意思。人心很小，所以叫方寸。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 在职场与家庭之中，微信早已取代电话成为日常沟通的主要渠道，然而不少人恰恰在这方寸屏幕前失了分寸。
- sentences to write yourself: 9

## sense 103710: 方寸

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 本义指一寸见方的小地方，常比喻人的内心、心绪，如“方寸已乱”；也可指很小的范围或空间。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103713: 直呼其名

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 直接叫一个人的名字，不加别的称呼。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 首要的一环是称呼：向长辈或上司发消息时不宜直呼其名，更不宜省略称谓，一句得体的"张老师""李经理"，往往比冗长的客套更能传递敬意。
- sentences to write yourself: 9
