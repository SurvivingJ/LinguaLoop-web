# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1021`

Read `data/exercise_seeding/zh/wf2/r1021/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1021/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103065: 可有可无

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 有也行，没有也行，不是很要紧。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 一位临近退休的老同事感慨，年轻时总觉得体检是可有可无的形式，如今才明白，那些密密麻麻的数字里，藏着身体最诚实的语言。
- sentences to write yourself: 9

## sense 103066: 可有可无

- reading: (none)
- dictionary POS hint: idiom. The enum below wins over this hint.
- existing definition: 形容某事物有没有都行，不重要，作用不大，不是必需的。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 100382: 填报

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 填写（表格、单据等）
- learner tier: T3
- surface forms seen in tests: ["填报"]
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 于是，母亲辞去工作在学校附近租房陪读，父亲在深夜里研究各校的分数线与志愿填报策略，仿佛只要算得足够精细，就能为孩子铺就一条稳妥的路。
- sentences to write yourself: 9

## sense 100381: 填报

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 在表格里写东西
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104495: 深浅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 深浅就是东西有多深，或者颜色有多深。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这种做法与医学领域的循证理念一脉相承：结论必须经得起证据检验，而非取决于资历深浅。
- sentences to write yourself: 9

## sense 104496: 深浅

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指深度或程度的大小，也指颜色的浓淡；还可以指说话做事的分寸。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
