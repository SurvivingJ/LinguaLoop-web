# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1021`

Read `data/exercise_seeding/zh/wf2/r1021/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1021/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103059: 病痛

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 病痛是人生病时身体很难受、很疼的感觉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 这项制度看似寻常，实则体现了一种朴素的关怀：与其等到病痛袭来才四处求医，不如在身体尚未拉响警报之时，主动去了解它真实的状况。
- sentences to write yourself: 9

## sense 103060: 病痛

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指疾病带来的身体上的痛苦或不适，也泛指人身体上的各种疾病和痛苦。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103061: 心电图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 医生用机器看心怎么跳，画出来的线就是心电图。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 抽血、拍片、测心电图，各项检查依次进行，前后不过两个小时。
- sentences to write yourself: 9

## sense 103062: 心电图

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 用仪器记录心脏跳动时产生的电变化而画成的曲线图，医生用它来检查心脏是否正常。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103063: 专科医院

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专科医院是只看一种病的医院，比如只看眼睛或只看牙齿。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 多数人各项指标平稳，只是被提醒少熬夜、多走动；也有少数人被告知某项指标偏高，需要尽快到专科医院复查。
- sentences to write yourself: 9

## sense 103064: 专科医院

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 专门诊治某一类疾病或某一类病人的医院，如眼科医院、儿童医院、心血管病医院等，医生在这方面的经验和设备通常更专业。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
