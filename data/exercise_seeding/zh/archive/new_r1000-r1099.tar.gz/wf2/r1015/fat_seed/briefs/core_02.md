# Fat-seed brief 02 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1015`

Read `data/exercise_seeding/zh/wf2/r1015/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1015/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 104097: 排泄物

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 排泄物是人和动物身体里排出来的脏东西，像大便和小便。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 9

## sense 104098: 排泄物

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人或动物从身体里排出的废物，主要指大便、小便等，有时也包括汗液。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 104099: 遛狗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 带小狗出去走一走，让它跑一跑。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 9

## sense 104100: 遛狗

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 带狗到户外散步、活动，让狗排便和锻炼身体。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103781: 避让

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 看到车或人过来，就走到旁边，不碰到他们。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 拴绳、清理、主动避让，这些微小的举动构成了文明养宠的底线。
- sentences to write yourself: 9

## sense 103782: 避让

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指为了不相撞或不发生冲突，主动向旁边移动或让开，也可指有意躲开某人或某事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
