# Fat-seed brief 01 — core (zh)

Run directory: `data/exercise_seeding/zh/wf2/r1015`

Read `data/exercise_seeding/zh/wf2/r1015/fat_seed/rules_core.md` first: the live P1 rules for zh. For every sense below,
write `data/exercise_seeding/zh/wf2/r1015/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 103941: 管束

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 大人看着孩子，不让他乱做不好的事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 此类邻里纠纷看似琐碎，实则折射出居住伦理的缺失——养宠物者既享有陪伴之乐，亦须承担管束之责。
- sentences to write yourself: 9

## sense 103942: 管束

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 指对人或行为加以约束和限制，使其遵守规矩，不任意妄为；多指家长、老师或组织对人的看管和教育。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103945: 惊扰

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 惊扰就是吵到别人或吓到别人，让他们不能安静。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 清晨与夜晚的遛狗时段，恰是邻里矛盾最易激化的时刻：犬吠声穿透薄墙，牵引绳的疏漏使宠物惊扰了老人与孩童，排泄物遗留于楼道亦屡见不鲜。
- sentences to write yourself: 9

## sense 103946: 惊扰

- reading: (none)
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 动词。指用声音、动作等打扰别人或动物，使其受惊、不得安宁。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 103947: 饲主

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 饲主是养小猫、小狗等小动物的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (1, keep verbatim, put first):
  0. 倘若每位饲主都能体谅他人对安宁与洁净的期待，人与宠物便可在同一屋檐下安然共存。
- sentences to write yourself: 9

## sense 103948: 饲主

- reading: (none)
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 指饲养宠物或其他动物的主人，也就是负责照顾并拥有这只动物的人。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["介词", "代词", "副词", "动词", "助词", "叹词", "名词", "形容词", "情态动词", "方向补语", "结果补语", "连词", "量词"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
