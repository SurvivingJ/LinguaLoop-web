# Fat-seed brief 02 — core (ja)

Run directory: `data/exercise_seeding/ja/wf_jlpt_n2/r0100`

Read `data/exercise_seeding/ja/wf_jlpt_n2/r0100/fat_seed/rules_core.md` first: the live P1 rules for ja. For every sense below,
write `data/exercise_seeding/ja/wf_jlpt_n2/r0100/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 119320: 調味料

- reading: ちょうみりょう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 料理の味をととのえるために使うもの。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 119322: 直通

- reading: ちょくつう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 乗り換えなしで目的地まで通じること。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 119324: 直角

- reading: ちょっかく
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 二つの直線が垂直に交わってできる、九十度の角。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 119326: 塵紙

- reading: ちりがみ
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 鼻をかんだり汚れをふいたりするのに使う、薄くて柔らかい紙。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 119328: 通路

- reading: つうろ
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 人が通るための道。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 119330: 月日

- reading: つきひ
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 時が移り過ぎていくこと。歳月。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
