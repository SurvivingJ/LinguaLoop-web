# Fat-seed brief 01 — core (ja)

Run directory: `data/exercise_seeding/ja/wf2/r0509`

Read `data/exercise_seeding/ja/wf2/r0509/fat_seed/rules_core.md` first: the live P1 rules for ja. For every sense below,
write `data/exercise_seeding/ja/wf2/r0509/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 35248: 装置

- reading: そうち
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 何かをするために使う、特別な道具や機械のことです。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 35250: 修道

- reading: しゅうどう
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 神様や仏様のための勉強やお祈りをする生活のことだよ。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 35252: 抄

- reading: しょう
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 文字や絵を手でうつし書くこと。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 35253: 抄

- reading: しょう
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 原本を手で書き写すこと。複写すること。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 35254: 写し

- reading: うつし
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 書いたものと同じものを作ること。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 35256: 根本

- reading: こんぽん
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 物事のいちばん大事なところ。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
