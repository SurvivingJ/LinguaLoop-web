# Fat-seed review 01 (ja)

Run directory: `data/exercise_seeding/ja/wf2/r0518`

Read `data/exercise_seeding/ja/wf2/r0518/fat_seed/rules_judges.md`: the live judge prompts. Apply their standards to every item.
Then for each sense below:

1. Read `data/exercise_seeding/ja/wf2/r0518/fat_seed/words/<sid>.json` (the authored document) and `data/exercise_seeding/ja/wf2/r0518/fat_seed/plans/<sid>.json`
   (which blocks are required, and the sentence each one is anchored to).
2. Write `data/exercise_seeding/ja/wf2/r0518/fat_seed/reviewed/<sid>.json`: the full corrected document, same shape.
   Copy it unchanged only if nothing needed fixing.
3. Write `data/exercise_seeding/ja/wf2/r0518/fat_seed/review/<sid>.json`:
   `{"sense_id": <sid>, "verdict": "accept"|"rewrite"|"reject",
      "issues": [{"path": "variants.A.level_3.options[2]", "problem": "…", "fix": "…"}],
      "notes": "…"}`

`reject` drops the sense from the upload. Use it only when the core itself is
unusable (wrong sense, broken sentences), not for a fixable distractor.


- sense 99731: 高い
- sense 99817: 送る
- sense 35824: 寸断
- sense 35834: 対処
- sense 35846: 構築
- sense 35848: 取り巻く
