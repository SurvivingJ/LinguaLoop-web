# Fat-seed brief 01 — core (ja)

Run directory: `data/exercise_seeding/ja/wf2/r0529`

Read `data/exercise_seeding/ja/wf2/r0529/fat_seed/rules_core.md` first: the live P1 rules for ja. For every sense below,
write `data/exercise_seeding/ja/wf2/r0529/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 51437: 薬

- reading: くすり
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 病気を治すために飲んだり塗ったりするものです。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 99703: バンド

- reading: ばんど
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: いっしょに がっきを えんそうする ひとたちの グループ。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 41350: 事務

- reading: じむ
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 机の上で書類を整理したり、計算したりする仕事です。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 41366: 磨く

- reading: みがく
- dictionary POS hint: 動詞. The enum below wins over this hint.
- existing definition: ものをきれいにするために、こすったりふいたりすること。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 42651: 地方

- reading: ちほう
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: 地方は、田舎の場所のことです。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 42670: 炎天

- reading: えんてん
- dictionary POS hint: 名詞. The enum below wins over this hint.
- existing definition: とても暑い夏のこと。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
