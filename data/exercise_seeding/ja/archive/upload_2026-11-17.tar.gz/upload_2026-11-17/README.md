# JA word assets — upload package

Reviewed fat-seed output for **3298 Japanese senses** (all passed
`check --source reviewed`; rejected and skipped senses are excluded).
Delta package: the 3151 senses of the earlier package are excluded.

| | |
|---|---|
| `word_assets` rows | 23,086 (7 asset types) |
| UPDATE statements | 7,100 {'dim_vocabulary': 3550, 'dim_word_senses': 3550} |
| language_id | 3 (ja) |
| source | tool-free fat-seed pipeline (scratch_offline/nt_pipeline.py); see the run directories for models |

## Files

- `apply_all.sql` — everything in one transaction (45.9 MB). Use with `psql`.
- `chunks/part_01.sql … part_38.sql` — the same statements in ~0.9 MB files, each its
  own `BEGIN … COMMIT`, UPDATEs at the end. For the Supabase SQL editor, run them in order.
- `word_assets.csv` — the asset rows only (no UPDATEs), for Table Editor import.
- `verify.sql` — row counts to run afterwards.

Every INSERT is `ON CONFLICT (sense_id, asset_type) DO UPDATE`, so re-running a
chunk is harmless. Apply with:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f data/exercise_seeding/ja/upload_2026-11-17/apply_all.sql
```

## Staging notes (2026-11-17) — NOT applied

Built against a live read-only snapshot taken 2026-11-17; nothing was written to the database.

- **Contents:** 384 senses written on 2026-11-17 (`wf2/r0506–r0539`) plus ~2,900 senses from the
  earlier run (`wf/`, `wf2/r0000–r0505`) that were reviewed but never uploaded. Every restored
  document was re-assembled and re-validated against the current snapshot and prompt set.
- **Excluded:** every sense that already has a `prompt1_core` row in `word_assets` (3,151).
- **Dictionary overwrites to review first:** the UPDATEs also write lemma/sense fields. Most fill
  NULLs, but `overwrites_live_values.csv` lists the 337 that would replace a *different* live value
  (189 `semantic_class`, 68 `part_of_speech`, 80 `pronunciation`). To keep live values, delete
  those UPDATE lines (they are at the end of each chunk) or apply only `word_assets.csv`.
- **The snapshot ages.** If the database changes before you apply this (e.g. the refactor or the
  POS standardisation migration), rebuild the package against a fresh snapshot rather than
  applying it as is.
- After applying: `verify.sql`, then stage 8 + render as in `.claude/skills/fat-seed-authoring/SKILL.md`.
