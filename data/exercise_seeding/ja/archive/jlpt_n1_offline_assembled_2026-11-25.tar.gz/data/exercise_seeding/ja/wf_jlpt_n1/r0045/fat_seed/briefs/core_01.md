# Fat-seed brief 01 — core (ja)

Run directory: `data/exercise_seeding/ja/wf_jlpt_n1/r0045`

Read `data/exercise_seeding/ja/wf_jlpt_n1/r0045/fat_seed/rules_core.md` first: the live P1 rules for ja. For every sense below,
write `data/exercise_seeding/ja/wf_jlpt_n1/r0045/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 900001080: 雄

- reading: おす
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 動物で、子を産まない方。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001082: 御世辞

- reading: おせじ
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 相手に気に入られようとして言う、心のこもらない褒め言葉。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001084: 襲う

- reading: おそう
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 不意に攻めかかる。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001086: 遅くとも

- reading: おそくとも
- dictionary POS hint: adverb. The enum below wins over this hint.
- existing definition: どんなに遅くても。遅い場合を想定しても、その時までには。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001088: 恐れ入る

- reading: おそれいる
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 相手の厚意や威力に対して、恐縮する。感服したり申し訳なく思ったりする。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001090: おだてる

- reading: おだてる
- dictionary POS hint: verb. The enum below wins over this hint.
- existing definition: 相手をほめたてて、いい気にさせる。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
