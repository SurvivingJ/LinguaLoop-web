# Fat-seed brief 02 — core (ja)

Run directory: `data/exercise_seeding/ja/wf_jlpt_n1/r0074`

Read `data/exercise_seeding/ja/wf_jlpt_n1/r0074/fat_seed/rules_core.md` first: the live P1 rules for ja. For every sense below,
write `data/exercise_seeding/ja/wf_jlpt_n1/r0074/fat_seed/words/<sense_id>.json`:

```json
{"sense_id": 123, "lemma": "…",
  "core": {
    "pos": "…", "semantic_class": "…", "definition": "…",
    "primary_collocate": null, "pronunciation": "…", "ipa": "…",
    "syllable_count": 2, "register": "…", "sense_fingerprint": "…",
    "morphological_forms": [{"form": "…", "label": "…"}],
    "sentences": [{"text": "…", "target_word": "…", "complexity_tier": "T3", "furigana": "…"}]
  }}
```

or `{"sense_id": 123, "lemma": "…", "skip": "reason"}` for proper nouns,
symbols and fragments. Do NOT write `variants` yet. That comes after `plan`.

Non-negotiable (upload rejects otherwise):
- exactly 10 sentences; every `target_word` appears verbatim in its `text`
- the mined sentences listed below come first, **byte-for-byte unchanged**
- `pos` from the POS set listed per sense; `semantic_class` from the enum. It decides the level plan.
- `primary_collocate` is null unless it passes the fixed-collocation test in the rules
- `furigana` is ja only; omit it for zh/en


## sense 900001788: 思考

- reading: しこう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 物事について筋道を立てて考えること。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001790: 嗜好

- reading: しこう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 好み。特に飲食物などの好み。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001792: 事項

- reading: じこう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 一つ一つの事柄。項目としてあげられた物事。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001794: 時刻表

- reading: じこくひょう
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 列車やバスなどの発着の時刻を一覧にして示した表。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001796: 地獄

- reading: じごく
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 死後に悪人が行って苦しみを受けるとされる世界。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10

## sense 900001798: 時差

- reading: じさ
- dictionary POS hint: noun. The enum below wins over this hint.
- existing definition: 地域による標準時の差。
- learner tier: T3
- surface forms seen in tests: []
- POS set: ["代名詞", "副詞", "助動詞", "助詞", "動詞", "名詞", "形容詞", "形状詞", "感動詞", "接尾辞", "接続詞", "接頭辞", "連体詞"]
- semantic_class enum: ["abstract", "action", "concrete", "function", "proper", "property"]
- mined sentences (0, keep verbatim, put first):
- sentences to write yourself: 10
